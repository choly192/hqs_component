import { BizCommon } from '../src/common/types';

let bizCommon: BizCommon = {
    ChatStatusCookieExpireDate: { ChattingExpireMinute: 30, WaitingChatExpireMinute: 1440 },
    PureCloud: {
        deployMentKey: 'de95e62d-cd43-4dfa-8bf1-91e6ed39c1f4',
        orgGuid: '3bda506d-faf6-4a02-84ba-ae8983d4cf01'
    },
    SpecialBusiness: [
        {
            BizType: 1,
            Description: 'Normal chat'
        },
        {
            BizType: 2,
            Description: 'Chat directly,eg:header chat'
        },
        {
            BizType: 3,
            Description: 'Chat with special queue,eg:proactive chat',
            Config: {
                SpecialApi: [
                    { key: 'Software Licensing', api: 'SoftLicensingCloseSetting' },
                    { key: 'ABS_Customer_Service', api: 'AbsCloseSetting' }
                ],
                SpecialCustomField2: 'ItemNumber'
            }
        },
        {
            BizType: 4,
            Config: {
                SpecifiedQueueList: ['GCC']
            },
            Description: 'Chat with specified queue,eg:gcc chat'
        }
    ]
};

export default bizCommon;
