import { BizChatLogin } from '../src/common/types';

let bizChatLogin: BizChatLogin = {
    CategoryOptions: {
        Common: [
            '--Please Select--',
            'Computer Components',
            'Desktop/Laptop Computers',
            'Storage & Memory',
            'Other',
        ],
        USA: [],
        CAN: [],
        USB: [],
    },
    CategoryAndQueueMapping: {
        Common: [],
        USA: [
            {
                CategoryName: 'NormalUser',
                QueueName: 'Newegg Customer Service – All Other Groups',
                QueueID: '43d2d78c-3f2f-441b-9320-02a19758d384',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'TX',
                QueueName: '',
                QueueID: '',
                Skills: 'Texas',
                Priority: '0',
            },
            {
                CategoryName: 'Software Licensing',
                QueueName: 'Software Licensing',
                QueueID: '1642b0bb-4c36-425c-acfd-e1c292ab97c9',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'GCC',
                QueueName: 'GCC Support',
                QueueID: 'bb9c0c0d-2229-4bdd-8e4a-4bf73ce07e11',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'ABS_Customer_Service',
                QueueName: 'ABS Customer Service',
                QueueID: '94607a83-b70c-47cf-b242-b0dc75a60d35',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Computer Components',
                QueueName: 'Newegg Customer Service – Group 1.1 (Components)',
                QueueID: '9c3b6bcb-3738-4302-b480-0c64e9f2d3d1',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Desktop/Laptop Computers',
                QueueName: 'Newegg Customer Service – Group 1.2 (Systems)',
                QueueID: '6f20e8b2-e0d7-4503-b4ed-602e30e7796b',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Storage & Memory',
                QueueName: 'Newegg Customer Service – Group 1.3 (Storage)',
                QueueID: '87ae8e8e-d12b-40e3-bae0-395a7f380db6',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Other',
                QueueName: 'Newegg Customer Service – All Other Groups',
                QueueID: '43d2d78c-3f2f-441b-9320-02a19758d384',
                Skills: 'Chat',
                Priority: '0',
            },
        ],
        CAN: [
            {
                CategoryName: 'Computer Components',
                QueueName: 'Newegg Customer Service – Group 1.1 (Components)',
                QueueID: '9c3b6bcb-3738-4302-b480-0c64e9f2d3d1',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Desktop/Laptop Computers',
                QueueName: 'Newegg Customer Service – Group 1.2 (Systems)',
                QueueID: '6f20e8b2-e0d7-4503-b4ed-602e30e7796b',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Storage & Memory',
                QueueName: 'Newegg Customer Service – Group 1.3 (Storage)',
                QueueID: '87ae8e8e-d12b-40e3-bae0-395a7f380db6',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Other',
                QueueName: 'Newegg Customer Service – All Other Groups',
                QueueID: '43d2d78c-3f2f-441b-9320-02a19758d384',
                Skills: 'Chat',
                Priority: '0',
            },
        ],
        USB: [
            {
                CategoryName: 'ABS_Customer_Service',
                QueueName: 'ABS Customer Service',
                QueueID: '94607a83-b70c-47cf-b242-b0dc75a60d35',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Computer Components',
                QueueName: 'B2B Service',
                QueueID: '3b4df4b9-e1f5-4e3a-a083-0d74f054757e',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Desktop/Laptop Computers',
                QueueName: 'B2B Service',
                QueueID: '3b4df4b9-e1f5-4e3a-a083-0d74f054757e',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Storage & Memory',
                QueueName: 'B2B Service',
                QueueID: '3b4df4b9-e1f5-4e3a-a083-0d74f054757e',
                Skills: 'Chat',
                Priority: '0',
            },
            {
                CategoryName: 'Other',
                QueueName: 'B2B Service',
                QueueID: '3b4df4b9-e1f5-4e3a-a083-0d74f054757e',
                Skills: 'Chat',
                Priority: '0',
            },
        ],
    },
    ChatBotEntrance: {
        Enable: true,
        AllowAllTopicAndReason: false,
    },
    DefaultTopic: '--Select Support Topic--',
    DefaultReason: '--Select Reason--',
    DefaultCategory: '--Please Select--',
    DefaultCloseMessage: "<span class='message-title'>We are sorry!</span>\n                            <p>Please contact us during normal business hours or visit our Knowledge Base <a href='https://kb.newegg.com/'>here</a> for articles to answer questions you might have. We highly recommend using our self-help online tools to track an order, return an item or check the return status for the fastest assistance. </p>",
    EnableTranscript: true,
    TopicAndReasonOptions: {
        Common: [
            {
                Name: 'Order Assistance',
                Reason: [
                    {
                        Name: 'Check order status',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Assistance or problems placing an order',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Pricing or promotions',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Rebates',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Submit a Newegg Marketplace Guarantee claim',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Other order related questions',
                        AllowChatBot: false,
                    },
                ],
            },
            {
                Name: 'Return',
                Reason: [
                    {
                        Name: 'Refund or Replacement',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Check the status of an existing return',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Other return or RMA related Questions',
                        AllowChatBot: false,
                    },
                ],
            },
            {
                Name: 'Payment',
                Reason: [
                    {
                        Name: 'Failed order/payment verification',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Assistance with Payment Methods',
                        AllowChatBot: true,
                    },
                ],
            },
            {
                Name: 'Shipping',
                Reason: [
                    {
                        Name: 'File a claim for a damaged shipment',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Report a delayed shipment',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Report a lost shipment',
                        AllowChatBot: true,
                    },
                    {
                        Name: 'Check the status of an existing claim',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Other shipping related questions',
                        AllowChatBot: true,
                    },
                ],
            },
            {
                Name: 'Account/Other',
                Reason: [
                    {
                        Name: 'Make changes to your Newegg account',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Forgot Newegg ID or password',
                        AllowChatBot: false,
                    },
                    {
                        Name: 'Other Inquires/General Assistance',
                        AllowChatBot: false,
                    },
                ],
            },
        ],
        USA: [],
        CAN: [],
        USB: [],
    },
    SpecialChatSkills: [
        {
            SkillName: 'Returns',
            HitTopic: 'Return',
            HitCategory: '',
            HitReason: '',
            HitCity: '',
        },
        {
            SkillName: 'Shipping',
            HitTopic: 'Shipping',
            HitCategory: '',
            HitReason: '',
            HitCity: '',
        },
        {
            SkillName: 'Texas',
            HitTopic: '',
            HitCategory: '',
            HitReason: '',
            HitCity: 'TX',
        },
    ],
    EmailValidRegex:
        '^\\s*[0-9a-zA-Z_-](?:(?:[-\\w\\+]|\\.(?!\\.))*[0-9a-zA-Z_-])?@[0-9a-zA-Z](?:(?:[0-9a-zA-Z]|\\.(?!(?:\\.|-))|-(?!\\.))*[0-9a-zA-Z])?\\.[0-9a-zA-Z]{2,}\\s*$',
};

export default bizChatLogin;
