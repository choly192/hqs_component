import { BizCustomizedUI } from '../src/common/types';

let bizCustomizedUI: BizCustomizedUI = {
    ChatWindow: [
        {
            Countries: 'Default',
            Value: {
                Title: {
                    Main: 'Chat With Us',
                    Sub:
                        '<div style="font-size:10px; padding-left:5px">Or call us at (800) 390-1119. <a href="https://kb.newegg.com/knowledge-base/contacting-customer-service/" target="_blank" style="color:white;font-size:10px;">Need to Schedule Callback instead?<i style="padding-left:5px;" class="fa fa-info-circle" aria-hidden="true"></i></a></div>',
                },

                Disclaimer: `
                <p>Disclaimer:</p>
                <p>By moving forward in this chat support with Newegg Customer Service, you hereby agree to have your personal data processed by Newegg Inc. For the full policy, click <a href="https://kb.newegg.com/knowledge-base/privacy-policy-newegg/" target="_blank" style="color: #05f;text-decoration: underline;cursor: pointer;">here</a>.</p>
              `,
            },
        },
        {
            Countries: 'USA',
            Value: {
                Title: {
                    Main: 'Chat With Us',
                    Sub:
                        '<div style="font-size:10px; padding-left:5px">Or call us at (800) 390-1119. <a href="https://kb.newegg.com/knowledge-base/contacting-customer-service/" target="_blank" style="color:white;font-size:10px;">Need to Schedule Callback instead?<i style="padding-left:5px;" class="fa fa-info-circle" aria-hidden="true"></i></a></div>',
                },

                Disclaimer: `
                <p>Disclaimer:</p>
                <p>By moving forward in this chat support with Newegg Customer Service, you hereby agree to have your personal data processed by Newegg Inc. For the full policy, click <a href="https://kb.newegg.com/knowledge-base/privacy-policy-newegg/" target="_blank" style="color: #05f;text-decoration: underline;cursor: pointer;">here</a>.</p>
              `,
            },
        },
        {
            Countries: 'CAN',
            Value: {
                Title: {
                    Main: 'Chat With Us',
                    Sub:
                        '<div style="font-size:10px; padding-left:5px">Or call us at (800) 390-1119. <a href="https://kb.newegg.ca/knowledge-base/contacting-customer-service/" target="_blank" style="color:white;font-size:10px;">Need to Schedule Callback instead?<i style="padding-left:5px;" class="fa fa-info-circle" aria-hidden="true"></i></a></div>',
                },
                Disclaimer: `
                <p>Disclaimer:</p>
                <p>By moving forward in this chat support with Newegg Customer Service, you hereby agree to have your personal data processed by Newegg Inc. For the full policy, click <a href="https://kb.newegg.com/knowledge-base/privacy-policy-newegg/" target="_blank" style="color: #05f;text-decoration: underline;cursor: pointer;">here</a>.</p>
              `,
            },
        },
        {
            Countries: 'USB',
            Value: {
                Title: {
                    Main: 'Chat With Us',
                    Sub:
                        '<div style="font-size:10px; padding-left:5px">Or call us at (800) 390-1119. <a href="https://kb.newegg.com/knowledge-base/contacting-customer-service/" target="_blank" style="color:white;font-size:10px;">Need to Schedule Callback instead?<i style="padding-left:5px;" class="fa fa-info-circle" aria-hidden="true"></i></a></div>',
                },
                Disclaimer: `
                <p>Disclaimer:</p>
                <p>By moving forward in this chat support with Newegg Customer Service, you hereby agree to have your personal data processed by Newegg Inc. For the full policy, click <a href="https://kb.newegg.com/knowledge-base/privacy-policy-newegg/" target="_blank" style="color: #05f;text-decoration: underline;cursor: pointer;">here</a>.</p>
              `,
            },
        },
    ],
};
export default bizCustomizedUI;
