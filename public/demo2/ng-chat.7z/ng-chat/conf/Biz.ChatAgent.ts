import { BizChatAgent } from '../src/common/types';

let bizChatAgent: BizChatAgent = {
    EnableTyping: true
};

export default bizChatAgent;
