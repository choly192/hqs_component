import { Service } from './Service.RestfulAPI';

export = {
    [Service.OnlineChatService]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
                connection: 'Keep-Alive',
                Authorization: 'Bearer sPc0wAJJWWFouT0qx36G7Sc7KEOne3gORykLc0QV',
            },
        },
        serverList: [{ address: 'https://gqc-onlinechat.newegg.org/' }],
        // serverList: [{ address: 'https://help.newegg.com/' }],
    },
    [Service.ChatSurveyService]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
                connection: 'Keep-Alive',
            },
        },
        serverList: [{ address: 'http://apis.newegg.org/' }],
    },
    [Service.PureCloudGuestWebChatService]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
            },
        },
        serverList: [{ address: 'https://apis-tp11.newegg.org/' }],
    },
    [Service.TranslateService]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
            },
        },
        serverList: [{ address: 'http://apis.newegg.org/' }],
    },
    [Service.HelpSiteCenterService]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
                Authorization: 'Bearer MC3VybiEC3OejsHOaUCmR0hfay227lBgpfT1R8ZF',
            },
        },
        serverList: [{ address: 'http://apis-dev.newegg.org/' }],
    },
    [Service.WebChatScriptSetting]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
            },
        },
        serverList: [{ address: 'http://10.16.75.24:3000/' }],
    },
    [Service.IPDataService]: {
        options: {
            headers: {
                'content-type': 'application/json',
                accept: 'application/json',
            },
        },
        serverList: [{ address: 'http://apis.newegg.org/' }],
    },
    [Service.ExternalReviewUploadService]: {
        options: {
          headers: {
            'content-type':
              'multipart/form-data; boundary=--------------------------003526552578530167934358',
            accept: 'application/json',
            Authorization: 'Bearer vBuWNKYcX4oo07g3W7Jhn0Te2eaClmYfiiDSeJsP',
          },
        },
        serverList: [{ address: 'http://10.16.75.24:3000/' }],
      },
};
