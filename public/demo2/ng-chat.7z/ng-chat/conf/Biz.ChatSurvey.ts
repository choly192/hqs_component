import {BizChatSurvey} from "../src/common/types/biz-chatSurvey"
let bizChatSurvey: BizChatSurvey = {
    FeedBackInfo: {
        HashCode: "2C054C28",
        ExcludeQuesion: "54",
        QuestionReplaceInfo: {
            Question: [
                {
                    QuestionMasterId: "49",
                    QuestionText: "Did you feel valued?"
                },
                {
                    QuestionMasterId : "161",
                    QuestionText: "Was your experience easy?"
                },
                {
                    QuestionMasterId : "52",
                    QuestionText: "Was your issue resolved?"
                },
                {
                    QuestionMasterId : "53",
                    QuestionText: "How likely would you recommend Newegg?"
                },
                {
                    QuestionMasterId:"295",
                    QuestionText:"Please enter your email address if you would like us to contact you back about your experience today"
                },
                {
                    QuestionMasterId : "55",
                    QuestionText: "Comments"
                }
            ]
        }
    }
}
export default bizChatSurvey
