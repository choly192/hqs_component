module.exports = {
    PORT: 8080,
    CDN: {
        imageServer: 'https://c1.neweggimages.com/',
        cssServer: 'https://akamai.newegg.com.sh/',
        jsServer: 'https://akamai.newegg.com.sh/',
        staticImageServer: 'https://akamai.newegg.com.sh/'
    },
    HealthCheck: {
        CheckRemoteConfigs: true
    }
};
