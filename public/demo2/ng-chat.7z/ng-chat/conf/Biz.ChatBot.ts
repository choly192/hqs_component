import { BizChatBot } from '../src/common/types';

let bizChatBot: BizChatBot = {
    MaxConnectToAgentRetryCounts: 20,
};

export default bizChatBot;
