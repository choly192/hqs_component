export enum Service {
    OnlineChatService = 'OnlineChatService',
    ChatSurveyService = 'ChatSurveyService',
    PureCloudGuestWebChatService = 'PureCloudGuestWebChatService',
    TranslateService = 'TranslateService',
    HelpSiteCenterService = 'HelpSiteCenterService',
    WebChatScriptSetting = 'WebChatScriptSetting',
    IPDataService = 'IPDataService',
    ExternalReviewUploadService = 'ExternalReviewUploadService',
}

export default {
    CreatePureCloudWebChatConversation: {
        method: 'POST',
        path: 'api/v2/webchat/guest/conversations',
        service: Service.PureCloudGuestWebChatService,
    },
    TranslateText: {
        method: 'GET',
        path: 'parrot/language/v3/translate',
        service: Service.TranslateService,
    },
    GetHelpSiteCenterSetting: {
        method: 'GET',
        path: 'HelpSiteCenterService/v1/Contact/Settings',
        service: Service.HelpSiteCenterService,
    },
    CommentCard: {
        method: 'GET',
        path: 'store-maintain/v1/customer-feedback/comment-card-by-code/:hashCode',
        service: Service.ChatSurveyService,
    },
    Submit: {
        method: 'POST',
        path: 'store-maintain/v1/customer-feedback/response',
        service: Service.ChatSurveyService,
    },
    GetWebChatMember: {
        method: 'GET',
        path: 'api/v2/webchat/guest/conversations/:conversationId/members/:memberId',
        service: Service.PureCloudGuestWebChatService,
    },
    GetWebChatMembers: {
        method: 'GET',
        path: 'api/v2/webchat/guest/conversations/:conversationId/members',
        service: Service.PureCloudGuestWebChatService,
    },
    SenCustomerMsgToAgent: {
        method: 'POST',
        path: 'api/v2/webchat/guest/conversations/:conversationId/members/:memberId/messages',
        service: Service.PureCloudGuestWebChatService,
    },
    EndWebChatMember: {
        method: 'Delete',
        path: 'api/v2/webchat/guest/conversations/:conversationId/members/:memberId',
        service: Service.PureCloudGuestWebChatService,
    },
    PostWebChatMemberTyping: {
        method: 'POST',
        path: 'api/v2/webchat/guest/conversations/:conversationId/members/:memberId/typing',
        service: Service.PureCloudGuestWebChatService,
    },
    GetWebChatMessages: {
        method: 'GET',
        path: 'api/v2/webchat/guest/conversations/:conversationId/messages',
        service: Service.PureCloudGuestWebChatService,
    },
    SendEmailMessage: {
        method: 'POST',
        path: 'api/webchat/publisher/end',
        service: Service.WebChatScriptSetting,
    },
    SaveConservationMessage: {
        method: 'POST',
        path: 'api/webchat/publisher/message',
        service: Service.WebChatScriptSetting,
    },
    SaveConservation: {
        method: 'POST',
        path: 'api/webchat/publisher/createconverastion',
        service: Service.WebChatScriptSetting,
    },
    SoftLicensingCloseSetting: {
        method: 'GET',
        path: 'api/purecloud/softlicense',
        service: Service.OnlineChatService,
    },
    AbsCloseSetting: {
        method: 'GET',
        path: 'api/purecloud/abscustomer',
        service: Service.OnlineChatService,
    },
    IPData: {
        method: 'GET',
        path: 'ipdata/:ip',
        service: Service.IPDataService,
    },
    ChatAgentAttachmentFileLink: {
        method: 'GET',
        path: 'onlinechatservice/connection/chatwithbot/decrypt/attachment',
        service: Service.OnlineChatService,
    },
    UploadClient: {
        method: 'POST',
        path: 'website/uploadfile/review/',
        service: Service.ExternalReviewUploadService,
        internal: true,
    },
};
