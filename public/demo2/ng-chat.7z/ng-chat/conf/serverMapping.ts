import os from 'os';

module.exports = [
    { name: 'E4K8S',        environment: 'PROD',        serverId: 'DESKTOP-E4K8S',      channel: 'E4' },
    { name: 'E11K8S',       environment: 'PROD',        serverId: 'DESKTOP-E11K8S',     channel: 'E11' },

    { name: 'SANDBOX',      environment: 'SandBox',     serverId: 'DESKTOP-SandBox',    channel: 'SandBox'},
    { name: 'PreLaunch',    environment: 'PreLaunch',   serverId: 'DESKTOP-PreLaunch',  channel: 'PreLaunch'},

    { name: 'E4K8SCanary',  environment: 'PROD',        serverId: 'E4K8SCanary',        channel: 'E4' },
    { name: 'E11K8SCanary', environment: 'PROD',        serverId: 'E11K8SCanary',       channel: 'E11' },

    { name: 'GQC',  environment: 'GQC', serverId: 'GQC-Server' },

    { name: 'gdev', environment: 'gdev', serverId: 'gdev' },

    { name: os.hostname(), environment: 'dev', serverId: 'dev' },
];
