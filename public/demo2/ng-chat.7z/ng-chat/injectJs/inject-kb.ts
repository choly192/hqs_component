declare let jQuery;

(function () {
    // var ngChatAddress = 'https://chat.newegg.com/';
    var ngChatAddress = 'http://localhost:8080/';
    var isGCC = window.location.pathname === '/ar/';
    var params = {
        injectionType: 'embed',
        type: isGCC ? 4 : 1,
        country: countryInCookie(),
        loginName: '',
        encryptedEmailAddress: '',
        encryptedCustomerNumber: '',
        currencyCode: '',
        nvtc: '',
        specifiedQueue: isGCC ? 'GCC' : ''
    };

    var isCAN = checkIsCAN();
    function checkIsCAN() {
        return countryInCookie() == 'CAN';
    }

    function getInfoFromCookie() {
        try {
            var cookieList = document.cookie
                .split(';')
                .map(function (s) {
                    return s.trim();
                })
                .filter(function (t) {
                    return t;
                })
                .map(function (c) {
                    var list = c.split('=');
                    return { key: list[0], value: list[1] };
                });
            var otherInfo = cookieList.find(function (t) {
                return t.key == 'NV%5FOTHERINFO';
            });
            if (otherInfo) {
                var otherInfoJson = JSON.parse(decodeURIComponent(otherInfo.value).substr(2));
                var otherInfoDetail = otherInfoJson['Sites'][isCAN ? 'CAN' : 'USA']['Values'];
                if (otherInfoDetail) {
                    params.loginName = otherInfoDetail['si'];
                    params.encryptedEmailAddress = otherInfoDetail['sb'];
                    params.encryptedCustomerNumber = otherInfoDetail['sc'];
                }
            }
            var configInfo = cookieList.find(function (t) {
                return t.key == 'NV%5FCONFIGURATION';
            });
            if (configInfo) {
                var configInfoJson = JSON.parse(decodeURIComponent(configInfo.value).substr(2));
                var configInfoDetail = configInfoJson['Sites'][isCAN ? 'CAN' : 'USA']['Values'];
                params.currencyCode = configInfoDetail['w58'];
            }
            var nvtcInfo = cookieList.find(function (t) {
                return t.key == 'NVTC';
            });
            params.nvtc = nvtcInfo['value'];
        } catch (e) {}
    }
    getInfoFromCookie();

    function loadDom() {
        var paramsArr = [];
        if (params != null) {
            Object.keys(params).forEach(function (key) {
                if (params[key]) {
                    paramsArr.push(key + '=' + params[key]);
                }
            });
        }
        var chatContainerHtml =
            '<div id="chatContainer" class="chat-container" ' +
            'style="padding: 0px; right: 17px; bottom: 17px; left: unset; z-index: 99999; border: none; border-radius: 4px 4px 3px 3px; box-shadow: rgba(0, 0, 0, 0.5) 0px 1px 10px; height: 521px; width: 100%;">';

        var chatDiv =
            chatContainerHtml +
            '<iframe allow="geolocation" id="chat-iframe" frameborder="no" src="' +
            ngChatAddress +
            '?' +
            paramsArr.join('&') +
            '" tabindex="0" height="521px" width="100%"></iframe>' +
            '</div>';

        var $body = jQuery('.ht-page .ht-container');
        $body.prepend(jQuery(chatDiv));
    }


    function countryInCookie() {
        var cookieName = 'NV%5FW57';
        var result = document.cookie.match('(^|[^;]+)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
        var cookieValue = result ? unescape(result.pop()) : '';
        if (cookieValue) {
            return cookieValue.toUpperCase();
        } else {
            return 'USA';
        }
    }

    loadDom();
})();
