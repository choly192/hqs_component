declare let Biz: any;
declare let jQuery;

var Chat = (function () {
    // var ngChatAddress = 'https://chat.newegg.com/';
    var ngChatAddress = 'http://localhost:8080/';
    var chatCookieName = 'NV_CustomizedInfoes';
    var chatSubDomainName = 'wschat';

    var item_Subcategory_category_chatTopic_mapping = [
        {
            topic: 'Software Licensing',
            // checkUrl: 'https://ec-apis.newegg.com/api/purecloud/softlicense',
            checkUrl: 'https://gqc-onlinechat.newegg.org/api/purecloud/softlicense',
            token: 'Bearer sPc0wAJJWWFouT0qx36G7Sc7KEOne3gORykLc0QV',
            categoryIds: { ids: ['785'], is_regex: false },
            subCategoryIds: { ids: [], is_regex: false }
        }
    ];
    var params = {
        injectionType: 'popup',
        country: 'USB',
        topic: '',
        reason: '',
        category: '',
        type: 1,
        loginName: '',
        encryptedEmailAddress: '',
        encryptedCustomerNumber: '',
        currencyCode: '',
        nvtc: ''
    };
    var postMsg = {
        topic: '',
        reason: '',
        category: '',
        type: 1,
        key: 'chat',
        noAction: false
    };

    function getInfoFromCookie() {
        try {
            var cookieList = document.cookie
                .split(';')
                .map(function (s) {
                    return s.trim();
                })
                .filter(function (t) {
                    return t;
                })
                .map(function (c) {
                    var list = c.split('=');
                    return { key: list[0], value: list[1] };
                });
            var otherInfo = cookieList.find(function (t) {
                return t.key == 'NV%5FOTHERINFO';
            });
            if (otherInfo) {
                var otherInfoJson = JSON.parse(decodeURIComponent(otherInfo.value).substr(2));
                var otherInfoDetail = otherInfoJson['Sites']['B2B']['Values'];
                if (otherInfoDetail) {
                    params.loginName = otherInfoDetail['si'];
                    params.encryptedEmailAddress = otherInfoDetail['sb'];
                    params.encryptedCustomerNumber = otherInfoDetail['sc'];
                }
            }
            var configInfo = cookieList.find(function (t) {
                return t.key == 'NV%5FCONFIGURATION';
            });
            if (configInfo) {
                var configInfoJson = JSON.parse(decodeURIComponent(configInfo.value).substr(2));
                var configInfoDetail = configInfoJson['Sites']['B2B']['Values'];
                params.currencyCode = configInfoDetail['w58'];
            }
            var nvtcInfo = cookieList.find(function (t) {
                return t.key == 'NVTC';
            });
            params.nvtc = nvtcInfo['value'];
        } catch (e) {}
    }
    getInfoFromCookie();

    function loadDom() {
        var paramsArr = [];
        if (Chat.params != null) {
            Object.keys(Chat.params).forEach(function (key) {
                if (Chat.params[key]) {
                    paramsArr.push(key + '=' + Chat.params[key]);
                }
            });
        }
        var chatContainerHtml =
            '<div id="chat-container" class="chat-container" style="padding:0;position:fixed;right:17px;bottom:17px;left:unset;z-index:99999;border:none; width:340px;height:558.188px; border-radius:4px 4px 3px 3px; box-shadow:0 1px 10px rgba(0,0,0,0.5);">';
        var chatDiv =
            chatContainerHtml +
            '<iframe allow="geolocation" id="chat-iframe" onload="Chat.initialPostMessage()" frameborder="no" src="' +
            ngChatAddress +
            '?' +
            paramsArr.join('&') +
            '" tabindex="0" height="558.188px" width="100%"></iframe>' +
            '</div>';

        var chatContainer = document.getElementById('chat-container');
        if (chatContainer) {
            chatContainer.style.visibility = 'visible';
            var redTip = document.getElementById('redTip');
            if (redTip) {
                redTip.style.display = '';
            }
        } else {
            var $body = jQuery('body');
            $body.append(jQuery(chatDiv));
        }

        Chat.initialPostMessage();

        var chatEntrance = document.getElementById('chat-entrance');
        if (chatEntrance) {
            chatEntrance.style.display = 'none';
        } else {
            buildIconHtml();
            document.getElementById('chat-entrance').style.display = 'none';
        }
    }

    function initialPostMessage() {
        // @ts-ignore
        var chatIFrame = document.getElementById('chat-iframe').contentWindow;
        if (chatIFrame) {
            chatIFrame.postMessage(Chat.postMsg, '*');
        }
    }

    function setCookieValue(name, value, min) {
        var cookieValue = readCookie();
        var valueObj = {};
        if (cookieValue !== '') {
            valueObj = JSON.parse(cookieValue);
        }
        if (min < 0) {
            delete valueObj[name];
        } else {
            var expireDate = new Date(new Date().getTime() + min * 60 * 1000);
            if (!valueObj[name]) {
                valueObj[name] = {};
            }
            valueObj[name].data = value;
            valueObj[name].exp = expireDate.getTime();
        }
        var cookieExpireDate = new Date(new Date().getTime() + 1000 * 24 * 60 * 60 * 1000);
        var expire = '; expires=' + cookieExpireDate;
        var domainArray = document.domain.split('.');
        if (domainArray.length > 1) {
            domainArray.shift();
        }
        var domain = '; domain=' + domainArray.join('.');
        var sameSite = '; SameSite=None;';
        if (window.location.protocol === 'https:') {
            sameSite += 'Secure';
        }
        document.cookie =
            chatCookieName + '=' + escape(JSON.stringify(valueObj)) + expire + domain + sameSite;
    }

    function readCookie() {
        var result = document.cookie.match('(^|[^;]+)\\s*' + chatCookieName + '\\s*=\\s*([^;]+)');
        var cookieValue = result ? unescape(result.pop()) : '';
        return cookieValue;
    }

    function buildIconHtml() {
        let css_element = document.createElement('link');
        css_element.setAttribute('rel', 'stylesheet');
        css_element.setAttribute(
            'href',
            'https://c1.neweggimages.com/WebResource/Chat/CSS/chat-icon.css'
        );
        document.body.appendChild(css_element);
        document.body.appendChild(createChatIconNode());
        function createChatIconNode() {
            var e_0 = document.createElement('div');
            e_0.setAttribute('id', 'chat-entrance');
            e_0.innerHTML = buildIconInnerHtml();
            return e_0;
        }
    }

    function buildIconInnerHtml() {
        var html =
            '<div class="slide-in-window at-right on-horizontal chat-entrance is-active">' +
            '<div class="chat-entrance-inner display-flex" onclick="Chat.loadDom()">' +
            '<i class="fa fa-comment-dots" aria-label="Newegg Chat"></i>' +
            '</div></div>';
        return html;
    }

    return {
        params: params,
        postMsg: postMsg,
        chatSubDomainName: chatSubDomainName,
        loadDom: loadDom,
        item_Subcategory_category_chatTopic_mapping: item_Subcategory_category_chatTopic_mapping,
        buildIconHtml: buildIconHtml,
        buildIconInnerHtml: buildIconInnerHtml,
        readCookie: readCookie,
        setCookieValue: setCookieValue,
        initialPostMessage: initialPostMessage
    };
})();

(function () {
    function setProactivePostMsg() {
        var checkResult = checkItemMacthMapping();
        Chat.postMsg.topic = checkResult.chatTopic;
        Chat.postMsg.reason =
            // @ts-ignore
            (window.utag_data && window.utag_data.product_id && window.utag_data.product_id[0]) ||
            '';
        Chat.postMsg.category = checkResult.chatTopic;
        Chat.postMsg.type = 3;
        Chat.params.topic = checkResult.chatTopic;
        Chat.params.reason =
            // @ts-ignore
            (window.utag_data && window.utag_data.product_id && window.utag_data.product_id[0]) ||
            '';
        Chat.params.category = checkResult.chatTopic;
        Chat.params.type = 3;
    }

    function checkIsProactiveChat() {
        var checkResult = checkItemMacthMapping();
        if (checkResult.chatTopic && checkResult.validateLink) {
            // @ts-ignore
            jQuery.ajax({
                url: checkResult.validateLink,
                cache: false,
                type: 'Get',
                accepts: 'application/json',
                dataType: 'json',
                async: true,
                timeout: 15000,
                data: {},
                beforeSend: function (request) {
                    if (checkResult.validateToken) {
                        request.setRequestHeader('Authorization', checkResult.validateToken);
                    }
                },
                success: function (isCanChat) {
                    if (isCanChat) {
                        setProactivePostMsg();
                        Chat.buildIconHtml();
                    }
                },
                error: function (err) {
                    console.error(err);
                }
            });
        }
    }

    function checkItemMacthMapping() {
        var chatTopic = '';
        var validateLink = '';
        var validateToken = '';
        // @ts-ignore
        if (window.utag_data) {
            // @ts-ignore
            var itemNumber = window.utag_data.product_id;
            // @ts-ignore
            var subcategoryId = window.utag_data.product_subcategory_id;
            // @ts-ignore
            var categoryId = window.utag_data.product_category_id;

            for (var i = 0; i < Chat.item_Subcategory_category_chatTopic_mapping.length; i++) {
                var topicMappingInfo = Chat.item_Subcategory_category_chatTopic_mapping[i];

                var match =
                    checkMatch(topicMappingInfo.subCategoryIds, subcategoryId) ||
                    checkMatch(topicMappingInfo.categoryIds, categoryId);
                if (match) {
                    chatTopic = topicMappingInfo.topic;
                    validateLink = topicMappingInfo.checkUrl;
                    validateToken = topicMappingInfo.token;
                    break;
                }
            }
        }

        return {
            chatTopic: chatTopic,
            validateLink: validateLink,
            validateToken: validateToken
        };
    }

    function checkMatch(mappingInfo, checkInfo) {
        if (
            mappingInfo &&
            mappingInfo.ids &&
            mappingInfo.ids.length > 0 &&
            checkInfo &&
            checkInfo.length > 0
        ) {
            var checkItem = checkInfo[0];
            var match = false;
            for (var i = 0; i < mappingInfo.ids.length; i++) {
                var id = mappingInfo.ids[i];
                if (id) {
                    if (mappingInfo.is_regex) {
                        var matchResult = new RegExp(id, 'i').exec(checkItem);
                        match = matchResult && matchResult.length > 0;
                    } else {
                        match = id.toLowerCase() === checkItem.toLowerCase();
                    }
                }

                if (match) {
                    break;
                }
            }
            return match;
        }
        return false;
    }

    function check_mobile_javascript_variable() {
        var global_newegg_variable_mobile = false;
        // @ts-ignore
        if (window.__SITE__ && window.__SITE__.device && window.__SITE__.device == 'm') {
            global_newegg_variable_mobile = true;
        }
        return global_newegg_variable_mobile;
    }

    function buildAvatarInnerHtml(style) {
        var html =
            '<div id="avatar-icon" class="NE-chat-popup not-proactive is-collapsed" style="z-index:9999">' +
            '<div class="NE-chat-header not-proactive" onclick="Chat.loadDom()">' +
            '<figure class="agent-icon"' +
            'style="' +
            style +
            ';">' +
            '<i class="fa fa-user"></i>' +
            '<span id="redTip" class="NE-chat-badge color-red" style="display:none"></span>' +
            '</figure>' +
            '</div>' +
            '</div>';
        return html;
    }
    function getChatStatus() {
        var cookieValue = Chat.readCookie();
        var valueObj = {};
        if (cookieValue !== '') {
            valueObj = JSON.parse(cookieValue);
        }
        var chatStatus = '';
        if (valueObj[Chat.chatSubDomainName]) {
            var expDate = new Date(valueObj[Chat.chatSubDomainName].exp);
            if (expDate > new Date()) {
                chatStatus = valueObj[Chat.chatSubDomainName].data;
            }
        }
        return chatStatus;
    }

    if (!check_mobile_javascript_variable()) {
        window.addEventListener('message', function (e) {
            var iframe = document.getElementById('chat-iframe');
            var chatContainer = document.getElementById('chat-container');
            var chatEntrance = document.getElementById('chat-entrance');
            if (iframe && e.data && e.data.type == 'CHAT') {
                if (e.data.action == 'close' || e.data.action == 'collapse') {
                    if (chatContainer) {
                        chatContainer.style.visibility = 'hidden';
                    }
                    if (chatEntrance) {
                        chatEntrance.style.display = '';
                    }
                } else if (e.data.action == 'showAvatarIcon') {
                    var avatarEl = document.getElementById('avatar-icon');
                    if (chatEntrance && e.data.style) {
                        chatEntrance.innerHTML = buildAvatarInnerHtml(e.data.style);
                    }
                    if (avatarEl && e.data.classes) {
                        avatarEl.classList.add(e.data.classes);
                    }
                } else if (e.data.action == 'showNormalIcon') {
                    if (chatEntrance) {
                        chatEntrance.innerHTML = Chat.buildIconInnerHtml();
                    }
                } else if (e.data.action == 'showRedTip') {
                    var redTip = document.getElementById('redTip');
                    if (redTip) {
                        redTip.style.display = '';
                    }
                } else if (e.data.action == 'removeRedTip') {
                    var redTip = document.getElementById('redTip');
                    if (redTip) {
                        redTip.style.display = 'none';
                    }
                } else if (e.data.action == 'setCookie') {
                    Chat.setCookieValue(
                        Chat.chatSubDomainName,
                        e.data.cookieValue,
                        e.data.cookieExpire
                    );
                }
            }
        });

        var chatstatus = getChatStatus();
        if (
            chatstatus === 'Waiting' ||
            chatstatus === 'Chatting' ||
            chatstatus === 'ChatBotChatting'
        ) {
            var checkResult = checkItemMacthMapping();
            if (checkResult.chatTopic && checkResult.validateLink) {
                setProactivePostMsg();
            }
            Chat.postMsg.noAction = true;
            Chat.loadDom();
            Chat.postMsg.noAction = false;
        } else {
            checkIsProactiveChat();
        }
    }
})();
