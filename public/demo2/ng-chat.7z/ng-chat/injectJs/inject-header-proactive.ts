declare let Biz: any;
declare let jQuery;

var Chat = (function () {
    // var ngChatAddress = 'https://chat.newegg.com/';
    var ngChatAddress = 'http://localhost:8080/';
    // var chatSettingUrl = 'https://ec-apis.newegg.com/HelpSiteCenterService/v1/Contact/Settings';
    var chatSettingUrl = 'http://10.16.75.24:3000/HelpSiteCenterService/v1/Contact/Settings';
    var chatCookieName = 'NV_CustomizedInfoes';
    var chatSubDomainName = 'wschat';

    var item_Subcategory_category_chatTopic_mapping = [
        {
            topic: 'ABS_Customer_Service',
            // checkUrl: 'https://ec-apis.newegg.com/api/purecloud/abscustomer',
            checkUrl: 'https://gqc-onlinechat.newegg.org/api/purecloud/abscustomer',
            token: 'Bearer sPc0wAJJWWFouT0qx36G7Sc7KEOne3gORykLc0QV',
            itemNumbers: {
                ids: ['83-360-[a-zA-Z0-9]{3}', '83-102-[a-zA-Z0-9]{3}'],
                is_regex: true
            }
        },
        {
            topic: 'Software Licensing',
            // checkUrl: 'https://ec-apis.newegg.com/api/purecloud/softlicense',
            checkUrl: 'https://gqc-onlinechat.newegg.org/api/purecloud/softlicense',
            token: 'Bearer sPc0wAJJWWFouT0qx36G7Sc7KEOne3gORykLc0QV',
            categoryIds: { ids: ['785'], is_regex: false },
            subCategoryIds: { ids: ['3003', '539', '3750', '3749', '3748'], is_regex: false }
        }
    ];
    var params = {
        injectionType: 'popup',
        country: countryInCookie(),
        topic: '',
        reason: '',
        category: '',
        type: 1,
        loginName: '',
        encryptedEmailAddress: '',
        encryptedCustomerNumber: '',
        currencyCode: '',
        nvtc: ''
    };
    var postMsg = {
        topic: '',
        reason: '',
        category: '',
        type: 1,
        key: 'chat',
        noAction: false,
        fromHeader: false
    };

    var isProactive = false;
    var isCAN = checkIsCAN();
    function setHeaderPostMsg() {
        Chat.postMsg.topic = 'normalUser';
        Chat.postMsg.category = 'NormalUser';
        Chat.postMsg.reason = '';
        Chat.postMsg.type = 2;
        Chat.postMsg.fromHeader = true;
        Chat.params.topic = 'normalUser';
        Chat.params.category = 'NormalUser';
        Chat.params.reason = '';
        Chat.params.type = 2;
    }

    function getInfoFromCookie() {
        try {
            var cookieList = document.cookie
                .split(';')
                .map(function (s) {
                    return s.trim();
                })
                .filter(function (t) {
                    return t;
                })
                .map(function (c) {
                    var list = c.split('=');
                    return { key: list[0], value: list[1] };
                });
            var otherInfo = cookieList.find(function (t) {
                return t.key == 'NV%5FOTHERINFO';
            });
            if (otherInfo) {
                var otherInfoJson = JSON.parse(decodeURIComponent(otherInfo.value).substr(2));
                var otherInfoDetail = otherInfoJson['Sites'][isCAN ? 'CAN' : 'USA']['Values'];
                if (otherInfoDetail) {
                    params.loginName = otherInfoDetail['si'];
                    params.encryptedEmailAddress = otherInfoDetail['sb'];
                    params.encryptedCustomerNumber = otherInfoDetail['sc'];
                }
            }
            var configInfo = cookieList.find(function (t) {
                return t.key == 'NV%5FCONFIGURATION';
            });
            if (configInfo) {
                var configInfoJson = JSON.parse(decodeURIComponent(configInfo.value).substr(2));
                var configInfoDetail = configInfoJson['Sites'][isCAN ? 'CAN' : 'USA']['Values'];
                params.currencyCode = configInfoDetail['w58'];
            }
            var nvtcInfo = cookieList.find(function (t) {
                return t.key == 'NVTC';
            });
            params.nvtc = nvtcInfo['value'];
        } catch (e) {}
    }
    getInfoFromCookie();

    function invokeHeaderStartChat() {
        if (
            Biz &&
            Biz.Common &&
            Biz.Common.SiteCatalyst &&
            Biz.Common.SiteCatalyst.sendForOnClick
        ) {
            var eVar78Value = '';
            var name = 'header';
            eVar78Value = 'live chat-header-chat with us';
            Biz.Common.SiteCatalyst.sendForOnClick(
                {
                    events: 'event63',
                    eVar78: eVar78Value
                },
                name
            );
        }
        setHeaderPostMsg();
        loadDom();
    }

    function loadDom() {
        var paramsArr = [];
        if (Chat.params != null) {
            Object.keys(Chat.params).forEach(function (key) {
                if (Chat.params[key]) {
                    paramsArr.push(key + '=' + Chat.params[key]);
                }
            });
        }
        var chatContainerHtml =
            '<div id="chat-container" class="chat-container" style="padding:0;position:fixed;right:17px;bottom:17px;left:unset;z-index:99999;border:none; width:340px;height:558.188px; border-radius:4px 4px 3px 3px; box-shadow:0 1px 10px rgba(0,0,0,0.5);">';
        var chatDiv =
            chatContainerHtml +
            '<iframe allow="geolocation" id="chat-iframe" onload="Chat.initialPostMessage()" frameborder="no" src="' +
            ngChatAddress +
            '?' +
            paramsArr.join('&') +
            '" tabindex="0" height="558.188px" width="100%"></iframe>' +
            '</div>';

        var chatContainer = document.getElementById('chat-container');
        if (chatContainer) {
            chatContainer.style.visibility = 'visible';
            var redTip = document.getElementById('redTip');
            if (redTip) {
                redTip.style.display = '';
            }
        } else {
            var $body = jQuery('body');
            $body.append(jQuery(chatDiv));
        }

        Chat.initialPostMessage();

        var chatEntrance = document.getElementById('chat-entrance');
        if (chatEntrance) {
            chatEntrance.style.display = 'none';
        } else {
            buildIconHtml();
            document.getElementById('chat-entrance').style.display = 'none';
        }
    }

    function initialPostMessage() {
        // @ts-ignore
        var chatIFrame = document.getElementById('chat-iframe').contentWindow;
        if (chatIFrame) {
            chatIFrame.postMessage(Chat.postMsg, '*');
        }
    }

    function checkIsCAN() {
        return countryInCookie() == 'CAN';
    }

    function countryInCookie() {
        var cookieName = 'NV%5FW57';
        var result = document.cookie.match('(^|[^;]+)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
        var cookieValue = result ? unescape(result.pop()) : '';
        if (cookieValue) {
            return cookieValue.toUpperCase();
        } else {
            return 'USA';
        }
    }

    function setCookieValue(name, value, min) {
        var cookieValue = readCookie();
        var valueObj = {};
        if (cookieValue !== '') {
            valueObj = JSON.parse(cookieValue);
        }
        if (min < 0) {
            delete valueObj[name];
        } else {
            var expireDate = new Date(new Date().getTime() + min * 60 * 1000);
            if (!valueObj[name]) {
                valueObj[name] = {};
            }
            valueObj[name].data = value;
            valueObj[name].exp = expireDate.getTime();
        }
        var cookieExpireDate = new Date(new Date().getTime() + 1000 * 24 * 60 * 60 * 1000);
        var expire = '; expires=' + cookieExpireDate;
        var domainArray = document.domain.split('.');
        if (domainArray.length > 1) {
            domainArray.shift();
        }
        var domain = '; domain=' + domainArray.join('.');
        var sameSite = '; SameSite=None;';
        if (window.location.protocol === 'https:') {
            sameSite += 'Secure';
        }
        document.cookie =
            chatCookieName + '=' + escape(JSON.stringify(valueObj)) + expire + domain + sameSite;
    }

    function readCookie() {
        var result = document.cookie.match('(^|[^;]+)\\s*' + chatCookieName + '\\s*=\\s*([^;]+)');
        var cookieValue = result ? unescape(result.pop()) : '';
        return cookieValue;
    }

    function buildIconHtml() {
        let css_element = document.createElement('link');
        css_element.setAttribute('rel', 'stylesheet');
        css_element.setAttribute(
            'href',
            'https://c1.neweggimages.com/WebResource/Chat/CSS/chat-icon.css'
        );
        document.body.appendChild(css_element);
        document.body.appendChild(createChatIconNode());
        function createChatIconNode() {
            var e_0 = document.createElement('div');
            e_0.setAttribute('id', 'chat-entrance');
            e_0.innerHTML = buildIconInnerHtml();
            return e_0;
        }
    }

    function buildIconInnerHtml() {
        var html =
            '<div class="slide-in-window at-right on-horizontal chat-entrance is-active">' +
            '<div class="chat-entrance-inner display-flex" onclick="Chat.loadDom()">' +
            '<i class="fa fa-comment-dots" aria-label="Newegg Chat"></i>' +
            '</div></div>';
        return html;
    }

    return {
        setHeaderPostMsg: setHeaderPostMsg,
        params: params,
        postMsg: postMsg,
        chatSubDomainName: chatSubDomainName,
        isCAN: isCAN,
        invokeHeaderStartChat: invokeHeaderStartChat,
        loadDom: loadDom,
        isProactive: isProactive,
        checkIsCAN: checkIsCAN,
        chatSettingUrl: chatSettingUrl,
        item_Subcategory_category_chatTopic_mapping: item_Subcategory_category_chatTopic_mapping,
        buildIconHtml: buildIconHtml,
        buildIconInnerHtml: buildIconInnerHtml,
        countryInCookie: countryInCookie,
        readCookie: readCookie,
        setCookieValue: setCookieValue,
        initialPostMessage: initialPostMessage
    };
})();

(function () {
    var isAddChatTab = false;
    var chatIsClose = '';

    function getCustomerRegionInfo(callback) {
        if (!isAddChatTab) {
            isAddChatTab = true;
            if (chatIsClose === '') {
                // @ts-ignore
                var isCAN = window.Web.Config.SiteCookieInfo.bizUnit === 'CAN';
                if (isCAN) {
                    getCSChatTime('header', callback);
                } else {
                    var cookieCountry = Chat.countryInCookie();
                    getCSChatTime('USA' === cookieCountry ? 'header' : 'intl', callback);
                }
            } else {
                !chatIsClose && callback();
            }
        }
    }

    function getCSChatTime(domain, callback) {
        var authToken = 'Bearer MC3VybiEC3OejsHOaUCmR0hfay227lBgpfT1R8ZF';
        // @ts-ignore
        jQuery.ajax({
            url: Chat.chatSettingUrl + '?domain=' + domain + '&type=C',
            cache: false,
            type: 'Get',
            accepts: 'application/json',
            dataType: 'json',
            async: true,
            timeout: 15000,
            data: {},
            beforeSend: function (request) {
                request.setRequestHeader('Authorization', authToken);
            },
            success: function (chatSetting) {
                chatIsClose = chatSetting && chatSetting.IsClose;
                if (!chatIsClose) {
                    callback && callback.apply();
                }
            },
            error: function (err) {
                console.error(err);
            }
        });
    }

    function showHeaderChat() {
        var displayNonPremierChat = true;

        var pnode = jQuery(
            '.header2020-links.menu-box.is-gray-menu .menu-box-menu .nav-container .nav-container-inner .nav-cell .nav-list:last li:last'
        );
        displayNonPremierChat &&
            jQuery(
                '<li><a class="nav-list-link" onclick="Chat.invokeHeaderStartChat();" href="javascript:void(0)"><i class="fa fa-comments"></i> Chat with Us</a></li>'
            ).insertBefore(pnode);
    }

    function showHeaderChatInAccount() {
        var displayNonPremierChat = true;
        var pnode = jQuery(
            '.header2020-right .header2020-account.is-gray-menu .menu-box-menu .nav-container-inner .nav-cell:last .nav-list:last li:last'
        );
        displayNonPremierChat &&
            jQuery(
                '<li><a class="nav-list-link" onclick="Chat.invokeHeaderStartChat();" href="javascript:void(0)"><i class="fa fa-comments"></i> Chat with Us</a></li>'
            ).insertBefore(pnode);
    }

    function showHeaderChatInNewAccountHeader() {
        var displayNonPremierChat = true;
        var pnode = jQuery(
            'div.header2021-nav.header2021-account .menu-body .menu-list-container .menu-list-container-inner .menu-list-cell:last li:last'
        );
        displayNonPremierChat &&
            jQuery(
                '<li><a class="menu-list-link bg-transparent-lightblue" href="javascript:void(0)" onclick="Chat.invokeHeaderStartChat();" title="Chat with Us"><div class="display-flex align-items-center"><i class="ico ico-comments-alt" aria-label="chat"></i> Chat with Us</div</a></li>'
            ).insertBefore(pnode);
    }

    function registerHeadEvent() {
        var csTab = jQuery('div.header2020-links.menu-box.is-gray-menu');
        var headerTab = jQuery('.header2020-right .header2020-account');
        var newHeaderTab = jQuery('div.header2021-nav.header2021-account');
        var timeOut = null;
        var time = 600;
        if (headerTab.length > 0) {
            headerTab
                .bind('mouseenter', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(getCustomerRegionInfo, time, showHeaderChatInAccount);
                })
                .bind('mouseleave', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(function () {
                        var tabmenu = jQuery('.header2020-right .nav-complex-title .menu-box-menu');
                        if (tabmenu.length == 0) {
                            isAddChatTab = false;
                        }
                    }, time);
                })
                .bind('blur', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(function () {
                        var tabmenu = jQuery('.header2020-right .nav-complex-title .menu-box-menu');
                        if (tabmenu.length == 0) {
                            isAddChatTab = false;
                        }
                    }, time);
                });
        } else if (csTab.length > 0) {
            csTab
                .bind('mouseenter', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(getCustomerRegionInfo, time, showHeaderChat);
                })
                .bind('mouseleave', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(function () {
                        var tabmenu = jQuery(
                            '.header2020-links.menu-box.is-gray-menu .menu-box-menu'
                        );
                        if (tabmenu.length == 0) {
                            isAddChatTab = false;
                        }
                    }, time);
                })
                .bind('blur', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(function () {
                        var tabmenu = jQuery(
                            '.header2020-links.menu-box.is-gray-menu .menu-box-menu'
                        );
                        if (tabmenu.length == 0) {
                            isAddChatTab = false;
                        }
                    }, time);
                });
        } else if (newHeaderTab.length > 0) {
            newHeaderTab
                .bind('mouseenter', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(
                        getCustomerRegionInfo,
                        time,
                        showHeaderChatInNewAccountHeader
                    );
                })
                .bind('mouseleave', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(function () {
                        var tabmenu = jQuery('.header2020-right .nav-complex-title .menu-box-menu');
                        if (tabmenu.length == 0) {
                            isAddChatTab = false;
                        }
                    }, time);
                })
                .bind('blur', function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(function () {
                        var tabmenu = jQuery('.header2020-right .nav-complex-title .menu-box-menu');
                        if (tabmenu.length == 0) {
                            isAddChatTab = false;
                        }
                    }, time);
                });
        }
    }

    function setProactivePostMsg() {
        var checkResult = checkItemMacthMapping();
        Chat.postMsg.topic = checkResult.chatTopic;
        Chat.postMsg.reason =
            // @ts-ignore
            (window.utag_data &&
                window.utag_data.product_web_id &&
                window.utag_data.product_web_id[0]) ||
            '';
        Chat.postMsg.category = checkResult.chatTopic;
        Chat.postMsg.type = 3;
        Chat.params.topic = checkResult.chatTopic;
        Chat.params.reason =
            // @ts-ignore
            (window.utag_data &&
                window.utag_data.product_web_id &&
                window.utag_data.product_web_id[0]) ||
            '';
        Chat.params.category = checkResult.chatTopic;
        Chat.params.type = 3;
    }

    function checkIsProactiveChat() {
        var checkResult = checkItemMacthMapping();
        if (checkResult.chatTopic && checkResult.validateLink) {
            // @ts-ignore
            jQuery.ajax({
                url: checkResult.validateLink,
                cache: false,
                type: 'Get',
                accepts: 'application/json',
                dataType: 'json',
                async: true,
                timeout: 15000,
                data: {},
                beforeSend: function (request) {
                    if (checkResult.validateToken) {
                        request.setRequestHeader('Authorization', checkResult.validateToken);
                    }
                },
                success: function (isCanChat) {
                    if (isCanChat) {
                        setProactivePostMsg();
                        Chat.buildIconHtml();
                        Chat.isProactive = true;
                    }
                },
                error: function (err) {
                    console.error(err);
                }
            });
        }
    }

    function checkItemMacthMapping() {
        var chatTopic = '';
        var validateLink = '';
        var validateToken = '';
        // @ts-ignore
        if (window.utag_data) {
            // @ts-ignore
            var itemNumber = window.utag_data.product_id;
            // @ts-ignore
            var subcategoryId = window.utag_data.product_subcategory_id;
            // @ts-ignore
            var categoryId = window.utag_data.product_category_id;

            for (var i = 0; i < Chat.item_Subcategory_category_chatTopic_mapping.length; i++) {
                var topicMappingInfo = Chat.item_Subcategory_category_chatTopic_mapping[i];

                var match =
                    checkMatch(topicMappingInfo.itemNumbers, itemNumber) ||
                    checkMatch(topicMappingInfo.subCategoryIds, subcategoryId) ||
                    checkMatch(topicMappingInfo.categoryIds, categoryId);
                if (match) {
                    chatTopic = topicMappingInfo.topic;
                    validateLink = topicMappingInfo.checkUrl;
                    validateToken = topicMappingInfo.token;
                    break;
                }
            }
        }

        return {
            chatTopic: chatTopic,
            validateLink: validateLink,
            validateToken: validateToken
        };
    }

    function checkMatch(mappingInfo, checkInfo) {
        if (
            mappingInfo &&
            mappingInfo.ids &&
            mappingInfo.ids.length > 0 &&
            checkInfo &&
            checkInfo.length > 0
        ) {
            var checkItem = checkInfo[0];
            var match = false;
            for (var i = 0; i < mappingInfo.ids.length; i++) {
                var id = mappingInfo.ids[i];
                if (id) {
                    if (mappingInfo.is_regex) {
                        var matchResult = new RegExp(id, 'i').exec(checkItem);
                        match = matchResult && matchResult.length > 0;
                    } else {
                        match = id.toLowerCase() === checkItem.toLowerCase();
                    }
                }

                if (match) {
                    break;
                }
            }
            return match;
        }
        return false;
    }

    function check_mobile_javascript_variable() {
        var global_newegg_variable_mobile = false;
        // @ts-ignore
        if (window.__SITE__ && window.__SITE__.device && window.__SITE__.device == 'm') {
            global_newegg_variable_mobile = true;
        }
        return global_newegg_variable_mobile;
    }

    function buildAvatarInnerHtml(style) {
        var html =
            '<div id="avatar-icon" class="NE-chat-popup not-proactive is-collapsed" style="z-index:9999">' +
            '<div class="NE-chat-header not-proactive" onclick="Chat.loadDom()">' +
            '<figure class="agent-icon"' +
            'style="' +
            style +
            ';">' +
            '<i class="fa fa-user"></i>' +
            '<span id="redTip" class="NE-chat-badge color-red" style="display:none"></span>' +
            '</figure>' +
            '</div>' +
            '</div>';
        return html;
    }
    function getChatStatus() {
        var cookieValue = Chat.readCookie();
        var valueObj = {};
        if (cookieValue !== '') {
            valueObj = JSON.parse(cookieValue);
        }
        var chatStatus = '';
        if (valueObj[Chat.chatSubDomainName]) {
            var expDate = new Date(valueObj[Chat.chatSubDomainName].exp);
            if (expDate > new Date()) {
                chatStatus = valueObj[Chat.chatSubDomainName].data;
            }
        }
        return chatStatus;
    }

    if (!check_mobile_javascript_variable()) {
        window.addEventListener('message', function (e) {
            var iframe = document.getElementById('chat-iframe');
            var chatContainer = document.getElementById('chat-container');
            var chatEntrance = document.getElementById('chat-entrance');
            if (iframe && e.data && e.data.type == 'CHAT') {
                if (e.data.action == 'close') {
                    if (chatContainer) {
                        chatContainer.style.visibility = 'hidden';
                    }
                    if (chatEntrance) {
                        chatEntrance.style.display = '';
                        if (Chat.postMsg.type == 2) {
                            if (Chat.isProactive) {
                                setProactivePostMsg();
                            } else {
                                chatEntrance.remove();
                            }
                        }
                    }
                } else if (e.data.action == 'collapse') {
                    if (chatContainer) {
                        chatContainer.style.visibility = 'hidden';
                    }
                    if (chatEntrance) {
                        chatEntrance.style.display = '';
                    }
                } else if (e.data.action == 'showAvatarIcon') {
                    var avatarEl = document.getElementById('avatar-icon');
                    if (chatEntrance && e.data.style) {
                        chatEntrance.innerHTML = buildAvatarInnerHtml(e.data.style);
                    }
                    if (avatarEl && e.data.classes) {
                        avatarEl.classList.add(e.data.classes);
                    }
                } else if (e.data.action == 'showNormalIcon') {
                    if (chatEntrance) {
                        chatEntrance.innerHTML = Chat.buildIconInnerHtml();
                    }
                } else if (e.data.action == 'showRedTip') {
                    var redTip = document.getElementById('redTip');
                    if (redTip) {
                        redTip.style.display = '';
                    }
                } else if (e.data.action == 'removeRedTip') {
                    var redTip = document.getElementById('redTip');
                    if (redTip) {
                        redTip.style.display = 'none';
                    }
                } else if (e.data.action == 'setCookie') {
                    Chat.setCookieValue(
                        Chat.chatSubDomainName,
                        e.data.cookieValue,
                        e.data.cookieExpire
                    );
                } else if (e.data.action == 'initialHeaderVal') {
                    Chat.postMsg.fromHeader = false;
                }
            }
        });

        registerHeadEvent();

        var chatstatus = getChatStatus();
        if (
            chatstatus === 'Waiting' ||
            chatstatus === 'Chatting' ||
            chatstatus === 'ChatBotChatting'
        ) {
            if (!Chat.isCAN) {
                var checkResult = checkItemMacthMapping();
                if (checkResult.chatTopic && checkResult.validateLink) {
                    setProactivePostMsg();
                }
            }
            Chat.postMsg.noAction = true;
            Chat.loadDom();
            Chat.postMsg.noAction = false;
        } else {
            if (!Chat.isCAN) {
                checkIsProactiveChat();
            }
        }
    }
})();
