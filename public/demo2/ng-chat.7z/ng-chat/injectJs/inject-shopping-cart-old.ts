var check_mobile_javascript_variable = function () {
    var global_newegg_variable_mobile = false;
    if (window.__SITE__ && window.__SITE__.device && window.__SITE__.device == 'm') {
        global_newegg_variable_mobile = true;
    }
    return global_newegg_variable_mobile;
};

if (!check_mobile_javascript_variable()) {
    window.pureCloudChat = (function () {
        var host = '';
        var channel = 'USA';
        var isProactiveChat = false;
        var item_Subcategory_category_chatTopic_mapping = [
            {
                topic: 'ABS_Customer_Service',
                checkUrl: 'https://ec-apis.newegg.com/api/purecloud/abscustomer',
                token: 'Bearer sPc0wAJJWWFouT0qx36G7Sc7KEOne3gORykLc0QV',
                itemNumbers: { ids: ['83-360-[a-zA-Z0-9]{3}', '83-102-[a-zA-Z0-9]{3}'], is_regex: true }
            },
            {
                topic: 'Software Licensing',
                checkUrl: 'https://ec-apis.newegg.com/api/purecloud/softlicense',
                token: 'Bearer sPc0wAJJWWFouT0qx36G7Sc7KEOne3gORykLc0QV',
                categoryIds: { ids: ['785'], is_regex: false },
                subCategoryIds: { ids: ['3003', '539', '3750', '3749', '3748'], is_regex: false }
            }
        ];

        var invokeHeaderStartChat = function (topic, isFromHeader) {
            var chatiFrameElement = document.getElementById('chatiframe');
            if (chatiFrameElement == null) {
                init(null);
                pureCloudChat.iframeData = {
                    key: "startChat",
                    value: {
                        topic: topic,
                        isFromHeader: isFromHeader ? isFromHeader : false
                    }
                };
            } else {
                var chatIFrame = chatiFrameElement.contentWindow;
                chatIFrame.postMessage({
                    key: "startChat",
                    value: {
                        topic: topic,
                        isFromHeader: isFromHeader ? isFromHeader : false
                    }
                },
                    "*");
            }

        };

        var init = function (params) {
            var paramsArr = [];
            if (params == null) {
                params = {
                    "proactiveFirstIn": false
                }
            }
            if (params != null) {
                Object.keys(params).forEach(function (key) {
                    paramsArr.push(key + '=' + params[key])
                })
            }

            var loadDom = function () {
                var chatContainerHtml = '<div id="chatContainer" class="chat-container" style="padding:0;position:fixed;right:17px;bottom:17px;left:unset;z-index:99999;border:none; width:340px; border-radius:4px 4px 3px 3px; box-shadow:0 1px 10px rgba(0,0,0,0.5);display:none">'
                var chatDiv = chatContainerHtml + '<iframe allow="geolocation" id="chatiframe" onload="pureCloudChat.chatiFrameLoad(pureCloudChat.iframeData)" frameborder="no" src="' + pureCloudChat.host + 'PureCloudWebChat?channel=' + pureCloudChat.channel + (pureCloudChat.isProactiveChat ? '&type=licensing' : '&type=other') + (params != null && paramsArr.length > 0 ? '&' + paramsArr.join("&") : '') + '" tabindex="0" height="521px" width="100%"></iframe>' + '</div>';
                var $body = jQuery('body');
                $body.append(jQuery(chatDiv));
            };
            loadDom();
        }

        var chatiFrameLoad = function (data) {
            if (data && data.key) {
                var chatIFrame = document.getElementById('chatiframe').contentWindow;
                chatIFrame.postMessage(data, "*");
            }
            data = {};
        }

        var checkIsProactiveChat = function () {
            var checkResult = checkItemMacthMapping();
            if (checkResult.chatTopic && checkResult.validateLink) {
                jQuery.ajax({
                    url: checkResult.validateLink,
                    cache: false,
                    type: "Get",
                    accepts: 'application/json',
                    dataType: "json",
                    async: true,
                    timeout: 15000,
                    data: {},
                    beforeSend: function (request) {
                        if (checkResult.validateToken) {
                            request.setRequestHeader('Authorization', checkResult.validateToken);
                        }

                    },
                    success: function (isCanChat) {
                        if (isCanChat) {
                            pureCloudChat.isProactiveChat = true;
                            pureCloudChat.init({
                                "proactiveFirstIn": true
                            });
                            pureCloudChat.iframeData = {
                                key: "startChat",
                                value: {
                                    type: "licensing",
                                    topic: checkResult.chatTopic,
                                    reason: window.utag_data && window.utag_data.product_web_id && utag_data.product_web_id[0] || ''
                                }
                            };
                        }
                    },
                    error: function (err) {
                        console.error(err);
                    }
                })
            }
        }

        function checkItemMacthMapping() {
            var chatTopic = '';
            var validateLink = '';
            var validateToken = '';
            if (window.utag_data) {
                var itemNumber = window.utag_data.product_id;
                var subcategoryId = utag_data.product_subcategory_id;
                var categoryId = utag_data.product_category_id;
                
                for (var i = 0; i < item_Subcategory_category_chatTopic_mapping.length; i++) {
                    var topicMappingInfo = item_Subcategory_category_chatTopic_mapping[i];
                    
                    var match = checkMatch(topicMappingInfo.itemNumbers, itemNumber) ||
                                checkMatch(topicMappingInfo.subCategoryIds, subcategoryId) || 
                                checkMatch(topicMappingInfo.categoryIds, categoryId);
                    if (match) {
                        chatTopic = topicMappingInfo.topic;
                        validateLink = topicMappingInfo.checkUrl;
                        validateToken = topicMappingInfo.token;
                        break;
                    }
                }
            }

            return {
                chatTopic: chatTopic,
                validateLink: validateLink,
                validateToken: validateToken
            }
        }

        function checkMatch(mappingInfo, checkInfo) {
            if (mappingInfo && mappingInfo.ids && mappingInfo.ids.length > 0 && checkInfo && checkInfo.length > 0) {
                var checkItem = checkInfo[0];
                var match = false;
                for (var i = 0; i < mappingInfo.ids.length; i++) {
                    var id = mappingInfo.ids[i];
                    if (id) {
                        if (mappingInfo.is_regex) {
                            var matchResult = new RegExp(id, 'i').exec(checkItem);
                            match = matchResult && matchResult.length > 0
                        } else {
                            match = id.toLowerCase() === checkItem.toLowerCase();
                        }
                    }
                    
                    if (match) {
                        break;
                    }
                }
                return match;
            }
            return false;
        }

        return {
            headerChat: invokeHeaderStartChat,
            init: init,
            chatiFrameLoad: chatiFrameLoad,
            host: host,
            channel: channel,
            iframeData: {},
            checkIsProactiveChat: checkIsProactiveChat,
            isProactiveChat: isProactiveChat,
            checkItemMacthMapping: checkItemMacthMapping
        };
    })();

    (function () {
        var kbHelpCAN = 'https://help.newegg.ca/';
        var kbHelpCom = 'https://help.newegg.com/';
        var chatSettingUrl = "https://ec-apis.newegg.com/HelpSiteCenterService/v1/Contact/Settings";
        var authToken = 'Bearer MC3VybiEC3OejsHOaUCmR0hfay227lBgpfT1R8ZF';

        var isCAN = (function () {
            var cookieName = "NV%5FW57";
            var result = document.cookie.match("(^|[^;]+)\\s*" + cookieName + "\\s*=\\s*([^;]+)");
            var cookieValue = result ? unescape(result.pop()) : "USA";
            return cookieValue.toUpperCase() == "CAN"
        })();

        var isAddChatTab = false;
        var chatIsClose = '';
        pureCloudChat.host = getLink();

        function setChatTabFlag(isAdd) {
            isAddChatTab = isAdd;
        }

        function getCustomerRegionInfo(callback) {
            if (!isAddChatTab) {
                setChatTabFlag(true);
                if (chatIsClose === '') {
                    var isCAN = Web.Config.SiteCookieInfo.bizUnit === "CAN";
                    if (isCAN) {
                        getCSChatTime('header', callback);
                    } else {
                        var cookieCountry = countryInCookie();
                        getCSChatTime("USA" === cookieCountry ? 'header' : 'intl', callback);
                    }
                } else {
                    !chatIsClose && callback();
                }
            }
        }

        function getCSChatTime(domain, callback) {
            jQuery.ajax({
                url: chatSettingUrl + '?domain=' + domain + '&type=C',
                cache: false,
                type: "Get",
                accepts: 'application/json',
                dataType: "json",
                async: true,
                timeout: 15000,
                data: {},
                beforeSend: function (request) {
                    request.setRequestHeader('Authorization', authToken);
                },
                success: function (chatSetting) {
                    chatIsClose = chatSetting && chatSetting.IsClose
                    if (!chatIsClose) {
                        callback && callback.apply();
                    }
                },
                error: function (err) {
                    console.error(err);
                }
            });
        }

        function showHeaderChat() {
            var displayNonPremierChat = true;
            var link = pureCloudChat.host + 'contactus';

            var pnode = jQuery(".header2020-links.menu-box.is-gray-menu .menu-box-menu .nav-container .nav-container-inner .nav-cell .nav-list:last li:last");
            displayNonPremierChat && jQuery('<li><a class="nav-list-link" onclick="pureCloudChat.headerChat(\'normalUser\',true);" href="javascript:void(0)"><i class="fa fa-comments"></i> Chat with Us</a></li>').insertBefore(pnode);
        }

        function showHeaderChatInAccount() {
            var displayNonPremierChat = true;
            var pnode = jQuery(".header2020-right .header2020-account.is-gray-menu .menu-box-menu .nav-container-inner .nav-cell:last .nav-list:last li:last");
            displayNonPremierChat && jQuery('<li><a class="nav-list-link" onclick="pureCloudChat.headerChat(\'normalUser\',true);" href="javascript:void(0)"><i class="fa fa-comments"></i> Chat with Us</a></li>').insertBefore(pnode);
        }

        function showHeaderChatInNewAccountHeader() {
            var displayNonPremierChat = true;
            var pnode = jQuery("div.header2021-nav.header2021-account .menu-body .menu-list-container .menu-list-container-inner .menu-list-cell:last li:last");
            displayNonPremierChat && jQuery('<li><a class="menu-list-link bg-transparent-lightblue" href="javascript:void(0)" onclick="pureCloudChat.headerChat(\'normalUser\',true);" title="Chat with Us"><div class="display-flex align-items-center"><i class="ico ico-comments-alt" aria-label="chat"></i> Chat with Us</div</a></li>').insertBefore(pnode);
        }

        function getLink() {
            var result;
            if (isCAN) {
                pureCloudChat.channel = 'CAN';
                result = kbHelpCAN;
            } else {
                pureCloudChat.channel = 'USA';
                result = kbHelpCom;
            }

            return result;
        }

        function readCookie() {
            var cookieName = "NV_CustomizedInfoes";
            var subDomainName = "wschat";
            var result = document.cookie.match("(^|[^;]+)\\s*" + cookieName + "\\s*=\\s*([^;]+)");
            var cookieValue = result ? unescape(result.pop()) : "";
            var valueObj = {};
            if (cookieValue !== '') {
                valueObj = JSON.parse(cookieValue);
            }
            var chatStatus = '';
            if (valueObj[subDomainName]) {
                var expDate = new Date(valueObj[subDomainName].exp);
                if (expDate > new Date()) {
                    chatStatus = valueObj[subDomainName].data;
                }
            }
            return chatStatus;
        }

        function countryInCookie() {
            var cookieName = "NV%5FW57";
            var result = document.cookie.match("(^|[^;]+)\\s*" + cookieName + "\\s*=\\s*([^;]+)");
            var cookieValue = result ? unescape(result.pop()) : "";
            if (cookieValue) {
                return cookieValue.toUpperCase();
            } else {
                return 'USA'
            }
        }

        window.addEventListener("message",
            function (e) {
                var iframe = document.getElementById('chatiframe');
                var chatContainer = document.getElementById('chatContainer');
                if (e.data.key === 'collapsed' && iframe) {
                    iframe.height = '80px';
                    chatContainer.style.borderRadius = '';
                    chatContainer.style.boxShadow = '';
                    chatContainer.style.width = '100%';
                    chatContainer.style.display = '';
                    chatContainer.style.right = '0px';
                    chatContainer.style.bottom = '-4px';
                    chatContainer.style.height = '';
                } else if (e.data.key === 'show' && iframe) {
                    iframe.height = '521px';
                    chatContainer.style.borderRadius = '4px 4px 3px 3px';
                    chatContainer.style.boxShadow = '0 1px 10px rgba(0,0,0,0.5)';
                    chatContainer.style.width = '340px';
                    chatContainer.style.height = '521px';
                    chatContainer.style.bottom = '17px';
                    chatContainer.style.right = '17px';
                    chatContainer.style.display = '';
                } else if (e.data.key === 'hidden' && iframe) {
                    iframe.height = '0px';
                    chatContainer.style.display = 'none';
                    chatContainer.style.right = '0px';
                    chatContainer.style.bottom = '-4px';
                    chatContainer.style.height = '';
                }
            });

        var csTab = jQuery('div.header2020-links.menu-box.is-gray-menu');
        var headerTab = jQuery(".header2020-right .header2020-account");
        var newHeaderTab = jQuery('div.header2021-nav.header2021-account');
        var timeOut = null;
        var time = 600;
        if (headerTab.length > 0) {
            headerTab.bind('mouseenter',
                function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(getCustomerRegionInfo, time, showHeaderChatInAccount);
                }).bind('mouseleave',
                    function () {
                        clearTimeout(timeOut);
                        timeOut = setTimeout(function () {
                            var tabmenu = jQuery(".header2020-right .nav-complex-title .menu-box-menu");
                            if (tabmenu.length == 0) {
                                setChatTabFlag(false);
                            }
                        },
                            time)
                    }).bind('blur',
                        function () {
                            clearTimeout(timeOut);
                            timeOut = setTimeout(function () {
                                var tabmenu = jQuery(".header2020-right .nav-complex-title .menu-box-menu");
                                if (tabmenu.length == 0) {
                                    setChatTabFlag(false);
                                }
                            },
                                time)
                        })
        } else if (csTab.length > 0) {
            csTab.bind('mouseenter',
                function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(getCustomerRegionInfo, time, showHeaderChat);
                }).bind('mouseleave',
                    function () {
                        clearTimeout(timeOut);
                        timeOut = setTimeout(function () {
                            var tabmenu = jQuery(".header2020-links.menu-box.is-gray-menu .menu-box-menu");
                            if (tabmenu.length == 0) {
                                setChatTabFlag(false);
                            }
                        },
                            time)

                    }).bind('blur',
                        function () {
                            clearTimeout(timeOut);
                            timeOut = setTimeout(function () {
                                var tabmenu = jQuery(".header2020-links.menu-box.is-gray-menu .menu-box-menu");
                                if (tabmenu.length == 0) {
                                    setChatTabFlag(false);
                                }
                            },
                                time)
                        });
        } else if (newHeaderTab.length > 0) {
            newHeaderTab.bind('mouseenter',
                function () {
                    clearTimeout(timeOut);
                    timeOut = setTimeout(getCustomerRegionInfo, time, showHeaderChatInNewAccountHeader);
                }).bind('mouseleave',
                    function () {
                        clearTimeout(timeOut);
                        timeOut = setTimeout(function () {
                            var tabmenu = jQuery(".header2020-right .nav-complex-title .menu-box-menu");
                            if (tabmenu.length == 0) {
                                setChatTabFlag(false);
                            }
                        },
                            time)
                    }).bind('blur',
                        function () {
                            clearTimeout(timeOut);
                            timeOut = setTimeout(function () {
                                var tabmenu = jQuery(".header2020-right .nav-complex-title .menu-box-menu");
                                if (tabmenu.length == 0) {
                                    setChatTabFlag(false);
                                }
                            },
                                time)
                        })
        }

        var chatstatus = readCookie();
        if (chatstatus === 'Waiting' || chatstatus === 'Chating' || chatstatus === 'ChatBotChating') {
            if (!isCAN) {
                var checkResult = pureCloudChat.checkItemMacthMapping();
                if (checkResult.chatTopic && checkResult.validateLink) {
                    pureCloudChat.isProactiveChat = true;
                    pureCloudChat.iframeData = {
                        key: "startChat",
                        value: {
                            type: "licensing",
                            topic: checkResult.chatTopic,
                            reason: window.utag_data && window.utag_data.product_web_id && utag_data.product_web_id[0] || ''
                        }
                    };
                }
            } 
            pureCloudChat.init(null);

        } else {
            if (!isCAN) {
                pureCloudChat.checkIsProactiveChat();
            }
        }
    })();
}
(function () {
    if (__initialState__.SummaryInfo.GrandTotal < 500) {
        return;
    }

    jQuery.ajax({
        url: "https://ec-apis.newegg.com/HelpSiteCenterService/v1/Contact/Settings?domain=usa&type=c",
        cache: false,
        type: "Get",
        accepts: 'application/json',
        dataType: "json",
        async: true,
        timeout: 15000,
        data: {},
        beforeSend: function (request) {
            request.setRequestHeader('Authorization', 'Bearer MC3VybiEC3OejsHOaUCmR0hfay227lBgpfT1R8ZF');
        },
        success: function (chatSetting) {
            if(chatSetting && !chatSetting.IsClose){
                window.setTimeout(CheckIdleTime, 1000);
            }
        },
        error: function (err) {
            console.error(err);
        }
    });

    var IDLE_TIMEOUT = 10; //seconds

    var _idleSecondsCounter = 0;
    /*
    document.onclick = function () {
        _idleSecondsCounter = 0;
    };

    document.onmousemove = function () {
        _idleSecondsCounter = 0;
    };

    document.onkeypress = function () {
        _idleSecondsCounter = 0;
    };
    */
    var istest = window.location && window.location.search && window.location.search.includes('__testctest__');
    if (istest) {
        IDLE_TIMEOUT = 10;
    }

    

    function CheckIdleTime() {
        _idleSecondsCounter++;

        if (istest) {
            console.log(IDLE_TIMEOUT - _idleSecondsCounter);
        }

        if (_idleSecondsCounter >= IDLE_TIMEOUT) {

            jQuery("head").append("<link id='sidewindow' href='https://c1.neweggimages.com/WebResource/Themes/Secure/CSS/slide_in_window.css' type='text/css' rel='stylesheet' />");
            var chatentrance = jQuery(`<div id="Chat_Entrance" class="slide-in-window at-right on-horizontal chat-entrance is-active">
                                            <div class="chat-entrance-inner display-flex">
                                                <i class="fa fa-comment-dots" aria-label="Newegg Chat"></i>
                                                <div class="chat-entrance-text">
                                                    <strong>Got a question?</strong>
                                                    <span>We are here to help!</span>
                                                </div>
                                            </div>
                                        </div>`);
            jQuery(chatentrance).appendTo(jQuery('.page-content').parent());
            jQuery('.chat-entrance-inner.display-flex').click(
                function () {
                    pureCloudChat.headerChat('Checkout Reminder',false);
                    jQuery(this).remove();
                }
            );

        } else {
            window.setTimeout(CheckIdleTime, 1000);
        }
    }
})();
