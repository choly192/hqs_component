(function () {
    if (__initialState__.SummaryInfo.GrandTotal < 500) {
        return;
    }

    jQuery.ajax({
        url:
            'https://ec-apis.newegg.com/HelpSiteCenterService/v1/Contact/Settings?domain=usa&type=c',
        cache: false,
        type: 'Get',
        accepts: 'application/json',
        dataType: 'json',
        async: true,
        timeout: 15000,
        data: {},
        beforeSend: function (request) {
            request.setRequestHeader(
                'Authorization',
                'Bearer MC3VybiEC3OejsHOaUCmR0hfay227lBgpfT1R8ZF'
            );
        },
        success: function (chatSetting) {
            if (chatSetting && !chatSetting.IsClose) {
                Chat.params.type = 2;
                Chat.params.topic = 'Checkout Reminder';
                Chat.params.category = 'Checkout Reminder';
                Chat.postMsg = {
                    type: 2,
                    topic: 'Checkout Reminder',
                    category: 'Checkout Reminder',
                    key: 'chat',
                    noAction: false,
                    fromHeader: true
                };
                window.setTimeout(CheckIdleTime, 1000);
            }
        },
        error: function (err) {
            console.error(err);
        }
    });

    var IDLE_TIMEOUT = 180; //seconds

    var _idleSecondsCounter = 0;

    var istest =
        window.location &&
        window.location.search &&
        window.location.search.includes('__testctest__');
    if (istest) {
        IDLE_TIMEOUT = 10;
    }

    function CheckIdleTime() {
        _idleSecondsCounter++;

        if (istest) {
            console.log(IDLE_TIMEOUT - _idleSecondsCounter);
        }

        if (_idleSecondsCounter >= IDLE_TIMEOUT) {
            window.addEventListener('message', function (e) {
                var iframe = document.getElementById('chat-iframe');
                var chatContainer = document.getElementById('chat-container');
                var chatEntrance = document.getElementById('chat-entrance');
                if (iframe && e.data && e.data.type == 'CHAT') {
                    if (e.data.action == 'close') {
                        if (chatContainer) {
                            chatContainer.style.visibility = 'hidden';
                        }
                        if (chatEntrance) {
                            chatEntrance.style.display = '';
                            chatEntrance.remove();
                        }
                    }
                }
            });

            Chat.buildIconHtml();
            jQuery('.chat-entrance-inner.display-flex').click(function () {
                Biz &&
                    Biz.Common &&
                    Biz.Common.SiteCatalyst &&
                    Biz.Common.SiteCatalyst.sendForOnClick(
                        {
                            events: 'event63',
                            eVar78: utag_data.page_name.concat('-', 'chat-click')
                        },
                        'click'
                    );
                jQuery(this).remove();
            });
            Biz &&
                Biz.Common &&
                Biz.Common.SiteCatalyst &&
                Biz.Common.SiteCatalyst.sendForOnClick(
                    {
                        events: 'event63',
                        eVar78: utag_data.page_name.concat('-', 'chat-remind')
                    },
                    'impression'
                );
        } else {
            window.setTimeout(CheckIdleTime, 1000);
        }
    }
})();
