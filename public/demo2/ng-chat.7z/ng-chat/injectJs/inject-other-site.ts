declare let Biz: any;
declare let jQuery;

var Chat = (function () {
    // var ngChatAddress = 'https://chat.newegg.com/';
    var ngChatAddress = 'http://localhost:8080/';
    var chatCookieName = 'NV_CustomizedInfoes';
    var chatSubDomainName = 'wschat';

    var params = {
        injectionType: 'popup',
        country: 'USB',
        type: 1
    };
    var postMsg = {
        type: 1,
        key: 'chat',
        siteCookie: document.cookie,
        noAction: false
    };

    function loadDom() {
        var paramsArr = [];
        if (Chat.params != null) {
            Object.keys(Chat.params).forEach(function (key) {
                if (params[key]) {
                    paramsArr.push(key + '=' + params[key]);
                }
            });
        }
        var chatContainerHtml =
            '<div id="chat-container" class="chat-container" style="padding:0;position:fixed;right:17px;bottom:17px;left:unset;z-index:99999;border:none; width:340px; border-radius:4px 4px 3px 3px; box-shadow:0 1px 10px rgba(0,0,0,0.5);">';
        var chatDiv =
            chatContainerHtml +
            '<iframe allow="geolocation" id="chat-iframe" onload="Chat.initialPostMessage(false)" frameborder="no" src="' +
            ngChatAddress +
            '?' +
            paramsArr.join('&') +
            '" tabindex="0" height="521px" width="100%"></iframe>' +
            '</div>';

        var chatContainer = document.getElementById('chat-container');
        if (chatContainer) {
            chatContainer.style.visibility = 'visible';
            var redTip = document.getElementById('redTip');
            if (redTip) {
                redTip.style.display = '';
            }
        } else {
            var $body = jQuery('body');
            $body.append(jQuery(chatDiv));
        }

        Chat.initialPostMessage(true);

        var chatEntrance = document.getElementById('chat-entrance');
        if (chatEntrance) {
            chatEntrance.style.display = 'none';
        } else {
            buildIconHtml();
            document.getElementById('chat-entrance').style.display = 'none';
        }
        document.getElementById('Itc_Chat_Button').style.display = 'none';
    }

    function initialPostMessage(noCookie) {
        // @ts-ignore
        var chatIFrame = document.getElementById('chat-iframe').contentWindow;
        if (chatIFrame) {
            if (noCookie) {
                var msg = Object.assign({}, Chat.postMsg);
                msg.siteCookie = '';
                chatIFrame.postMessage(msg, '*');
            } else {
                chatIFrame.postMessage(Chat.postMsg, '*');
            }
        }
    }

    function setCookieValue(name, value, min) {
        var cookieValue = readCookie();
        var valueObj = {};
        if (cookieValue !== '') {
            valueObj = JSON.parse(cookieValue);
        }
        if (min < 0) {
            delete valueObj[name];
        } else {
            var expireDate = new Date(new Date().getTime() + min * 60 * 1000);
            if (!valueObj[name]) {
                valueObj[name] = {};
            }
            valueObj[name].data = value;
            valueObj[name].exp = expireDate.getTime();
        }
        var cookieExpireDate = new Date(new Date().getTime() + 1000 * 24 * 60 * 60 * 1000);
        var expire = '; expires=' + cookieExpireDate;
        var domainArray = document.domain.split('.');
        if (domainArray.length > 1) {
            domainArray.shift();
        }
        var domain = '; domain=' + domainArray.join('.');
        var sameSite = '; SameSite=None;';
        if (window.location.protocol === 'https:') {
            sameSite += 'Secure';
        }
        document.cookie =
            chatCookieName + '=' + escape(JSON.stringify(valueObj)) + expire + domain + sameSite;
    }

    function readCookie() {
        var result = document.cookie.match('(^|[^;]+)\\s*' + chatCookieName + '\\s*=\\s*([^;]+)');
        var cookieValue = result ? unescape(result.pop()) : '';
        return cookieValue;
    }

    function buildIconHtml() {
        let css_element = document.createElement('link');
        css_element.setAttribute('rel', 'stylesheet');
        css_element.setAttribute(
            'href',
            'https://c1.neweggimages.com/WebResource/Chat/CSS/chat-icon.css'
        );
        document.body.appendChild(css_element);
        document.body.appendChild(createChatIconNode());
        function createChatIconNode() {
            var e_0 = document.createElement('div');
            e_0.setAttribute('id', 'chat-entrance');
            e_0.innerHTML = buildIconInnerHtml();
            return e_0;
        }
    }

    function buildIconInnerHtml() {
        var html =
            '<div class="slide-in-window at-right on-horizontal chat-entrance is-active">' +
            '<div class="chat-entrance-inner display-flex" onclick="Chat.loadDom()">' +
            '<i class="fa fa-comment-dots" aria-label="Newegg Chat"></i>' +
            '</div></div>';
        return html;
    }

    return {
        params: params,
        postMsg: postMsg,
        chatSubDomainName: chatSubDomainName,
        loadDom: loadDom,
        buildIconHtml: buildIconHtml,
        buildIconInnerHtml: buildIconInnerHtml,
        readCookie: readCookie,
        setCookieValue: setCookieValue,
        initialPostMessage: initialPostMessage
    };
})();

(function () {
    function check_mobile_javascript_variable() {
        var global_newegg_variable_mobile = false;
        // @ts-ignore
        if (window.__SITE__ && window.__SITE__.device && window.__SITE__.device == 'm') {
            global_newegg_variable_mobile = true;
        }
        return global_newegg_variable_mobile;
    }

    function buildAvatarInnerHtml(style) {
        var html =
            '<div id="avatar-icon" class="NE-chat-popup not-proactive is-collapsed" style="z-index:9999">' +
            '<div class="NE-chat-header not-proactive" onclick="Chat.loadDom()">' +
            '<figure class="agent-icon"' +
            'style="' +
            style +
            ';">' +
            '<i class="fa fa-user"></i>' +
            '<span id="redTip" class="NE-chat-badge color-red" style="display:none"></span>' +
            '</figure>' +
            '</div>' +
            '</div>';
        return html;
    }
    function getChatStatus() {
        var cookieValue = Chat.readCookie();
        var valueObj = {};
        if (cookieValue !== '') {
            valueObj = JSON.parse(cookieValue);
        }
        var chatStatus = '';
        if (valueObj[Chat.chatSubDomainName]) {
            var expDate = new Date(valueObj[Chat.chatSubDomainName].exp);
            if (expDate > new Date()) {
                chatStatus = valueObj[Chat.chatSubDomainName].data;
            }
        }
        return chatStatus;
    }

    if (!check_mobile_javascript_variable()) {
        window.addEventListener('message', function (e) {
            var iframe = document.getElementById('chat-iframe');
            var chatContainer = document.getElementById('chat-container');
            var chatEntrance = document.getElementById('chat-entrance');
            if (iframe && e.data && e.data.type == 'CHAT') {
                if (e.data.action == 'close') {
                    if (chatContainer) {
                        chatContainer.style.visibility = 'hidden';
                    }
                    if (chatEntrance) {
                        chatEntrance.style.display = '';
                    }
                    document.getElementById('Itc_Chat_Button').style.display = '';
                } else if (e.data.action == 'collapse') {
                    if (chatContainer) {
                        chatContainer.style.visibility = 'hidden';
                    }
                    if (chatEntrance) {
                        chatEntrance.style.display = '';
                    }
                } else if (e.data.action == 'showAvatarIcon') {
                    var avatarEl = document.getElementById('avatar-icon');
                    if (chatEntrance && e.data.style) {
                        chatEntrance.innerHTML = buildAvatarInnerHtml(e.data.style);
                    }
                    if (avatarEl && e.data.classes) {
                        avatarEl.classList.add(e.data.classes);
                    }
                } else if (e.data.action == 'showNormalIcon') {
                    if (chatEntrance) {
                        chatEntrance.innerHTML = Chat.buildIconInnerHtml();
                    }
                } else if (e.data.action == 'showRedTip') {
                    var redTip = document.getElementById('redTip');
                    if (redTip) {
                        redTip.style.display = '';
                    }
                } else if (e.data.action == 'removeRedTip') {
                    var redTip = document.getElementById('redTip');
                    if (redTip) {
                        redTip.style.display = 'none';
                    }
                } else if (e.data.action == 'setCookie') {
                    Chat.setCookieValue(
                        Chat.chatSubDomainName,
                        e.data.cookieValue,
                        e.data.cookieExpire
                    );
                }
            }
        });

        var chatstatus = getChatStatus();
        if (
            chatstatus === 'Waiting' ||
            chatstatus === 'Chatting' ||
            chatstatus === 'ChatBotChatting'
        ) {
            Chat.postMsg.noAction = true;
            Chat.loadDom();
            Chat.postMsg.noAction = false;
        }
        Chat.buildIconHtml();
    }
})();
