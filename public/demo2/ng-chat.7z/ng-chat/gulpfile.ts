// import gulp from 'gulp';

// import { buildScript, buildServer } from './tools';


// exports.start = gulp.series(buildScript, buildServer);


import { join } from 'path';
import * as utils from './tools/utils/load_tasks';

const taskPath = join(__dirname,'tools', 'tasks', 'chat');
const compositeConfig = join(__dirname,'tools', 'config', 'chat.task.json');

utils.loadTasks(taskPath);
utils.loadCompositeTasks(compositeConfig);
