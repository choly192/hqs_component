import log from 'fancy-log';
import colors from 'ansi-colors';
import { existsSync, readdirSync, lstatSync, readFileSync } from 'fs';
import { join } from 'path';
import gulp from 'gulp';
import runSequence from 'gulp4-run-sequence';
import isStream from 'isstream';
import { flatten } from 'lodash';

import { Task } from '../tasks/basicTasks';

export function loadTasks(path: string): void {
    if (!existsSync(path)) {
        log(`Cannot find tasks folder: ${colors.red(path)}`);
    }

    log(`Loading tasks folder: ${colors.yellow(path)}`);
    const taskNames = walk(path);
    taskNames.forEach((task) => registerTask(task, path));
}

export function loadCompositeTasks(projectTasksFile: string): void {
    let projectTasks: any;
    try {
        projectTasks = JSON.parse(readFileSync(projectTasksFile).toString());
    } catch (e) {
        log(`Cannot load the task configuration files: ${e.toString()}`);
        return;
    }

    const invalid = validateTasks(projectTasks);
    if (invalid && invalid.length) {
        const errorMessage = getInvalidTaskErrorMessage(invalid as Array<string>, projectTasksFile);
        log(errorMessage);
        process.exit(1);
    }

    const mergedTasks = Object.assign({}, projectTasks);
    registerTasks(mergedTasks);
}

function walk(path: string): string[] {
    const files = readdirSync(path);
    const taskExtendRegex = /\.[tj]s$/;
    return files
        .map((file) => {
            const currentPath = join(path, file);
            if (lstatSync(currentPath).isFile() && taskExtendRegex.test(file)) {
                return file.replace(taskExtendRegex, '');
            }
            return '';
        })
        .filter(Boolean);
}

function normalizeTask(task: any, taskName: string): Task {
    const _task = task.default || task;

    if (_task instanceof Task) {
        return _task;
    }

    if (_task.prototype && _task.prototype instanceof Task) {
        return new _task();
    }

    if (typeof _task === 'function') {
        return new (class AnonTask extends Task {
            run(done: any) {
                if (_task.length > 0) {
                    return _task(done);
                }
                const taskReturnedValue = _task();
                if (isStream(taskReturnedValue)) {
                    return taskReturnedValue;
                }

                done();
            }
        })();
    }

    throw new Error(
        `${taskName} should be instance of the class Task, a function or a class which extends Task.`,
    );
}

function registerTask(taskName: string, path: string): void {
    const taskPath = join(path, taskName);

    gulp.task(taskName, (done: any) => {
        const task = normalizeTask(require(taskPath), taskName);

        if (!task.shallRun()) {
            return done();
        }

        const result = task.run(done);
        if (result && typeof result.catch === 'function') {
            result.catch((e: any) => {
                log(`Error while running ${taskPath}`, e);
            });
        }
        return result;
    });
}

function validateTasks(tasks: any) {
    return Object.keys(tasks)
        .map((task) => {
            if (
                !tasks[task] ||
                !Array.isArray(tasks[task]) ||
                flatten(tasks[task]).some((t) => typeof t !== 'string')
            ) {
                return task;
            }
            return null;
        })
        .filter((task) => !!task);
}

function getInvalidTaskErrorMessage(invalid: string[], file: string) {
    let error = `Invalid configuration in "${file}. `;
    if (invalid.length === 1) {
        error += 'Task';
    } else {
        error += 'Tasks';
    }
    error += ` ${invalid.map((t: any) => `"${t}"`).join(', ')} do not have proper format.`;
    return error;
}

function registerTasks(tasks: any): void {
    // console.log('tasks', tasks);
    Object.keys(tasks)
      .forEach((t: string) => {
        gulp.task(t, (done: any) => runSequence.apply(null, [...tasks[t], done]));
      });
  }