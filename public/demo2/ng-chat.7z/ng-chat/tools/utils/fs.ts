import fs from 'fs';
import path from 'path';
import mkdirp from 'mkdirp';
import rimraf from 'rimraf';
import glob from 'glob';

export const mkdir = async (path: string): Promise<boolean> =>
    new Promise<boolean>((resolve, reject) => {
        mkdirp(path, (err) => {
            return err ? resolve(false) : resolve(true);
        });
    });

export const writeFile = async (file: string, contents: string | Buffer): Promise<boolean> =>
    new Promise<boolean>((resolve, reject) => {
        mkdir(path.parse(file).dir).then(() => {
            fs.writeFile(file, contents, 'utf8', (err) => (err ? resolve(false) : resolve(true)));
        });
    });

export const readFile = async (path: string, options?: any): Promise<string> =>
    new Promise<string>((resolve, reject) =>
        fs.readFile(path, options, (err, data) => (err ? reject(err) : resolve(data.toString()))),
    );

export const cleanDir = async (pattern: string, options: any) =>
    new Promise((resolve, reject) =>
        rimraf(pattern, { glob: options }, (err: Error) => (err ? reject(err) : resolve(true))),
    );

export const readDir = (pattern: string, options: glob.IOptions) =>
    new Promise((resolve, reject) =>
        glob(pattern, options, (err, result) => (err ? reject(err) : resolve(result))),
    );
export const copyDir = async (source: string, target: string, filters?: string[]) => {
    const dirs: any = await readDir('**/*', {
        cwd: source,
        nosort: true,
        dot: true,
        nodir: true,
    });
    await Promise.all(
        dirs.map(async (dir: string) => {
            let skip = false;
            if (filters) {
                for (let i in filters) {
                    if (dir.match(filters[i])) {
                        skip = true;
                        break;
                    }
                }
            }
            if (!skip) {
                const from = path.resolve(source, dir);
                const to = path.resolve(target, dir);
                await mkdir(path.dirname(to));
                await copyFile(from, to);
            }
        }),
    );
};

export const copyFile = (source: string, target: string) =>
    new Promise<void>((resolve, reject) => {
        let cbCalled = false;
        function done(err: any) {
            if (!cbCalled) {
                cbCalled = true;
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            }
        }

        const rd = fs.createReadStream(source);
        rd.on('error', (err) => done(err));
        const wr = fs.createWriteStream(target);
        wr.on('error', (err: any) => done(err));
        wr.on('close', (err: any) => done(err));
        rd.pipe(wr);
    });
