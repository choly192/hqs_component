import path from 'path';
import webpack from 'webpack';
import MiniCssExtractPlugin from 'mini-css-extract-plugin';
import CopyPlugin from 'copy-webpack-plugin';
import AssetsPlugin from 'assets-webpack-plugin';

import BuildConfig from '../config/chat.config';

const getCommonConfig = () => {
    const config = <webpack.Configuration>{
        target: 'web',
        entry: {
            chat: './src/ng-chat/client/ng-chat.client.tsx',
        },
        output: {
            path: path.join(BuildConfig.PROJECT_ROOT, BuildConfig.ASSETS_DEST),
            publicPath: 'WebResource/Chat',
            filename: 'Scripts/[name]-[contenthash:8].js',
        },
        watchOptions: {
            aggregateTimeout: 1000,
            ignored: /node_modules/,
        },
        module: {
            rules: [
                {
                    test: /\.(woff(2)?|ttf|eot|svg)(\?.+)?$/,
                    use: [
                        {
                            loader: 'file-loader',
                            options: {
                                name: '[name].[ext]',
                                outputPath: 'Themes/fonts/',
                            },
                        },
                    ],
                },
                {
                    test: /\.css$/i,
                    use: [
                        {
                            loader: MiniCssExtractPlugin.loader,
                        },
                        {
                            loader: 'css-loader',
                            options: {
                                url: {
                                    filter: (url: string, _resourcePath: string) =>
                                        url.includes('/fonts/'),
                                },
                            },
                        },
                    ],
                },
            ],
        },
        plugins: [
            new CopyPlugin({
                patterns: [
                    {
                        context: 'static',
                        from: 'Themes/**/*',
                        toType: 'dir',
                    },
                ],
            }),
            new AssetsPlugin({
                path: path.join(BuildConfig.CONFIG_DEST),
                filename: 'assets.script.json',
                processOutput: function (x) {
                    let allChunk = []
                        .filter((p: any) => !(p?.src || '').startsWith('http'))
                        .filter((p: any) => /[tj]sx?$/.test(p.src || ''))
                        .reduce((rcc, chunk: any) => {
                            if (!!chunk && !!chunk.name && !!chunk.src) {
                                rcc[chunk.name] = {
                                    js: chunk.src,
                                    scriptSpecies: chunk.scriptSpecies,
                                };
                            }
                            return rcc;
                        }, {});

                    const scripts: any = {};
                    for (let key in x) {
                        if (!!key && !!x[key].js) {
                            scripts[key] = {
                                js: x[key].js,
                                scriptSpecies: allChunk[key]?.scriptSpecies,
                            };
                        }
                    }

                    // if (BuildConfig.IS_DEV) {
                    //     scripts['webpack-dev-server'] = {
                    //         js: '/webpack-dev-server.js',
                    //         scriptSpecies: 'defer',
                    //     };
                    // }

                    return `${JSON.stringify(scripts, null, 2)}`;
                },
            }),
            new AssetsPlugin({
                path: path.join(BuildConfig.CONFIG_DEST),
                filename: 'assets.css.json',
                processOutput: function (x) {
                    const styles: any = {};
                    for (let key in x) {
                        if (!!key && !!x[key].css) {
                            styles[key] = x[key].css;
                        }
                    }
                    return `${JSON.stringify(styles, null, 2)}`;
                },
            }),
            new webpack.DefinePlugin({
                __WebPlatform__: {
                    OS: JSON.stringify('browser'),
                    Environment: BuildConfig.BUILD_TYPE,
                },
                'process.env': {
                    BROWSER: JSON.stringify(true),
                },
                __DEV__: BuildConfig.IS_DEV,
            }),
            new MiniCssExtractPlugin({
                filename: 'CSS/[name]-[contenthash:8].css',
                chunkFilename: 'CSS/[name]-[contenthash:8].css',
                ignoreOrder: false,
            }),
        ],
        resolve: { extensions: ['.tsx', '.ts', '.js', '.jsx'] },
    };
    return config;
};

export default getCommonConfig();
