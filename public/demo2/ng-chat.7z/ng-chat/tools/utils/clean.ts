import colors from 'ansi-colors';
import log from 'fancy-log';
import { relative, normalize } from 'path';
import rimraf from 'rimraf';

import BuildConfig from '../config/chat.config'

/**
 * Cleans the given path(s) using `rimraf`.
 * @param {string | string[]} paths - The path or list of paths to clean.
 */
 export function clean(paths: string | string[]): (done: () => void) => void {
    return done => {
      let pathsToClean: string[];
      if (paths instanceof Array) {
        pathsToClean = paths;
      } else {
        pathsToClean = [<string>paths];
      }
  
      log('begin to clean!');
  
      const promises = pathsToClean.map(p => {
        return new Promise<void>(resolve => {
          const relativePath: string = relative(BuildConfig.PROJECT_ROOT, p);
          if (relativePath.startsWith('..')) {
            log(colors.bgred(`Cannot remove files outside the project root but tried "${normalize(p)}"`));
            process.exit(1);
          } else {
            log(colors.blue(p));
            rimraf(p, e => {
              if (e) {
                log('Clean task failed with', e);
              } else {
                log('Deleted', colors.yellow(p || '-'));
              }
              resolve();
            });
          }
        });
      });
      Promise.all(promises).then(() => (done || (() => 1))())
        .catch(e => log(colors.red(`Error while removing files "${[...paths].join(', ')}", ${e}`)));
    };
  }
  
  