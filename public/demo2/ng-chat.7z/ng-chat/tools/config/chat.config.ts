import { join } from 'path';
import { argv } from 'yargs';

const BUILD_TYPES = {
    DEVELOPMENT: 'development',
    PRODUCTION: 'release',
};

class ChatBuildConfig {
    PROJECT_ROOT = join(__dirname, '../..');
    BUILD_TYPE = getBuildType();
    DIST_DIR = 'dist';
    DEV_DEST = `${this.DIST_DIR}/development`;
    PROD_DEST = `${this.DIST_DIR}/release`;
    APP_DEST = this.BUILD_TYPE === BUILD_TYPES.DEVELOPMENT ? this.DEV_DEST : this.PROD_DEST;
    ASSETS_DEST = join(this.APP_DEST, '/WebResource/Chat');
    CONFIG_DEST = join(this.APP_DEST, 'conf');
    IS_DEV: boolean = BUILD_TYPES.DEVELOPMENT === this.BUILD_TYPE;
    onlineFaq = 'online.faq';
    DEPLOY_DEST = join(this.PROJECT_ROOT, this.DIST_DIR, 'deployment');
    IMAGE_CACHE_SERVER_DEST = join(this.DEPLOY_DEST, 'ImageCacheServer', 'WebResource', 'Chat');
    SERVER_DEPLOY_DEST = join(this.DEPLOY_DEST, 'server');
}

function getBuildType(): string {
    const type = ((argv['build-type'] || argv['env'] || '') as string).toLowerCase();
    const base: string[] = argv['_'];
    const prodKeyword = !!base.filter((o) => o.indexOf(BUILD_TYPES.PRODUCTION) >= 0).pop();
    if ((base && prodKeyword) || type === BUILD_TYPES.PRODUCTION) {
        return BUILD_TYPES.PRODUCTION;
    } else {
        return BUILD_TYPES.DEVELOPMENT;
    }
}

const config: ChatBuildConfig = new ChatBuildConfig();
export default config;
