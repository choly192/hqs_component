import gulp from 'gulp';
import ts from 'gulp-typescript';

import { Task } from '../basicTasks';

import BuildConfig from '../../config/chat.config';

export default class TscProdTask extends Task {
    run(done?: any) {

        const tsProject = ts.createProject('tsconfig.prd.server.json');

        return tsProject
        .src()
        .pipe(tsProject())
        .js
        .pipe(gulp.dest(BuildConfig.PROD_DEST));
    }
}
