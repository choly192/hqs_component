import log from 'fancy-log';
import gulp from 'gulp';
import glob from 'glob';
import through2 from 'through2';

import BuildConfig from '../../config/chat.config';

const files = glob.sync(`conf/**/!(*.d).{js,ts,json}`);
// If there are aaa.ts and aaa.js at the same time
// discard aaa.ts, use aaa.js
const filteredFiles = files.filter(
    (i) => !(i.endsWith('.ts') && files.includes(i.replace('.ts', '.js'))),
);

export default () => {
    log('build config....');
    return gulp
        .src(filteredFiles, { base: './conf' })
        .pipe(toJSON)
        .pipe(gulp.dest(BuildConfig.CONFIG_DEST));
};

let toJSON = through2.obj(function (blob, encoding, cb) {
    const [filePath] = blob.history;
    delete require.cache[require.resolve(filePath)];
    try {
        blob.contents = Buffer.from(JSON.stringify(require(filePath), null, 2));
        blob.path = filePath.substr(0, filePath.lastIndexOf('.')) + '.json';
        this.push(blob);
    } catch (e) {
        this.emit('error', e);
    }
    cb();
});
