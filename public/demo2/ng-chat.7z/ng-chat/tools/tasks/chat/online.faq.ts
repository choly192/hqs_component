import { writeFile } from 'fs';
import { join } from 'path';
import log from 'fancy-log';
import colors from 'ansi-colors';

import Config from '../../config/chat.config';

export default async () => {
    const filePath = join(Config.APP_DEST, Config.onlineFaq);

    await writeFile(filePath, '', (err) => {
        if (err) {
            log.error(err);
            return;
        }

        log('online.faq', colors.green(filePath));
    });
};
