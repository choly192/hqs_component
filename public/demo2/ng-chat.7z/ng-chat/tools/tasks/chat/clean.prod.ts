import { clean } from "../../utils/clean";

import BuildConfig from '../../config/chat.config';

export = clean([
    BuildConfig.PROD_DEST
])