import { webpack } from 'webpack';
import { merge } from 'webpack-merge';
import log from 'fancy-log';
import { WatchOptions } from 'gulp';

import { Task } from '../basicTasks';

import webpackConfig from '../../utils/webpack.common.config';

const devWebpackConfig = merge(webpackConfig, {
    mode: 'development',
    module: {
        rules: [
            {
                test: /\.[jt]sx?$/,
                exclude: /node_modules/,
                use: {
                    loader: 'swc-loader',
                },
            },
        ],
    },
    devtool: 'eval-cheap-module-source-map',
    target: ['web', 'es5'],
});

export default class BuildWebpackDevTask extends Task {
    run(done?: any) {
        done && done();
        return new Promise<void>((resolve, reject) => {
            webpack(devWebpackConfig).watch(webpackConfig.watchOptions as any, (err, stats) => {
                if (err) {
                    console.error(err);
                    reject(err);
                } else {
                    log('Webpack has finished bundling. Watching for file changes...');
                    resolve();
                }
            });
        });
    }
}
