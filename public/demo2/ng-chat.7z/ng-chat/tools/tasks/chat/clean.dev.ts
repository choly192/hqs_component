import { clean } from "../../utils/clean";

import BuildConfig from '../../config/chat.config';

export = clean([
    BuildConfig.DEV_DEST
])