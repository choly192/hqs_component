import { join } from 'path';
import os from 'os';
import { spawnSync } from 'child_process';
import WatchClient from 'tsc-watch/client';
import { exec } from 'child_process';

import BuildConfig from '../../config/chat.config';
import { readFile, writeFile } from '../../utils/fs';

const watch = new WatchClient();
let serverStarted: boolean = false;

export = async (done: any) => {
    await dev2ServerMapping();
    watch.on('first_success', startNodeServer);
    watch.on('compile_errors', startNodeServer);

    watch.start('--project', 'tsconfig.dev.server.json', '--compiler', 'typescript/bin/tsc');
};

function startNodeServer() {
    if (!serverStarted) {
        serverStarted = true;
        const isWindows: boolean = process.platform === 'win32';
        const isMac: boolean = process.platform === 'darwin';
        const scriptFile = isWindows ? 'start_nodemon.bat' : 'start_nodemon.command';

        const serverScript = join(BuildConfig.PROJECT_ROOT, 'tools', 'bin', scriptFile);

        if (isMac) {
            return spawnSync('open', ['-a', 'terminal', serverScript], {
                cwd: join(BuildConfig.PROJECT_ROOT),
            });
        } else if (isWindows) {
            return exec(`start cmd.exe /K "${serverScript}"`);
        }

        // todo: other platform
    }
}

async function dev2ServerMapping() {
    const serverInfo = {
        name: os.hostname(),
        environment: 'dev',
        serverId: 'dev',
    };

    let serverMapping;

    try {
        const serverMappingStr = await readFile(join(BuildConfig.CONFIG_DEST, 'serverMapping.json'));
        serverMapping = JSON.parse(serverMappingStr);
        serverMapping.push(serverInfo);
    } catch (e) {
        console.log('Write local dev server mapping error');
        serverMapping = [serverInfo];
    }

    await writeFile(
        join(BuildConfig.CONFIG_DEST, 'serverMapping.json'),
        JSON.stringify(serverMapping, null, 2),
    );
}
