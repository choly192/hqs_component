import { webpack } from 'webpack';
import { merge } from 'webpack-merge';
import TerserJSPlugin from 'terser-webpack-plugin';
import CssMinimizerPlugin from 'css-minimizer-webpack-plugin';
import log from 'fancy-log';

import { Task } from '../basicTasks';
import webpackConfig from '../../utils/webpack.common.config';
const HappyPack = require('happypack');
const os = require('os');
const happyThreadPool = HappyPack.ThreadPool({ size: os.cpus().length });
const prodWebpackConfig = merge(webpackConfig, {
    mode: 'production',
    target: ['web', 'es5'],
    module: {
        rules: [
            {
                test: /\.(ts|tsx|js)$/,
                use: 'happypack/loader?id=happyBabel',
                exclude: /[\\/]node_modules[\\/](?!(@framework-frontend|@microsoft|recoil)[\\/])/,
            },
        ],
    },
    plugins: [
        new HappyPack({
            id: 'happyBabel',
            loaders: [
                {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            [
                                '@babel/preset-env',
                                {
                                    useBuiltIns: 'usage',
                                    modules: 'commonjs',
                                    targets: {
                                        chrome: '58',
                                        ie: '11',
                                    },
                                    corejs: 3,
                                },
                            ],
                            '@babel/preset-react',
                            '@babel/preset-typescript',
                        ],
                        plugins: [
                            ['@babel/plugin-proposal-decorators', { legacy: true }],
                            [
                                '@babel/plugin-transform-runtime',
                                {
                                    regenerator: true,
                                },
                            ],
                        ],
                    },
                },
            ],
            threadPool: happyThreadPool,
            verbose: true,
        }),
    ],
    optimization: {
        minimizer: [
            new TerserJSPlugin({
                extractComments: false, // 不将注释提取到单独的文件
                terserOptions: {
                    compress: {
                        arrows: false,
                    },
                },
            }),
            new CssMinimizerPlugin(),
        ],
        splitChunks: {
            chunks: 'initial',
            minSize: 20000, // 生成chunk的最小体积
            minChunks: 1, // 拆分前必须共享的最小chunk数
            maxAsyncRequests: 5,
            maxInitialRequests: 3,
            name: false,
            cacheGroups: {
                default: false,
                vendor: {
                    name: 'vendor',
                    test: /[\\/]node_modules[\\/]/,
                },
                common: {
                    name: 'common',
                    test({ resource }: any) {
                        return [/[\\/]node_modules[\\/]@framework-frontend/].some((reg) =>
                            reg.test(resource),
                        );
                    },
                    priority: 10,
                },
            },
        },
    },
});

export default class BuildWebpackProdTask extends Task {
    run(done?: any) {
        return new Promise<void>((resolve, reject) => {
            webpack(prodWebpackConfig).run(async (err, stats) => {
                if (err) {
                    log.error(err);
                    reject(err);
                } else if (stats?.hasErrors()) {
                    const error = stats?.compilation?.errors
                        .map((err: any) => err.message)
                        .join('\n');
                    log(error);
                    reject(error);
                } else {
                    resolve();
                }
            });
        });
    }
}
