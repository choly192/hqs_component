import path from 'path';
import log from 'fancy-log';
import colors from 'ansi-colors';
import { copyFile } from 'fs';

import BuildConfig from '../../config/chat.config';
import { cleanDir, copyDir, mkdir, writeFile } from '../../utils/fs';

export = async (done: any) => {
    await cleanFolder(BuildConfig.DEPLOY_DEST);
    await mkdir(BuildConfig.DEPLOY_DEST);

    await copyYarnLock();
    await copyPackageJSON();
    await copyImageCacheServer();
    await copyServerToDeployment();

    done();
};

async function copyPackageJSON() {
    let packageJson = require(path.join(BuildConfig.PROJECT_ROOT, 'package.json'));
    delete packageJson['devDependencies'];

    await writeFile(
        path.join(BuildConfig.PROJECT_ROOT, `dist/release/package.json`),
        JSON.stringify(packageJson, null, 2),
    );

    log(`package.json`, colors.blue(`package.json ---------- done`));
}

async function copyYarnLock() {
    copyFile(
        path.join(BuildConfig.PROJECT_ROOT, 'yarn.lock'),
        path.join(BuildConfig.PROJECT_ROOT, BuildConfig.APP_DEST, 'yarn.lock'),
        (err) => {
            if (err) throw err;
            log('copyYarnLock', colors.blue(`COPYYARNLOCK DONE`));
        },
    );
}

async function cleanFolder(path) {
    await cleanDir(path, {
        noSort: true,
        dot: true,
    });
}

async function copyServerToDeployment() {
    await mkdir(BuildConfig.SERVER_DEPLOY_DEST);
    await copyDir(BuildConfig.PROD_DEST, BuildConfig.SERVER_DEPLOY_DEST);

    log(
        'copyServerToDeployment',
        colors.blue(`
      [from] :\t${BuildConfig.PROD_DEST}
      [to] :\t${BuildConfig.SERVER_DEPLOY_DEST}
      `),
    );
    await cleanFolder(BuildConfig.PROD_DEST);
}

async function copyImageCacheServer() {
    await mkdir(BuildConfig.IMAGE_CACHE_SERVER_DEST);
    await copyDir(BuildConfig.ASSETS_DEST, BuildConfig.IMAGE_CACHE_SERVER_DEST);

    log(
        'copyImageCacheServer',
        colors.blue(`
      [from] :\t${BuildConfig.ASSETS_DEST}
      [to] :\t${BuildConfig.IMAGE_CACHE_SERVER_DEST}
      `),
    );
    await cleanFolder(BuildConfig.ASSETS_DEST);
}
