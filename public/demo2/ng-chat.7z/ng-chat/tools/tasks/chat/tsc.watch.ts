import { join } from 'path';
import { spawnSync, exec } from 'child_process';

import BuildConfig from '../../config/chat.config';

const platformScriptMapping = {
    win32: 'start_tsc.bat',
    darwin: '',
    linux: '',
};

const platformCmdScriptMapping = {
    win32: function (serverScript: string) {
        return exec(`start cmd.exe /K "${serverScript}"`);
    },
    darwin: function (serverScript: string) {
        return spawnSync('open', ['-a', 'terminal', serverScript], {
            cwd: __dirname,
        });
    },
    linux: function (serverScript: string) {},
};

export = async (done: any) => {
    const platform = process.platform;
    const scriptFile: string = platformScriptMapping[platform];
    if (!scriptFile) {
        return;
    }

    const serverScript = join(BuildConfig.PROJECT_ROOT, 'tools', 'bin', scriptFile);

    platformCmdScriptMapping[platform](serverScript);

    done();
};
