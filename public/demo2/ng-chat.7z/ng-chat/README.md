## Prerequisites

* npm registry: `npm config set registry https://a.newegg.org/artifactory/api/npm/newegg-npm/ -g`
* yarn registry：`yarn config set registry https://a.newegg.org/artifactory/api/npm/newegg-npm/ -g`
* yarn

## 启动项目

* 正常 clone 项目
  git clone git@git.newegg.org:global-ec/application/ng-chat.git
* 安装项目依赖
  cd ng-chat
  yarn install
* 启动项目
  yarn start

## Git

* 获取更新:

  $ git pull
* 配置:

  $ git config --global --replace-all merge.autoStash true  # merge时自动stash
  
  $ git config --global --replace-all merge.conflictstyle diff3  # 给冲突标记上加上base version的内容
  
  $ git config --global --replace-all mergetool.trustExitCode true  # 信任mergetool的返回状态码来判断merge是否完成
  
  $ git config --global --replace-all pull.rebase merges  # pull时默认使用rebase而不是merge
  
  $ git config --global --replace-all rebase.autoStash true  # rebase时自动stash
  
  $ git config --global --replace-all alias.unshelve '!git stash pop; git submodule foreach --recursive "git stash pop || :"'  # 上面的反操作，即恢复暂存的改动

### Commit
* commit/push前做以下事：
1. **确定编译运行通过，并且浏览器控制台没有React的警告**
2. **Review一遍你的改动**，不要提交一些临时的，试验性的，不成熟的改动，
   善用stash/branch机制来管理这类代码
3. push前获取下最新版，**强烈建议使用rebase而不是merge**（使用上面的推荐配置），单个分支中由pull产生的merge结点是完全没有必要的，会使本应是线性的历史变成复杂的图，看起来很乱，review也不方便。

## Notice

1. **请统一使用yarn作为包管理器，不要使用npm**，这样我们可以在开发/测
   试/产线都使用相同的`yarn.lock`，安装完全相同的依赖，以保证由第三方
   包引起的bug是可复现的。

## 开发规范:

### 文件夹命名：

* 全小写，用 "-" 分隔单词

### 文件命名：

* ".ts"后缀，typescript文件命名：
  全小写，用 "-"分隔，拥有类型概念时，使用 ".【type】."来约束。
  常见类型：.interface. / .const. / .service. / .util. / .factory.
* ".tsx"后缀，typescript + JSX文件命名：
  全大写，帕斯卡命名法  ->  用于大部分普通组件
  拥有类型概念时，或者本身并不属于组件概念，而是内部只是需要使用JSX语法时，允许全小写，用"-"分隔，使用".【type】."来约束，比如定义的factory用于build组件。
  特殊情况：使用高阶组件（HOC）时，文件命名："with" + 帕斯卡命名。

### Typescript：

* 善用类型注释

```ts
/** person information */
interface User{
	name:string;
}
```

* 善用类型扩展
  * 在定义公共 API（如编辑一个库）时使用 `interface`，这样可以方便使用者继承接口；
  * 在定义组件属性（`Props`）和状态（`State`）时，建议使用 `type`，因为 `type` 的约束性更强；
  * `type` 类型不能二次编辑，而 `interface` 可以随时扩展。
* 善用TS支持的JS新特性
  * **可选链（Optional Chaining）** `?.` 是 `ES11(ES2020)`新增的特性，`TypeScript 3.7` 支持了这个特性。
  * **空值合并运算符** `??` 是 `ES12(ES2021)`新增的特性，`TypeScript 3.7` 支持了这个特性。当左侧的操作数为 `null` 或者 `undefined` 时，返回其右侧操作数，否则返回左侧操作数。
    * 注意与逻辑或操作符（`||`） 不同，`||` 会在左侧操作数为 `falsy` 值（例如，`''` 或 `0`）时返回右侧操作数。也就是说，如果使用 `||` 来为某些变量设置默认值，可能会遇到意料之外的行为：
      ```ts
      const user = {
      	level:0
      }
      let l1 = user.level || 'no level'  //no level
      let l2 = user.level ?? 'no level'  //0
      ```
* 善用高级类型
  * 类型索引(keyof), `keyof` 类似于`Object.keys`  ，用于获取一个接口中 Key 的联合类型
  * 类型约束（extends）,`TypeScript`中的`extends`关键词不同于在`Class`后使用`extends` 的继承作用，一般在泛型内使用，它主要作用是对泛型加以约束
  * 类型映射(in),`in` 关键词的作用主要是做类型的映射，遍历已有接口的 `key` 或者是遍历联合类型。

## 发版

1. `git stash` 你本地的修改
2. `git tag v.xxxxx.y.z HEAD`用版本号打一个新的tag
3. `git push origin --tags`push git tag
4. commit & push所有改动
5. CI系统跑完后需要放一下ImageCacheServer的launch包：解压publish.zip并
   上传到launch包。

## Libraries

1. [React Hooks](https://reactjs.org/docs/hooks-intro.html)
2. [React hook form examples](https://github.com/react-hook-form/react-hook-form/tree/master/examples)
3. [Fastify](https://www.fastify.io/docs/latest/)
4. [NestJS](https://docs.nestjs.com/)
5. [RxJS](https://www.learnrxjs.io/)
