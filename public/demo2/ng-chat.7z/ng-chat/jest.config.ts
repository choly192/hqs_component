module.exports = {
    roots: ['<rootDir>/'],
    modulePathIgnorePatterns: [
      '<rootDir>/dist',
      '<rootDir>/tools',
      '<rootDir>/src',
    ],
    testRegex: '.(e2e-|unit-)?spec.ts$',
    transform: {
      '^.+\\.(ts|tsx)$': '@swc/jest',
    },
    preset: 'ts-jest',
    testEnvironment: 'node',
    globals: {
      'ts-jest': {
        tsConfig: './tsconfig.prd.server.json',
      },
    },
  };
  