// interface System {
//     type: string;
//     version: string;
//     shell: () => void;
//     agent: string;
//     isIE: boolean;
//     isWebkit: boolean;
//     isStrict: boolean;
//     supportSubTitle: () => boolean;
//     supportScope: () => boolean;

// }
declare let window: any;
export const getBrowserInfo = () => {
    if (typeof window !== 'undefined') {
        const Browser = (function (window) {
            const document = window.document,
                navigator = window.navigator,
                agent = navigator.userAgent.toLowerCase(),
                IEMode = document?.documentMode
            const chrome = window?.chrome || false;
            const System: any = {
                type: "",
                version: "",
                shell: () => { },
                //user-agent
                agent: agent,
                //is IE
                isIE: /trident/.test(agent),
                //is Gecko
                isGecko: agent.indexOf("gecko") > 0 && agent.indexOf("like gecko") < 0,
                // is webkit
                isWebkit: agent.indexOf("webkit") > 0,
                isStrict: document.compatMode === "CSS1Compat",
                supportSubTitle: function () {
                    return "track" in document.createElement("track");
                },
                supportScope: function () {
                    return "scoped" in document.createElement("style");
                },
                ieVersion: function () {
                    let rMsie = /(msie\s|trident.*rv:)([\w.]+)/;
                    let ma = window.navigator.userAgent.toLowerCase()
                    let match = rMsie.exec(ma);
                    try {
                        return match && match[2];
                    } catch (e) {
                        // return IEMode;
                        return e
                    }
                },
                operaVersion: function () {
                    try {
                        if (window?.opera) {
                            return agent.match(/opera.([\d.]+)/)[1];
                        } else if (agent.indexOf("opr") > 0) {
                            return agent.match(/opr\/([\d.]+)/)[1];
                        }
                    } catch (e) {
                        return 0;
                    }
                }
            };

            try {
                System.type = System.isIE ? "IE" :
                    window?.opera || (agent.indexOf("opr") > 0) ? "opera" :
                        (agent.indexOf("chrome") > 0) ? "chrome" :
                            window?.openDatabase ? "safari" :
                                (agent.indexOf("firefox") > 0) ? "firefox" :
                                    'unknow';
                System.version = (System.type === "IE") ? System.ieVersion() :
                    (System.type === "firefox") ? agent.match(/firefox\/([\d.]+)/)[1] :
                        (System.type === "chrome") ? agent.match(/chrome\/([\d.]+)/)[1] :
                            (System.type === "opera") ? System.operaVersion() :
                                (System.type === "safari") ? agent.match(/version\/([\d.]+)/)[1] :
                                    "0";
                System.shell = function () {

                    if (agent.indexOf("edge") > 0) {
                        System.version = agent.match(/edge\/([\d.]+)/)[1] || System.version;
                        return "edge";
                    }
                    if (agent.indexOf("maxthon") > 0) {
                        System.version = agent.match(/maxthon\/([\d.]+)/)[1] || System.version;
                        return "maxthon";
                    }
                    if (agent.indexOf("qqbrowser") > 0) {
                        System.version = agent.match(/qqbrowser\/([\d.]+)/)[1] || System.version;
                        return "QQ";
                    }
                    if (agent.indexOf("se 2.x") > 0) {
                        return 'sogou';
                    }
                    if (chrome && System.type !== "Opera") {
                        var external = window.external,
                            clientInfo = window.clientInformation,
                            clientLanguage = clientInfo.languages;
                        if (external && 'LiebaoGetVersion' in external) {
                            return 'liebao';
                        }
                        if (agent.indexOf("bidubrowser") > 0) {
                            System.version = agent.match(/bidubrowser\/([\d.]+)/)[1] ||
                                agent.match(/chrome\/([\d.]+)/)[1];
                            return "baidu";
                        }
                        if (System.supportSubTitle() && typeof clientLanguage === "undefined") {
                            var storeKeyLen = Object.keys(chrome.webstore).length,
                                v8Locale = "v8Locale" in window;
                            return storeKeyLen > 1 ? '360 extreme browser' : '360 secure browser';
                        }
                        return "chrome";
                    }
                    return System.type;
                };

                System.name = System.shell();

            } catch (e) {

            }
            return {
                client: System
            };

        })(window);
        if (Browser.client.name == undefined || Browser.client.name == "") {
            Browser.client.name = "Unknown";
            Browser.client.version = "Unknown";
        } else if (Browser.client.version == undefined) {
            Browser.client.version = "Unknown";
        }
        return Browser;
    }

}