import React from 'react';
import cn from 'classnames';
import { isArray, isEmpty } from 'lodash';
import ChatBotMessage, { Suggestion } from '../component/ChatBotMessage';

import {
    ActionButton,
    ActionsAdditionalInfo,
    AgentAdditionalInfo,
    AgentFileType,
    AvatarAdditionalInfo,
    BaseAdditionalInfo,
    ChatBotAdditionalInfo,
    FileTypeStyle,
    MsgType,
    NoticeAdditionalInfo,
    RenderMsgByType,
    UserAdditionalInfo,
} from '../types';
import { replaceHttpUrl } from './chat.util';

export interface RenderChatMsg<T, K extends keyof T> {
    additionInfo: T[K];
    ele: (index: number, additionalInfo?: T[K]) => JSX.Element;
    type: K;
}

const msgTypes = [MsgType.Actions, MsgType.Agent, MsgType.ChatBot, MsgType.User];
const agentEntryTypes = [MsgType.Agent, MsgType.ChatBot, MsgType.Typing, MsgType.Actions];

export const renderMsgUtil = <K extends keyof RenderMsgByType>(
    prevList: Array<RenderChatMsg<RenderMsgByType, MsgType>>,
    type: K,
    additionInfo: RenderMsgByType[K],
): Array<RenderChatMsg<RenderMsgByType, MsgType>> => {
    if (prevList && isArray(prevList)) {
        if (prevList.findIndex((t) => t.type == MsgType.Typing) > -1) {
            if (type == MsgType.Typing) {
                return prevList;
            }
            if (type == MsgType.Agent) {
                prevList = prevList.filter((t) => t.type !== MsgType.Typing);
            }
        }

        if (msgTypes.includes(type)) {
            let lastItem = prevList[prevList.length - 1];
            let addInfo = additionInfo as BaseAdditionalInfo;
            let lastAddInfo = lastItem?.additionInfo as BaseAdditionalInfo;
            if (!addInfo.time) {
                addInfo.time = convertDate();
            }

            if (!lastAddInfo?.isError && !addInfo.isError && lastAddInfo?.time == addInfo.time && type == lastItem.type) {
                prevList[prevList.length - 1].additionInfo = {
                    ...additionInfo,
                    msgList: lastAddInfo?.msgList?.concat(addInfo?.msgList),
                };
                return prevList;
            }
        }
        prevList.push({
            additionInfo: additionInfo,
            type: type,
            ele: (index, addition) => {
                return (
                    <li
                        className={cn({
                            'user-entry': type == MsgType.User,
                            'agent-entry': agentEntryTypes.includes(type),
                            'notice chatting-with': type == MsgType.Avatar,
                            // 'attachment-entry': type == MsgType.ChatBotUSerAttachment,
                            notice: type == MsgType.Notice,
                        })}
                        id={type === MsgType.Actions ? 'chatbot-suggestion' : ''}
                        key={`li-${type}-${index}`}
                    >
                        {compileMsgByType(type, addition as RenderMsgByType[MsgType])}
                    </li>
                );
            },
        });
    }
    return prevList;
};

export const compileMsgByType = (type: MsgType, addition: RenderMsgByType[MsgType]) => {
    switch (type) {
        case MsgType.Agent:
            const agentMsgList = (addition as AgentAdditionalInfo)?.msgList?.filter(
                (t) => t.oriMsg,
            );
            if (agentMsgList.length > 0) {
                return (
                    <>
                        {agentMsgList?.map((t, index) => {
                            return (
                                <span key={`span-${type}-${index}`} className="entry-text">
                                    {replaceHttpUrl(t.oriMsg)}
                                    {t.isTranslated && (
                                        <span className="translation">{replaceHttpUrl(t.translateMsg ?? '')}</span>
                                    )}
                                </span>
                            );
                        })}
                        <span className="time-stamp">
                            {(addition as AgentAdditionalInfo)?.time}
                        </span>
                    </>
                );
            }
            return;
        case MsgType.ChatBot:
            return (
                <>
                    {(addition as ChatBotAdditionalInfo)?.msgList?.map((t, index) => {
                        return (
                            <span key={`span-${type}-${index}`}>
                                <ChatBotMessage
                                    data={t.data}
                                    isInteraction={
                                        (addition as ChatBotAdditionalInfo)?.isInteraction ?? true
                                    }
                                    onSendMessage={t.onSendMessage}
                                />
                            </span>
                        );
                    })}
                    <span className="time-stamp">{(addition as BaseAdditionalInfo)?.time}</span>
                </>
            );
        case MsgType.Notice:
            return (
                <span className="notice-text">
                    {replaceHttpUrl((addition as NoticeAdditionalInfo)?.notice)}
                </span>
            );
        case MsgType.User:
            const isError = (addition as UserAdditionalInfo)?.isError ?? false;
            const userMsgList = (addition as UserAdditionalInfo)?.msgList?.filter(
                (t) => t?.isAttachment || t?.oriMsg?.trim(),
            );
            if (userMsgList.length > 0) {
                return (
                    <>
                        {(addition as UserAdditionalInfo)?.msgList?.map((t, index) => {
                            const title =
                                t.isAttachment && t.fileName
                                    ? t.fileName.replace(/(.{30})/g, '$1\n')
                                    : '';
                            let renderMsgContent = (
                                <>
                                    {replaceHttpUrl(t.oriMsg)}
                                    {!isError && t.isTranslated && (
                                        <span className="translation">
                                            {t.translateMsg ? (
                                                t.translateMsg
                                            ) : (
                                                <span className="typing-indicator" />
                                            )}
                                        </span>
                                    )}
                                </>
                            );

                            if (t.isAttachment) {
                                if (isError) {
                                    renderMsgContent = (
                                        <>
                                            <i className="fa fa-exclamation-triangle" />
                                            {t.oriMsg}
                                            <span
                                                className="oversized-attachment-filename limit-length"
                                                title={title}
                                            >
                                                {t.fileName}
                                            </span>
                                        </>
                                    );
                                } else {
                                    renderMsgContent = (
                                        <>
                                            <a target="_blank" className="limit-length">
                                                <i
                                                    className={cn(
                                                        'fa',
                                                        findFileTypeStyle(t.fileType)?.iconClass,
                                                        t.isUploading && 'attachment-uploading',
                                                    )}
                                                    style={{ fontFamily: 'FontAwesome !important' }}
                                                />
                                                {t.fileName}
                                            </a>
                                            {t.isAttachment && t.isUploading && (
                                                <div
                                                    className="attachment-upload-processing"
                                                    style={{ width: `${t.progress}%` }}
                                                />
                                            )}
                                        </>
                                    );
                                }
                            }

                            let renderMsg = (
                                <span
                                    key={`user-span-${type}-${index}`}
                                    className={cn(
                                        'entry-text',
                                        t.isAttachment &&
                                            !isError &&
                                            findFileTypeStyle(t.fileType)?.containerClass,
                                        t.isAttachment && isError && 'attachment-oversized',
                                        t.isAttachment && t.isUploading && 'attachment-uploading',
                                    )}
                                    title={title}
                                >
                                    {renderMsgContent}
                                </span>
                            );

                            return (
                                <React.Fragment key={`user-isError-span-${type}-${index}`}>
                                    {renderMsg}
                                    {isError && !t.isRetryMsg && (
                                        <span
                                            className="time-stamp not-sent"
                                            key={`retry-${index}`}
                                        >
                                            {t.isAttachment ? 'FAILED TO SEND' : 'NOT DELIVERED'}
                                            {!t.isAttachment && t.retryFn && (
                                                <a
                                                    title=""
                                                    onClick={() => {
                                                        t.retryFn && t.retryFn();
                                                    }}
                                                    style={{cursor:'pointer'}}
                                                >
                                                    RETRY
                                                </a>
                                            )}
                                        </span>
                                    )}
                                    {t.isRetryMsg && (
                                        <span className="time-stamp"><span className='typing-indicator'/></span>
                                    )}
                                </React.Fragment>
                            );
                        })}
                        {!isError && <span className='time-stamp' key={(addition as UserAdditionalInfo)?.time??new Date().getTime()}>
                            {(addition as UserAdditionalInfo)?.time}
                        </span>}
                    </>
                );
            }
            return;
        case MsgType.Typing:
            return (
                <span className="entry-text">
                    <span className="typing-indicator" />
                </span>
            );
        case MsgType.Avatar:
            return (
                <span className="notice-text">
                    <span
                        className="agent-thumbnail"
                        style={(addition as AvatarAdditionalInfo)?.style}
                    />
                    <span className="entry-text">{(addition as AvatarAdditionalInfo)?.notice}</span>
                </span>
            );
        case MsgType.Actions:
            const {
                actionButton,
                suggestions,
                onUploadVisible,
                onSendMessage,
                visible = true,
            } = addition as ActionsAdditionalInfo;
            return visible && (
                <div className="NE-chat-bot-btns">
                    {!isEmpty(actionButton) && (
                        <Suggestion data={[actionButton]} onSendMessage={onUploadVisible} />
                    )}
                    {!isEmpty(suggestions) && (
                        <Suggestion data={suggestions} onSendMessage={onSendMessage} />
                    )}
                </div>
            );
    }
};

export const convertDate = (date?: Date): string => {
    return (date ? new Date(date) : new Date()).toLocaleString('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true,
    });
};

const findFileTypeStyle = (fileType: AgentFileType | undefined) => {
    if (fileType) {
        if (!FileTypeStyle[fileType]) {
            return FileTypeStyle[AgentFileType.None];
        }
        return FileTypeStyle[fileType];
    }
    return null;
};
