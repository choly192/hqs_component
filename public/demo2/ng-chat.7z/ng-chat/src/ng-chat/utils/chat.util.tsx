import React from 'react';
import { trim } from 'lodash';

import { useLocalStorage } from '../../common/hook';

import { ChatStatus, LocalStorageType } from '../../common/storage';
import { ChatCookie, ONE_DAY } from '../const/browser';
import { PostMessage, InitialState, ConnectWith } from '../types';
const { getValue, setValue, remove } = useLocalStorage();

const getCookieValue = (name: string) => {
    let result = document.cookie.match(
        '(^|[^;]+)\\s*' + name + '\\s*=\\s*([^;]+)',
    ) as RegExpMatchArray;
    return result ? unescape(result.pop() ?? '') : '';
};

const setCookieValue = (name: string, value: string, min: number) => {
    let cookieValue = getCookieValue(ChatCookie);
    let valueObj = {};
    if (cookieValue !== '') {
        valueObj = JSON.parse(cookieValue);
    }
    if (min < 0) {
        delete valueObj[name];
    } else {
        let expireDate = new Date(new Date().getTime() + min * 60 * 1000);
        if (!valueObj[name]) {
            valueObj[name] = {};
        }
        valueObj[name].data = value;
        valueObj[name].exp = expireDate.getTime();
    }
    let cookieExpireDate = new Date(new Date().getTime() + 1000 * 24 * 60 * 60 * 1000);
    let expire = '; expires=' + cookieExpireDate;
    let domainArray = document.domain.split('.');
    if (domainArray.length > 1) {
        domainArray.shift();
    }
    let domain = '; domain=' + domainArray.join('.');
    let sameSite = '; SameSite=None;';
    if (window.location.protocol === 'https:') {
        sameSite += 'Secure';
    }
    document.cookie =
        ChatCookie + '=' + escape(JSON.stringify(valueObj)) + expire + domain + sameSite;
};

const chatPostMessage = (info?: PostMessage) => {
    window.parent.postMessage({ type: 'CHAT', ...info }, '*');
};

const isPC = () => {
    let userAgentInfo = navigator.userAgent;
    let Agents = new Array('Android', 'iPhone', 'SymbianOS', 'Windows Phone', 'iPad', 'iPod');
    let flag = true;
    for (let v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
        }
    }
    return flag;
};

const closePopup = () => {
    chatPostMessage({
        action: 'close',
    });
    setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, false);
};

const collapsePopup = () => {
    chatPostMessage({
        action: 'collapse',
    });
    setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, false);
};

const replaceHttpUrl = (sourceStr: string): React.ReactNode => {
    const regUrl = /(((https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/ig;
    const urlList = sourceStr.match(regUrl) || [];
    let copySourceStr = trim(sourceStr);

    if (urlList.length > 0) {
        let elementTmp: React.ReactNode = '';

        urlList.forEach((url) => {
            const index = copySourceStr.indexOf(url);
            let beforeStr = '';

            if (index !== 0) {
                beforeStr = copySourceStr.slice(0, index);
            }
            copySourceStr = copySourceStr.replace(`${beforeStr}${url}`, '');

            const isHttp = url.slice(0, 7).toLowerCase() === 'http://';
            let isHttps = false;
            if (!isHttp) {
                isHttps = url.slice(0, 8).toLowerCase() === 'https://';
            }

            elementTmp = (
                <>
                    {elementTmp}
                    {beforeStr}
                    {isHttp || isHttps ? (
                        <a href={url} target="_blank">
                            {url}
                        </a>
                    ) : (
                        url
                    )}
                </>
            );
        });

        return (
            <>
                {elementTmp}
                {copySourceStr}
            </>
        );
    }

    return sourceStr.replace(/\^/g, '');
};

const isChatting = (): boolean => {
    let chatStatus = getValue(LocalStorageType.CHAT_STATE);
    return chatStatus && chatStatus !== ChatStatus.Ended && chatStatus !== ChatStatus.Initial;
};

const connectWithChatStatus = (): ConnectWith => {
    let chatStatus = getValue(LocalStorageType.CHAT_STATE);
    switch (chatStatus) {
        case ChatStatus.Waiting:
        case ChatStatus.Chatting:
            return ConnectWith.Agent;
        case ChatStatus.ChatBotChatting:
            return ConnectWith.ChatBot;
        case ChatStatus.Ended:
            return ConnectWith.Ended;
        default:
            return ConnectWith.Initial;
    }
};

const clearCookie = () => {
    let keys = document.cookie.match(/[^ =;]+(?==)/g);
    if (keys) {
        for (let i = keys.length; i--; ) {
            document.cookie = `${keys[i]}=;expires=${new Date(
                Date.now() - ONE_DAY,
            )}; SameSite=None; Secure`;
        }
    }
};

const isIE = () => {
    const pat = /msie|trident/i;
    return pat.test(window.navigator.userAgent);
};

export {
    setCookieValue,
    getCookieValue,
    closePopup,
    collapsePopup,
    replaceHttpUrl,
    chatPostMessage,
    isChatting,
    connectWithChatStatus,
    clearCookie,
    isPC,
    isIE,
};
