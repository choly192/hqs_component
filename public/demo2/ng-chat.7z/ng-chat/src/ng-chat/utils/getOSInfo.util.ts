interface os {
    name: string;
    version: string;
}
export const getOSInfo = () => {
    var userAgent = navigator.userAgent.toLowerCase();
    var name = 'Unknown';
    var version = "Unknown";
    if (userAgent.indexOf("win") > -1) {
        if (userAgent.indexOf("windows nt 5.0") > -1) {
            name = "Win 2000";
            version = "2000";
        } else if (userAgent.indexOf("windows nt 5.1") > -1 || userAgent.indexOf("windows nt 5.2") > -1) {
            name = "Win XP";
            version = "XP";
        } else if (userAgent.indexOf("windows nt 6.0") > -1) {
            name = "Win Vista";
            version = "Vista";
        } else if (userAgent.indexOf("windows nt 6.1") > -1 || userAgent.indexOf("windows 7") > -1) {
            name = "Win 7";
            version = "7";
        } else if (userAgent.indexOf("windows nt 6.2") > -1 || userAgent.indexOf("windows 8") > -1) {
            name = "Win 8";
            version = "8";
        } else if (userAgent.indexOf("windows nt 6.3") > -1) {
            name = "Win 8.1";
            version = "8.1";
        } else if (userAgent.indexOf("windows nt 6.2") > -1 || userAgent.indexOf("windows nt 10.0") > -1) {
            name = "Win 10";
            version = "10";
        } else {
            version = "Unknown";
        }
    } else if (userAgent.indexOf("iphone") > -1) {
        name = "Iphone";
    } else if (userAgent.indexOf("mac") > -1) {
        name = "Mac";
    } else if (userAgent.indexOf("x11") > -1 || userAgent.indexOf("unix") > -1 || userAgent.indexOf("sunname") > -1 || userAgent.indexOf("bsd") > -1) {
        name = "Unix";
    } else if (userAgent.indexOf("linux") > -1) {
        if (userAgent.indexOf("android") > -1) {
            name = "Android"
        } else {
            name = "Linux";
        }

    } else {
        name = "Unknown";
    }
    const os: os = { name: name, version: version };
    return os;
}