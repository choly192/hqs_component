import React from 'react';
import { trim } from 'lodash';

import { ChatStatus, LocalStorageType } from '../../common/storage';
import { useLocalStorage } from '../../common/hook';

const { getValue, setValue, remove } = useLocalStorage();
const hasChatBotConversationAndToken = () => {
    return getValue(LocalStorageType.CHATBOT_SESSIONID) && getValue(LocalStorageType.CHATBOT_TOKEN);
};

const replaceToStrongOrSup = (sourceStr: string, isReplaceBrTag: boolean = false): React.ReactNode => {
    const matchList = sourceStr.match(/(\*\*(.*?)\*\*)|(\^\^(.*?)\^\^)/g) || [];

    let copySourceStr = trim(sourceStr);

    if (matchList.length > 0) {
        let elementTmp: React.ReactNode = '';

        matchList.forEach((str) => {
            const index = copySourceStr.indexOf(str);
            let beforeStr = '';
            let beforeStrEl: React.ReactNode;
            let afterEscape: React.ReactNode;

            if (/\*\*(.*?)\*\*/g.test(str)) {
                const value = str.replace(/\*/g, '');
                afterEscape = <strong>{isReplaceBrTag ? replaceLineFeed(value) : value}</strong>;
            } else {
                const value = str.replace(/\^/g, '');
                afterEscape = <sup>{isReplaceBrTag ? replaceLineFeed(value) : value}</sup>;
            }

            if (index !== 0) {
                beforeStr = copySourceStr.slice(0, index);
                beforeStrEl = isReplaceBrTag ? replaceLineFeed(beforeStr) : beforeStr;
            }

            copySourceStr = copySourceStr.replace(`${beforeStr}${str}`, '');

            elementTmp = (
                <>
                    {elementTmp}
                    {beforeStrEl}
                    {afterEscape}
                </>
            );
        });

        return (
            <>
                {elementTmp}
                {copySourceStr}
            </>
        );
    }
    const newStr = copySourceStr.replace(/\*/g, '');
    return isReplaceBrTag ? replaceLineFeed(newStr) : newStr;
};

const replaceLineFeed = (sourceStr: string) => {
    let copySourceStr = sourceStr.replace(/\n/g, '/br').trim();
    const matchList = copySourceStr.match(/\/br/g) || [];
    if (matchList.length > 0) {
        let elementTmp: React.ReactNode = '';

        matchList.forEach((str) => {
            const index = copySourceStr.indexOf(str);
            let beforeStr = '';

            if (index !== 0) {
                beforeStr = copySourceStr.slice(0, index);
            } else {
                const newSourceStr = copySourceStr.substring(3);
                console.log(newSourceStr, copySourceStr)
                const nextIndex = newSourceStr.indexOf(str);
                beforeStr = newSourceStr.substring(0, nextIndex > -1 ? nextIndex : newSourceStr.length);
                console.log(beforeStr, nextIndex)
            }

            copySourceStr = copySourceStr.replace(`${beforeStr}${str}`, '');

            elementTmp = (
                <>
                    {elementTmp}
                    {index === 0 && <br/>}
                    {beforeStr}
                    {index > 0 && <br />}
                </>
            );
        });

        return (
            <>
                {elementTmp}
                {copySourceStr}
            </>
        );
    }

    return sourceStr;
};
export {
    hasChatBotConversationAndToken,
    replaceToStrongOrSup,
    replaceLineFeed,
};
