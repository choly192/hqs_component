import { useLocalStorage } from '../../common/hook';
import { ChatMsg, ChatStatus, LocalStorageType } from '../../common/storage';
import { CreateAgentChatResponse } from '../models';
import { AgentFileType } from '../types/msg.type';
const { getValue, setValue } = useLocalStorage();
const keepAlive = (websocket: WebSocket) => {
    if (websocket.readyState == WebSocket.OPEN) {
        websocket.send('');
    }
};

const SetPrefix = (oriMsg, transLateMsg) => {
    return `${oriMsg}(Translated:${transLateMsg})`;
};

const ConvertPrefix = (
    val: string,
): {
    oriMsg: string;
    translatedMsg: string;
} => {
    let translatedFont = '(Translated:';
    let position = val.indexOf(translatedFont);
    if (position > -1) {
        return {
            oriMsg: val.substring(0, position),
            translatedMsg: val.substring(position + translatedFont.length, val.length - 1),
        };
    }
    return {
        oriMsg: val,
        translatedMsg: '',
    };
};

const reg = /(.*?)\(This is attachment file link,file name is (.*)(\..*?)\)/;

const checkIsAttachment = (val: string): boolean => {
    return reg.test(val);
};

const GetAttachmentInfo = (
    val,
): {
    url: string;
    fileType: AgentFileType;
    fileName: string;
} => {
    let res = reg.exec(val) as RegExpExecArray;
    if (res) {
        return {
            url: res[1] ?? '',
            fileType: (res[3]?.trim()?.toLowerCase() as AgentFileType) ?? AgentFileType.None,
            fileName: res[2] && res[3]?.trim() ? `${res[2]}${res[3]}` : '',
        };
    }
    return {
        url: '',
        fileType: AgentFileType.None,
        fileName: '',
    };
};

const saveChatMessage = (msgInfo: ChatMsg) => {
    let msgList = getValue(LocalStorageType.CHAT_MSG_LIST) || [];
    let hasStore = false;
    for (let i = 0; i < msgList.length; i++) {
        if (msgList[i].messageId == msgInfo.messageId) {
            hasStore = true;
            break;
        }
    }
    if (hasStore) {
        return;
    }
    if (
        msgInfo.targetLanguage == msgInfo.oriLanguage ||
        msgInfo.translateMessage == msgInfo.sendMessage
    ) {
        msgInfo.translateMessage = '';
        msgInfo.targetLanguage = '';
    }
    if (!msgList || msgList.length == 0) {
        msgList = [];
    }
    msgList.push(msgInfo);
    setValue(LocalStorageType.CHAT_MSG_LIST, msgList);
};

const getAgentChatData = (): CreateAgentChatResponse => {
    const basicInfo = getValue(LocalStorageType.CHAT_BASIC_INFO);
    let config: CreateAgentChatResponse = {
        socketUrl: getValue(LocalStorageType.CHAT_CONVERSATION_WEBSOCKETURL),
        token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN),
        conversationID: getValue(LocalStorageType.CHAT_CONVERSATION_ID),
        chatSource: getValue(LocalStorageType.CHAT_SOURCE),
        memberId: getValue(LocalStorageType.CHAT_CUSTOMER_MEMBER_ID),
        sourceLanguage: getValue(LocalStorageType.CHAT_LANGUAGE),
        translateQuestion: basicInfo.questionTranslate ?? '',
        question: basicInfo.question,
    };
    return config;
};

const hasAgentConversationAndToken = () => {
    return (
        getValue(LocalStorageType.CHAT_CONVERSATION_ID) &&
        getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
    );
};

const saveAgentInfoToLocalStorage = (res: CreateAgentChatResponse) => {
    setValue(LocalStorageType.CHAT_STATE, ChatStatus.Waiting);
    setValue(LocalStorageType.CHAT_CONVERSATION_ID, res?.conversationID);
    setValue(LocalStorageType.CHAT_CONVERSATION_TOKEN, res?.token);
    setValue(LocalStorageType.CHAT_SOURCE, res?.chatSource);
    setValue(LocalStorageType.CHAT_CUSTOMER_MEMBER_ID, res?.memberId);
    setValue(LocalStorageType.CHAT_CONVERSATION_WEBSOCKETURL, res?.socketUrl);
    let chatBasicInfo = getValue(LocalStorageType.CHAT_BASIC_INFO);
    chatBasicInfo.questionTranslate = res?.translateQuestion?.trim();
    setValue(LocalStorageType.CHAT_BASIC_INFO, chatBasicInfo);
    setValue(LocalStorageType.CHAT_LANGUAGE, res?.sourceLanguage);
};

export {
    keepAlive,
    SetPrefix,
    ConvertPrefix,
    checkIsAttachment,
    GetAttachmentInfo,
    saveChatMessage,
    getAgentChatData,
    hasAgentConversationAndToken,
    saveAgentInfoToLocalStorage,
};
