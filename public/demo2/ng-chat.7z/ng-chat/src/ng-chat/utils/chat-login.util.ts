import { useLocalStorage } from '../../common/hook';
import { ChatStatus, LocalStorageType } from '../../common/storage';
import { CascaderOptions } from '../../common/component';
import { TopicAndReasonOption } from '../../common/types';
import { ChatLoginSubmitVal } from '../types/chatLogin/chatLoginSubmitVal';

const { setValue } = useLocalStorage();

const convertTopicAndReason = (
    topicAndReasonOptions: Array<TopicAndReasonOption>,
    defaultTopic: string,
    defaultReason: string,
    agentClose: boolean,
    allowAllTopicAndReason: boolean,
) => {
    let topicOptionList: Array<CascaderOptions> = [
        {
            Value: defaultTopic,
        },
    ];
    topicAndReasonOptions?.forEach((t) => {
        if (t.Name) {
            let reasonList: Array<any> = [];
            if (t.Reason && t.Reason.length > 0) {
                reasonList = reasonList.concat(
                    allowAllTopicAndReason || !agentClose
                        ? t.Reason
                        : t.Reason.filter((t) => t.AllowChatBot),
                );
                if (reasonList.length == 0) {
                    return;
                }
                reasonList.unshift({
                    Value: defaultReason,
                });
                topicOptionList.push({
                    Value: t.Name,
                    Children: reasonList
                        ? reasonList.map((m) => {
                              if (m.Name) {
                                  m.Value = m.Name;
                              }
                              return m;
                          })
                        : [],
                });
            }
        }
    });
    if (topicOptionList.length == 1) {
        return [];
    }
    return topicOptionList;
};

const getInputLine = (ref: HTMLTextAreaElement): number => {
    return Math.floor(
        ref.scrollHeight / Number(window.getComputedStyle(ref).lineHeight.replace('px', '')),
    );
};

const saveLoginInfoToLocalStorage = (submitVal: ChatLoginSubmitVal, connectChatBot: boolean) => {
    // setValue(LocalStorageType.CHAT_USER_NAME, submitVal.FullName.value);
    // setValue(LocalStorageType.CHAT_EMAIL, submitVal.EmailAddress.value);
    setValue(LocalStorageType.CHAT_BASIC_INFO, {
        fullName: submitVal.FullName.value,
        emailAddress: submitVal.EmailAddress.value,
        sendMeTranscript: submitVal.EnableSendMeTranscript,
        category: submitVal.Category.value,
        topic: submitVal.Topic.value,
        reason: submitVal.Reason.value,
        question: connectChatBot ? submitVal.Reason.value : submitVal.Question.value,
        dateTime: new Date(),
    });
    setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, true);
    // setValue(LocalStorageType.CHAT_SEND_TRANSCRIPT_EMAIL, submitVal.EnableSendMeTranscript);
    setValue(LocalStorageType.CHAT_STATE, ChatStatus.Initial);
};

export { convertTopicAndReason, getInputLine, saveLoginInfoToLocalStorage };
