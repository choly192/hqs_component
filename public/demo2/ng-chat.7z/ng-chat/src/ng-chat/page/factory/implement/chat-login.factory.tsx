import React from 'react';

import { AbstractChatFactory } from '../abstract-chat-factory';
import { ChatLogin } from '../../ng-chat-login/ChatLogin';

export class ChatLoginFactory extends AbstractChatFactory {
    buildComponent() {
        return (
            <>
                <ChatLogin />
            </>
        );
    }
}
