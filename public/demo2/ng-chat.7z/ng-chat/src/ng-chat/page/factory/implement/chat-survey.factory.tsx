import React from 'react';

import { AbstractChatFactory } from '../abstract-chat-factory';
import { ChatSurvey } from '../../ng-chat-survey/ChatSurvey'

export class ChatSurveyFactory extends AbstractChatFactory {
    buildComponent() {
        return (
            <>
                <ChatSurvey />
            </>
        );
    }
}
