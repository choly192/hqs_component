import { PageType } from '../../atom';
import { AbstractChatFactory } from './abstract-chat-factory';
import {
    ChatWindowFactory,
    ChatLoginFactory,
    ChatAgentWindowFactory,
    ChatBotWindowFactory,
    ChatCloseFactory,
    ChatSurveyFactory,
    ChatSurveySuccessFactory,
} from './implement';

const chatWindow = new ChatWindowFactory({});
export const ChatFactoryMapping: { [key: string]: AbstractChatFactory } = {
    [PageType.ChatLogin]: new ChatLoginFactory(),
    [PageType.ChatAgentWindow]: chatWindow,
    [PageType.ChatBotWindow]: chatWindow,
    [PageType.ChatClose]: new ChatCloseFactory(),
    [PageType.ChatSurvey]: new ChatSurveyFactory(),
    [PageType.ChatSurveySuccess]: new ChatSurveySuccessFactory(),
};
