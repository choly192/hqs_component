import React from 'react';

import { ChatWindowFactory } from './chat-window.factory';
import { PageType } from '../../../atom';

export class ChatBotWindowFactory extends ChatWindowFactory {
    constructor() {
        super({ pageType: PageType.ChatBotWindow });
    }
}
