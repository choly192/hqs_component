import React from 'react';

import { ChatWindowFactory } from './chat-window.factory';
import { PageType } from '../../../atom';

export class ChatAgentWindowFactory extends ChatWindowFactory {
    constructor() {
        super({ pageType: PageType.ChatAgentWindow });
    }
}
