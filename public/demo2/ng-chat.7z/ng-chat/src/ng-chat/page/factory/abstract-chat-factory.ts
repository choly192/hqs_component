import { PageType } from '../../atom';

export abstract class AbstractChatFactory {
    abstract buildComponent(pageType?: PageType): JSX.Element;
}
