import React from 'react';

import { AbstractChatFactory } from '../abstract-chat-factory';
import { ChatBase } from '../../ng-chat-window/ChatBase';
import { PageType } from '../../../atom';
import { MsgType, RenderMsgByType } from '../../../types';
import { RenderChatMsg } from '../../../utils';
import ChatAgent from '../../ng-chat-window/ng-chat-agent/ChatAgent';
import ChatBot from '../../ng-chat-window/ng-chat-bot/ChatBot';

interface IChatWindowFactory {
    pageType?: PageType;
    renderMsgList?: Array<RenderChatMsg<RenderMsgByType, MsgType>>;
}

const PageTypeComponentMapping = {
    [PageType.ChatAgentWindow]: ChatAgent,
    [PageType.ChatBotWindow]: ChatBot,
};

export class ChatWindowFactory extends AbstractChatFactory {
    pageType?: PageType;
    renderMsgList: Array<RenderChatMsg<RenderMsgByType, MsgType>>;
    botToAgentStatus: boolean = false;

    constructor({ pageType, renderMsgList }: IChatWindowFactory) {
        super();
        this.pageType = pageType;
        this.renderMsgList = renderMsgList ?? [];
    }

    getBotToAgentStatus(): boolean {
        return this.botToAgentStatus;
    }

    setBotToAgentStatus(val: boolean) {
        this.botToAgentStatus = val;
    }

    getRenderChatMsgList():Array<RenderChatMsg<RenderMsgByType, MsgType>> {
        return this.renderMsgList;
    }

    setRenderChatMsgList<K extends keyof RenderMsgByType>(type: K,
        additionInfo: RenderMsgByType[K]) {
        return this.renderMsgList;
    }

    buildComponent(pageType) {
        const C = PageTypeComponentMapping[pageType];
        return <ChatBase>
            {(props) => <C {...props} />}
        </ChatBase>;
    }
    buildWindow() {
        return <></>;
    }
}
