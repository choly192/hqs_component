import React from 'react';

import { AbstractChatFactory } from '../abstract-chat-factory';
import { ChatSurveySuccess } from '../../ng-chat-survey/ChatSurveySuccess'
export class ChatSurveySuccessFactory extends AbstractChatFactory {
    buildComponent() {
        return (
            <>
                <ChatSurveySuccess />
            </>
        );
    }
}
