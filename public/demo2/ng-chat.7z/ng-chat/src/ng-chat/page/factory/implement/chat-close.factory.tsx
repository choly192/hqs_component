import React, { FC } from 'react';
import { currentPageStatusAtom, PageType } from '../../../atom';

import { AbstractChatFactory } from '../abstract-chat-factory';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { useLocalStorage } from '../../../../common/hook';
import { LocalStorageType } from '../../../../common/storage';
import { chatPostMessage } from '../../../utils';
import { useChatUtils } from '../../../hooks';

export class ChatCloseFactory extends AbstractChatFactory {
    buildComponent() {
        return <ChatClose />;
    }
}

const ClosedMsg = `We are sorry! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.`;
const ChatClose: FC = () => {
    const [currentPageStatus, setCurrentPageStatus] = useRecoilState(currentPageStatusAtom);
    const { setValue } = useLocalStorage();
    const { isPopup } = useChatUtils();
    return (
        <div className="NE-chat-exit show-unavailable">
            <div className="chat-unavailable">
                <div className="message message-info is-vertical">
                    <div className="message-wrapper">
                        <div className="message-icon"></div>
                        {currentPageStatus.additionInfo &&
                        currentPageStatus.additionInfo.message ? (
                            <div
                                dangerouslySetInnerHTML={{
                                    __html: currentPageStatus.additionInfo.message.trim()
                                }}
                            />
                        ) : (
                            <div className="message-information">
                                <span className="message-title">
                                    Our Live Chat is currently closed.
                                </span>
                                <p>{ClosedMsg}</p>
                            </div>
                        )}
                    </div>
                    {isPopup() && (
                        <div className="exit-buttons">
                            <button
                                className="btn"
                                onClick={() => {
                                    setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, false);
                                    chatPostMessage({ action: 'close' });
                                }}
                            >
                                Leave Chat
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
ChatClose.displayName = 'ChatClose';
