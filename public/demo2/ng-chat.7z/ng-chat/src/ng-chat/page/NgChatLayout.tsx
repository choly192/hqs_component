import React, { FC, useEffect, useMemo, useRef } from 'react';
import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';
import cn from 'classnames';

import { LocalStorageType } from '../../common/storage';
import { useLocalStorage } from '../../common/hook';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';

import { AvatarType, currentChatLayoutStatusAtom } from '../atom/current-chat-layout-status.atom';
import { currentPageStatusAtom, PageType } from '../atom/current-page-status.atom';
import {
    chatPostMessage,
    connectWithChatStatus,
    hasAgentConversationAndToken,
    hasChatBotConversationAndToken,
    isChatting
} from '../utils';
import { ChatFactoryMapping } from './factory/chat-factory-mapping';
import {
    useChatAgentAPI,
    useChatAPI,
    useChatBotAPI,
    useChatLoginUtils,
    useChatUtils
} from '../hooks';
import { ChatType, ConnectWith, InitialState, PostMessageFromPage } from '../types';
import { PermissionType } from '../models';
import {
    chatBasicInfo,
    chatLayoutBasicInfoAtom,
    ChatRedTipsStatus,
    ChatRedTipsStatusAtom
} from '../atom';

export const NgChatLayout: FC = () => {
    const [currentPageStatus, setCurrentPageStatus] = useRecoilState(currentPageStatusAtom);
    const currentChatLayoutStatus = useRecoilValue(currentChatLayoutStatusAtom);
    const setChatLayoutBasicInfo = useSetRecoilState(chatLayoutBasicInfoAtom);
    const setChatRedTipsStatus = useSetRecoilState(ChatRedTipsStatusAtom);
    const chatLayoutBasicInfoRef = useRef<chatBasicInfo>();

    const { getAgentConversationState } = useChatAgentAPI();
    const { getChatBotConversationState } = useChatBotAPI();
    const { clearInfo, initialPage } = useChatUtils();
    const { saveChatBasicInfoByChatDirectlyType, noActiveChatBot } = useChatLoginUtils();

    const { getValue, setValue } = useLocalStorage();
    const initialState = useInitialState<InitialState>();

    const chatFactory = ChatFactoryMapping[currentPageStatus.pageType];
    const ChatEnhancer = useMemo(() => chatFactory?.buildComponent(currentPageStatus.pageType), [currentPageStatus]);

    useEffect(() => {
        setChatLayoutBasicInfo({
            loginName: initialState.AdditionInfo.loginName,
            emailAddress: initialState.AdditionInfo.emailAddress,
            category: initialState.AdditionInfo.category,
            topic: initialState.AdditionInfo.topic,
            reason: initialState.AdditionInfo.reason,
            type: initialState.AdditionInfo.type,
            isClose: initialState.IsClose,
            closeMsg: initialState.CloseMsg
        });
        if (getValue(LocalStorageType.CHAT_WINDOW_IS_OPEN) === false && isChatting()) {
            chatPostMessage({ action: 'collapse' });
        }
        if (connectWithChatStatus() == ConnectWith.Agent) {
            hasAgentConversationAndToken() &&
                getValue(LocalStorageType.CHAT_CUSTOMER_MEMBER_ID) &&
                getAgentConversationState()?.then((res) => {
                    if (res?.data) {
                        setCurrentPageStatus({
                            pageType: PageType.ChatAgentWindow,
                            additionInfo: {
                                isReconnected: true
                            }
                        });
                    } else {
                        clearInfo();
                    }
                });
        } else if (connectWithChatStatus() == ConnectWith.ChatBot) {
            hasChatBotConversationAndToken() &&
                getChatBotConversationState()?.then((res) => {
                    if (res && res > PermissionType.NONEEDDISCONNECTED) {
                        setCurrentPageStatus({
                            pageType: PageType.ChatBotWindow,
                            additionInfo: {
                                isReconnected: true
                            }
                        });
                    } else {
                        clearInfo();
                    }
                });
        } else if (noActiveChatBot() && initialState.IsClose) {
            setCurrentPageStatus({
                pageType: PageType.ChatClose,
                additionInfo: {
                    message: initialState.CloseMsg
                }
            });
        }
        window.addEventListener('message', msgFromFatherPage);
        return () => {
            window.removeEventListener('message', msgFromFatherPage);
        };
    }, []);

    const msgFromFatherPage = (e: MessageEvent<PostMessageFromPage>) => {
        if (e.data.key && e.data.key == 'chat') {
            if (!e.data.noAction) {
                setValue(LocalStorageType.CHAT_HAS_RED_TIPS, false);
                setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, true);
                setChatRedTipsStatus({
                    status: ChatRedTipsStatus.open
                });
                chatPostMessage({ action: 'removeRedTip' });
            }
            if (e.data.type != chatLayoutBasicInfoRef.current?.type) {
                let otherInfo = {
                    category: e.data.category,
                    topic: e.data.topic,
                    reason: e.data.reason,
                    type: e.data.type
                };

                setChatLayoutBasicInfo((prev) => {
                    chatLayoutBasicInfoRef.current = {
                        ...prev,
                        ...otherInfo
                    };
                    return chatLayoutBasicInfoRef.current;
                });
            }
            if (
                e.data.type == ChatType.ChatDirectly &&
                !!initialState.AdditionInfo.encryptedCustomerNumber &&
                !isChatting() &&
                chatLayoutBasicInfoRef.current &&
                e.data.fromHeader
            ) {
                saveChatBasicInfoByChatDirectlyType(chatLayoutBasicInfoRef.current);
                initialPage();
                setCurrentPageStatus({
                    pageType: PageType.ChatAgentWindow
                });
                chatPostMessage({ action: 'initialHeaderVal' });
            }
        }
    };

    return (
        <>
            <dialog
                className={cn('NE-chat-popup', {
                    'is-agent-offline': currentChatLayoutStatus.avatarType == AvatarType.offLine
                })}
                open
            >
                {ChatEnhancer}
            </dialog>
        </>
    );
};

NgChatLayout.displayName = 'NgChatLayout';
