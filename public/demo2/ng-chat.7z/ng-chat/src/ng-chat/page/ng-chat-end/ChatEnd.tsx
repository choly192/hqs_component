import React, { FC, useEffect, useState } from 'react';
import { useLocalStorage } from '../../../common/hook/useLocalStorage';
import { LocalStorageType } from '../../../common/storage/local/nameMapping';

interface ChatEndProps {
    handleLeaveChatClick: () => void;
    handleContinueChatClick: () => void;
    needShowEmailCheckBox?: boolean;
}
export const ChatEnd: FC<ChatEndProps> = ({
    handleLeaveChatClick,
    handleContinueChatClick,
    needShowEmailCheckBox = true,
}) => {
    const { getValue, setValue } = useLocalStorage();

    return (
        <>
            <div className="NE-chat-exit show-confirm is-visible">
                <div className="confirm-exit">
                    <i className="fa fa-info-circle"></i>
                    <h5>Are you sure you want to end this chat?</h5>
                    {needShowEmailCheckBox && (
                        <label className="form-checkbox">
                            <input
                                type="checkbox"
                                defaultChecked={
                                    getValue(LocalStorageType.CHAT_BASIC_INFO)?.sendMeTranscript
                                }
                                onChange={(e) => {
                                    let basicInfo = getValue(LocalStorageType.CHAT_BASIC_INFO);
                                    basicInfo.sendMeTranscript = e.target.checked;
                                    setValue(LocalStorageType.CHAT_BASIC_INFO, basicInfo);
                                }}
                            />
                            <span className="form-checkbox-title">
                                Send a chat transcript to:{' '}
                                <span className="email">
                                    {getValue(LocalStorageType.CHAT_BASIC_INFO).emailAddress}
                                </span>
                            </span>
                        </label>
                    )}
                    <div className="exit-buttons">
                        <button
                            className="btn btn-primary leave-chat"
                            onClick={() => {
                                handleLeaveChatClick && handleLeaveChatClick();
                            }}
                        >
                            Yes, leave chat
                        </button>
                        <button
                            className="btn continue-chat"
                            onClick={() => {
                                handleContinueChatClick && handleContinueChatClick();
                            }}
                        >
                            No, continue chatting
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};
ChatEnd.displayName = 'ChatEnd';
