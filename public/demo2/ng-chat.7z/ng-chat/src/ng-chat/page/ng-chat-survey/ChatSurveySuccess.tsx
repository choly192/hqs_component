import React, { FC, useState } from 'react';
import { useSetRecoilState } from 'recoil';

import { Button } from '../../../common/component';

import { currentPageStatusAtom, PageType } from '../../atom';
import { useChatUtils } from '../../hooks';

export const ChatSurveySuccess: FC = () => {
    const setCurrentPageStatus = useSetRecoilState(currentPageStatusAtom);
    const { hideChatWindow } = useChatUtils();

    return (
        <>
            <div className="NE-chat-exit is-visible show-message">
                <div className="exit-message">
                    <i className="fa fa-check-circle"></i>
                    <h5>Thanks for your valuable feedback!</h5>
                </div>
            </div>
            <div className="NE-chat-input-bar show-close">
                <div className="columns close-bar">
                    <div className="column">
                        <Button
                            text="close"
                            className="btn btn-secondary NE-close-now"
                            onClick={() => {
                                hideChatWindow();
                            }}
                        />
                    </div>
                </div>
            </div>
        </>
    );
};
