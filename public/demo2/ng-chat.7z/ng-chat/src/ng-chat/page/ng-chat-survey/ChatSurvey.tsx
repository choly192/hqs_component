import React, { FC, useState, useEffect, useRef } from 'react';
import { useSetRecoilState } from 'recoil';
import { RatingEggs } from '../../component/ratingEgg/RatingEggs';
import { Button } from '../../../common/component';
import { LoadingBackdrop, DialogBackdrop } from '../../component';
import { currentPageStatusAtom, PageType } from '../../atom';
import { CustomerFeedbackEntityResponse } from '../../models/chatSurvey/chat-survey-respones.model';
import { getOSInfo } from '../../utils/getOSInfo.util';
import { getBrowserInfo } from '../../utils/getBrowserInfo.util';
import { useLocalStorage } from '../../../common/hook';
import { LocalStorageType } from '../../../common/storage';
import { ChatSurveyTextarea } from '../../component/ChatSurveyTextarea';
import { useChatUtils, useChatSurveyAPI } from '../../hooks';

export const ChatSurvey: FC = () => {
    const {
        getChatSurveyInfo,
        submitFeedback,
    } = useChatSurveyAPI()
    const { hideChatWindow } = useChatUtils();

    const { getValue, setValue, remove } = useLocalStorage();
    const setCurrentPageStatus = useSetRecoilState(currentPageStatusAtom);
    const [chatSurveyInfo, setChatSurveyInfo] = useState<CustomerFeedbackEntityResponse>({
        HashCode: '',
        Questions: [],
    });

    const [showHeader, setShowHeader] = useState<boolean>(false)
    const [disabledSubmitButton, setDisabledSubmitButton] = useState<boolean>(true)
    const [submitDialogState, setSubmitDialogState] = useState<boolean>(false);
    const [isMaskLoading, setMaskIsLoading] = useState<boolean>(false);
    const [isLoading, setIsLoading] = useState<boolean>(true);

    const isSubmitRef = useRef<boolean>(false);
    const localStorageDataRef = useRef<{ [key: string]: any }>();

    useEffect(() => {
        getChatSurveyInfo()?.then((res) => {
            if (res.data) {
                setIsLoading(false);
                setShowHeader(true);
                setDisabledSubmitButton(false);
                let surveyInfo = res?.data;
                surveyInfo?.Questions?.forEach((t: { Value: string; error: boolean }) => {
                    (t.Value = ''), (t.error = false);
                });
                surveyInfo && setChatSurveyInfo(surveyInfo);
            }else{
                hideChatWindow();
            }
        });
    }, []);

    useEffect(() => {
        localStorageDataRef.current = {
            chatSource: getValue(LocalStorageType.CHAT_SOURCE),
            emailAddress: getValue(LocalStorageType.CHAT_BASIC_INFO).emailAddress,
            fullName: getValue(LocalStorageType.CHAT_BASIC_INFO).fullName,
            sessionID: getValue(LocalStorageType.CHAT_CONVERSATION_ID),
            agentName: getValue(LocalStorageType.CHAT_AGENT_NAME),
        };
    }, []);

    const submit = () => {
        setMaskIsLoading(true);
        if (!isSubmitRef.current) {
            isSubmitRef.current = true;
            const questionsData = chatSurveyInfo?.Questions;
            questionsData?.forEach((item) => {
                if (item.IsRequired && item.Value == '') {
                    item.error = true;
                }
            });
            const submission: boolean = questionsData?.every(
                (question: { error: boolean }) => question.error === false,
            );
            setChatSurveyInfo((pre: any) => {
                return { ...pre, Questions: questionsData };
            });

            const Answers = chatSurveyInfo?.Questions?.map(
                (i: { QuestionMasterId: number; Value: string }) => {
                    return { QuestionMasterId: i.QuestionMasterId, Value: i.Value };
                },
            );
            if (submission) {
                const {
                    emailAddress = '',
                    fullName = '',
                    sessionID = '',
                    agentName = '',
                    chatSource = '',
                } = localStorageDataRef.current ?? {};

                submitFeedback({
                    body: {
                        logingEmailAddress: emailAddress,
                        CommentHashCode: chatSurveyInfo?.HashCode,
                        ScreenResolution: screen?.width + 'x' + screen?.height ?? '',
                        PreviousPage: document?.referrer ?? '',
                        RequestURL: window?.location?.href ?? '',
                        UserAgent: window.navigator?.userAgent ?? '',
                        OSName: getOSInfo()?.name ?? '',
                        OSVersion: getOSInfo()?.version ?? '',
                        BrowserVersion: getBrowserInfo()?.client.version ?? '',
                        BrowserName: getBrowserInfo()?.client.name ?? '',
                        Variables: [
                            { Key: 'LoginName', Value: fullName },
                            { Key: 'SessionID', Value: sessionID },
                            { Key: 'AgentName', Value: agentName },
                            { Key: 'Source', Value: chatSource },
                        ],
                        Answers,
                    },
                })?.then((res) => {
                    if (res) {
                        if (res?.data?.Success) {
                            setValue(LocalStorageType.CHAT_HAS_SUBMIT_FEEDBACK, true);
                            remove(LocalStorageType.CHAT_AGENT_NAME);
                            setCurrentPageStatus({
                                pageType: PageType.ChatSurveySuccess,
                            });
                        }
                        !res?.data && setSubmitDialogState(true);
                    }
                    isSubmitRef.current = false;
                    setMaskIsLoading(false);
                });
            } else {
                isSubmitRef.current = false;
                setMaskIsLoading(false);
            }
        }
    };

    return (
        <>
            {/* <div className="NE-chat-content show-chat " style={{ top: 80 }}>
                <div className="chat-section">
                </div>
            </div> */}
            <div className="NE-chat-exit show-survey is-visible">
                <div className="experience-survey">
                    <a
                        className="NE-close-now"
                        title="close chat"
                        onClick={
                            () => {
                                showHeader&&hideChatWindow();
                            }
                        }
                    >
                        <i className="fa fa-times"></i>
                    </a>
                    {showHeader && <h5>Please rate your chat experience</h5>}
                    <div className="ratings">
                        {chatSurveyInfo?.Questions.map((item, index) => {
                            return !!item.Answers && item.Answers.length > 0 ? (
                                <RatingEggs
                                    questionMasterId={item.QuestionMasterId}
                                    isRequired={item.IsRequired}
                                    questionText={item.QuestionText}
                                    answers={item.Answers}
                                    error={item.error}
                                    questionType={item.QuestionType}
                                    key={`Questions-${item.QuestionMasterId}`}
                                    onClick={(val, Id) => {
                                        setChatSurveyInfo((pre) => {
                                            pre?.Questions.forEach((t) => {
                                                if (t.QuestionMasterId == Id) {
                                                    t.Value = val;
                                                    t.error = false;
                                                }
                                            });
                                            return { ...pre };
                                        });
                                    }}
                                />
                            ) : (
                                    <ChatSurveyTextarea
                                        key={item.QuestionMasterId}
                                        label={item.QuestionText}
                                        isRequired={item.IsRequired}
                                        questionMasterId={item.QuestionMasterId}
                                        onBlur={(val, Id) => {
                                            setChatSurveyInfo((pre) => {
                                                pre?.Questions.forEach((t) => {
                                                    if (t.QuestionMasterId == Id) {
                                                        t.Value = val ?? '';
                                                    }
                                                });
                                                return { ...pre };
                                            });
                                        }}
                                    />
                                );
                        })}
                    </div>
                </div>
            </div>
            <div className={`NE-chat-input-bar show-submit ${disabledSubmitButton && 'disabled'}`}>
                <div className="columns submit-bar">
                    <div className="column">
                        <Button
                            text="SUBMIT"
                            className="btn btn-primary submit-btn"
                            disabled={disabledSubmitButton}
                            onClick={submit}
                        />
                    </div>
                </div>
            </div>
            {isLoading && <LoadingBackdrop />}
            {isMaskLoading && <LoadingBackdrop isShowMask={true} />}
            {submitDialogState && (
                <DialogBackdrop
                    onClick={(e) => {
                        setSubmitDialogState(false);
                    }}
                />
            )}
        </>
    );
};
ChatSurvey.displayName = 'ChatSurvey';
