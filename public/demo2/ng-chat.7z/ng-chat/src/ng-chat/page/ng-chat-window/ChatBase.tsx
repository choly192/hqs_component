import React, { useState, useRef, useMemo, useCallback, useEffect } from 'react';
import { ChatInputBar, Header, HeaderProps } from '../../component';
import { useInitialState } from '../../../common/server/interceptors/context/GlobalContext';
import { InitialState, ChatWindowChildrenType } from '../../types';
import { useRecoilValue } from 'recoil';
import { chatWindowMsgListAtom } from '../../atom';
import { isIE } from '../../utils';

interface RenderChildrenProps {
    ref: React.Ref<any>;
    setHeaderInfo: (data: any) => any;
    onMsgListScroll: (wait: number) => void;
    renderInputBar: ChatWindowChildrenType;
}

interface ChatBaseProps {
    children: (props: RenderChildrenProps) => JSX.Element;
}

export const ChatBase: React.FC<ChatBaseProps> = ({ children }) => {
    const initialState = useInitialState<InitialState>();
    const windowChatMsgList = useRecoilValue(chatWindowMsgListAtom);

    const [headerInfo, setHeaderInfo] = useState<HeaderProps>({ showCloseIcon: false });
    const msgScrollRef = useRef<HTMLUListElement>(null);
    const chatRef = useRef<any>(null);
    const chatContentRef = useRef<HTMLDivElement>(null);

    const handleMsgScroll = useCallback(
        (wait: number = 0) => {
            setTimeout(() => {
                isIE()
                    ? chatContentRef?.current?.scrollIntoView(false)
                    : chatContentRef?.current?.scrollTo(
                        0,
                        msgScrollRef?.current?.offsetHeight ?? 0,
                    );
            }, wait);
        },
        [msgScrollRef.current]
    );

    const handleCollapseIcon = useCallback(() => {
        chatRef.current.onCollapse();
    }, [chatRef.current]);

    const handleClose = useCallback(() => {
        chatRef.current.onClose();
    }, [chatRef.current]);

    const renderFooter = useMemo(() => children({
        ref: chatRef,
        setHeaderInfo,
        onMsgListScroll: handleMsgScroll,
        renderInputBar: (props) => (
            <ChatInputBar {...props} />
        ),
    }), [chatRef, children]);

    return (
        <>
            <Header
                noName={headerInfo?.noName}
                styles={headerInfo?.styles}
                member={headerInfo?.member}
                showCloseIcon={headerInfo?.showCloseIcon ?? false}
                showRedTips={headerInfo?.showRedTips}
                handleCollapseIcon={handleCollapseIcon}
                handleCloseIcon={handleClose}
                isChatBot={headerInfo?.isChatBot}
            />
            <div
                className="NE-chat-content show-chat"
                style={{
                    top: initialState?.AdditionInfo?.injectionType == 'popup' ? '95px' : '59px'
                }}
                ref={chatContentRef}
            >
                <div className="chat-section">
                    <ul className="chat-entries" ref={msgScrollRef}>
                        {windowChatMsgList &&
                            windowChatMsgList.length > 0 &&
                            windowChatMsgList.map((t, index) => t.ele(index, t.additionInfo))}
                    </ul>
                </div>
            </div>
            {renderFooter}
        </>
    );
};
