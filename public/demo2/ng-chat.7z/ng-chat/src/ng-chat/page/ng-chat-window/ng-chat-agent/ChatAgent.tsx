import React, { useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as _ from 'lodash';
import { useRecoilState, useRecoilValue, useSetRecoilState } from 'recoil';

import {
    beforeUploadFileCheck,
    PermissionData,
    UploadReqData,
    useUploadPermission,
    useUploadProgress,
} from '../../../../common/component/upload';
import { useLocalStorage } from '../../../../common/hook';
import { ChatMsg, ChatStatus, LocalStorageType } from '../../../../common/storage';
import { useInitialState } from '../../../../common/server/interceptors/context/GlobalContext';

import { ChatInputBarRefMethod, DialogBackdrop, LoadingBackdrop } from '../../../component';
import {
    AvatarType,
    chatLayoutBasicInfoAtom,
    ChatRedTipsStatus,
    ChatRedTipsStatusAtom,
    chatWindowMsgListAtom,
    currentChatLayoutStatusAtom,
    currentPageStatusAtom,
    PageType,
} from '../../../atom';
import { HeaderIcon, NoticeConst } from '../../../const/browser';
import {
    chatPostMessage,
    checkIsAttachment,
    collapsePopup,
    convertDate,
    ConvertPrefix,
    getAgentChatData,
    GetAttachmentInfo,
    hasAgentConversationAndToken,
    isChatting,
    keepAlive,
    RenderChatMsg,
    renderMsgUtil,
    saveAgentInfoToLocalStorage,
    saveChatMessage,
} from '../../../utils';
import { CreateAgentChatResponse, GuestCustomerMessageResponse, MemberEntity } from '../../../models';
import { useChatAgentAPI, useChatAPI, useChatUtils } from '../../../hooks';
import {
    ChatType,
    ChatWindowCompProps,
    ChatWindowCompRef,
    errTypeCustomFieldsKeyMapping,
    InitialState,
    MsgType,
    NoticeAdditionalInfo,
    RenderMsgByType,
    UserAdditionalInfo,
    UserMsgInfo,
} from '../../../types';
import { ChatEnd } from '../../ng-chat-end/ChatEnd';
import { BaseErrorCode, CreateAgentChatErrorCodeErrorCode } from '../../../const/server';

const { getValue, setValue, remove } = useLocalStorage();

const ChatAgent: React.ForwardRefRenderFunction<ChatWindowCompRef, ChatWindowCompProps> = ({
    setHeaderInfo,
    onMsgListScroll,
    renderInputBar,
}, ref) => {
    const setCurrentChatLayoutStatus = useSetRecoilState(currentChatLayoutStatusAtom);
    const [windowChatMsgList, setWindowChatMsgList] = useRecoilState(chatWindowMsgListAtom);
    const [currentPageStatus, setCurrentPageStatus] = useRecoilState(currentPageStatusAtom);
    const chatLayoutBasicInfo = useRecoilValue(chatLayoutBasicInfoAtom);
    const [chatRedTipsStatus, setChatRedTipsStatus] = useRecoilState(ChatRedTipsStatusAtom);

    const { clearInfo, setAgentCookie } = useChatUtils();
    const initialState = useInitialState<InitialState>();

    const {
        CreateAgentApi,
        getMemberState,
        memberTyping,
        getAgentMsgData,
        agentEnd,
        sendCustomerMessageToAgent,
        getAllMembersState,
        getConversationMessages,
        endConversation,
        getAttachmentFileLink,
        getAgentConversationState,
    } = useChatAgentAPI();
    const { getUploadReqParams } = useChatAPI();

    const { sendCustomerMsgFailed, hideChatWindow } = useChatUtils();

    const { onGetPermission } = useUploadPermission(false);
    const { onSendUpload, onUploadCancel } = useUploadProgress();
    const [permission, setPermission] = useState<PermissionData>();
    const [uploadReqParams, setUploadReqParams] = useState<UploadReqData>();

    const socketRef = useRef<WebSocket>();
    const conversationIdRef = useRef<string>();
    const memberIdRef = useRef<string>();
    const agentNameRef = useRef<string>();
    const intervalRef = useRef<NodeJS.Timeout>();
    const needScrollRef = useRef<boolean>(true);
    const inputRef = useRef<ChatInputBarRefMethod>(null);
    const connectToAgentRetryCounts = useRef<number>(0);
    const componentUnmountedRef = useRef<boolean>(false);
    const curRedTipsStatusRef = useRef<ChatRedTipsStatus>(ChatRedTipsStatus.open);

    const [inputStatus, setInputStatus] = useState<{ disabled: boolean }>({ disabled: true });
    const [isShowChatEnd, setIsShowChatEnd] = useState<boolean>(false);
    const [showErrorDialog, setShowErrorDialog] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(() => {
        handleGetReqParamsAndPermission();
        const tipsStatus = getValue(LocalStorageType.CHAT_WINDOW_IS_OPEN)
            ? ChatRedTipsStatus.open : ChatRedTipsStatus.close;
        setChatRedTipsStatus({
            status: tipsStatus,
        });
        const { member, otherBotWindowToAgent = false } = currentPageStatus.additionInfo ?? {};
        setHeaderInfo((prev) => ({
            ...prev,
            member,
            noName: !member,
            isChatBot: getValue(LocalStorageType.CHAT_STATE) === ChatStatus.BotToAgent
                || otherBotWindowToAgent,
        }));
        if (currentPageStatus.additionInfo?.isReconnected) {
            connectToAgentSuccess(getAgentChatData());
            getAllMembersState()?.then((response) => {
                if (response.data?.entities && response.data?.entities.length !== 0) {
                    let info = response.data.entities.find(
                        (t) =>
                            t.role.toLocaleUpperCase() == 'AGENT' &&
                            t.state.toUpperCase() == 'CONNECTED',
                    );
                    if (info && info.memberName) {
                        showAgentJoinMsg(info);
                    }

                    let msgList = getValue(LocalStorageType.CHAT_MSG_LIST) || [];
                    let maxChatTime = 0;
                    let maxMsgID = '';
                    if (msgList.length > 0) {
                        for (let i = 0; i < msgList.length; i++) {
                            let msg = msgList[i];
                            let currentDate = msg.sendDate ? new Date(msg.sendDate).getTime() : NaN;
                            if (msg.role == 'AGENT' && maxChatTime < currentDate) {
                                maxChatTime = currentDate;
                                maxMsgID = msg.messageId;
                            }
                        }
                    }

                    getConversationMessages({
                        body: {
                            msgId: maxMsgID,
                        },
                    })?.then((res) => res.data && showHistoryMessage(res.data));
                }
            });
        } else {
            setWindowChatMsgList((prevList) => {
                if (currentPageStatus.additionInfo?.botToAgentStatus) {
                    return prevList;
                }
                return [
                    ...renderMsgUtil([], MsgType.Notice, {
                        notice: NoticeConst.Connecting.value,
                        id: NoticeConst.Connecting.id,
                    }),
                ];
            });
            connectToAgent();
        }

        return () => {
            intervalRef.current && clearInterval(intervalRef.current);
            socketRef.current && socketRef.current?.removeEventListener('open', openSocket);
            componentUnmountedRef.current = true;
        };
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            let currentRedTips = (
                chatRedTipsStatus.status === ChatRedTipsStatus.close
                && getValue(LocalStorageType.CHAT_HAS_RED_TIPS)
            );

            curRedTipsStatusRef.current = chatRedTipsStatus.status;
            setHeaderInfo((prev) => {
                if (prev.showRedTips !== currentRedTips) {
                    return {
                        ...prev,
                        showRedTips: currentRedTips,
                    };
                }
                return prev;
            });
            chatPostMessage({ action: currentRedTips ? 'showRedTip' : 'removeRedTip' });
        }, 1000);

        return () => {
            clearInterval(interval);
        }
    }, [chatRedTipsStatus]);

    useEffect(() => {
        if (needScrollRef.current) {
            onMsgListScroll();
        }
        needScrollRef.current = true;
    }, [windowChatMsgList, onMsgListScroll]);

    useImperativeHandle(ref, () => ({
        onCollapse: handleCollapseIcon,
        onClose: handleClose,
    }));

    const handleGetReqParamsAndPermission = useCallback(async () => {
        try {
            const reqParams = await getUploadReqParams();
            const { host = '', nvtc = '', authorization = '' } = reqParams?.data ?? {};
            if (host && authorization) {
                const query: UploadReqData = {
                    bizType: 7,
                    host,
                    header: {
                        nvtc,
                        Authorization: authorization,
                    },
                    options: {
                        EncryptedCustomerNumber: initialState.AdditionInfo.encryptedCustomerNumber,
                    },
                };
                const { permission: permissionData } = await onGetPermission(query);

                setPermission(permissionData);
                setUploadReqParams(query);
            }
        } catch (e) {
            setPermission(undefined);
            setUploadReqParams(undefined);
        }
    }, [onGetPermission]);

    const connectToAgent = () => {
        CreateAgentApi()?.then((res) => {
            if (res.data && res.errorCode == CreateAgentChatErrorCodeErrorCode.NO_ERROR) {
                res.data && connectToAgentSuccess(res?.data);
            } else if (res.errorCode == CreateAgentChatErrorCodeErrorCode.CHAT_UNAVAILABLE) {
                setCurrentPageStatus({
                    pageType: PageType.ChatClose,
                    additionInfo: {
                        message: res.errorMessage,
                    },
                });
            } else {
                switchBotOrAgentFail();
            }
        });
    };

    const connectToAgentSuccess = (res: CreateAgentChatResponse) => {
        setHeaderInfo((prev) => {
            return {
                ...prev,
                showCloseIcon: true,
            };
        });
        if (res && res?.conversationID) {
            conversationIdRef.current = res?.conversationID;
            memberIdRef.current = res.memberId;
            !currentPageStatus.additionInfo?.isReconnected && saveAgentInfoToLocalStorage(res);
            
            setWindowChatMsgList((prevList) => {
                if (
                    currentPageStatus.additionInfo?.botToAgentStatus ||
                    currentPageStatus.additionInfo?.otherBotWindowToAgent
                ) {
                    prevList = prevList.filter(
                        (t) =>
                            !(
                                t.type == MsgType.Notice &&
                                (t.additionInfo as NoticeAdditionalInfo).id ==
                                    NoticeConst.ChatBotToAgent.id
                            )
                    );
                    if (currentPageStatus.additionInfo?.needShowQuestion) {
                        prevList = getInitialQuestion();
                    }
                } else {
                    prevList = getInitialQuestion();
                    if (getValue(LocalStorageType.CHAT_STATE) == ChatStatus.Chatting) {
                        return prevList;
                    }
                }
                return [
                    ...renderMsgUtil(prevList, MsgType.Notice, {
                        notice: NoticeConst.AgentConnect.value,
                        id: NoticeConst.AgentConnect.id,
                    }),
                ];
            });
            res && res?.conversationID && createWebSocket(res?.socketUrl);
            if (
                !currentPageStatus.additionInfo?.isReconnected &&
                chatLayoutBasicInfo.type !== ChatType.ChatDirectly
            ) {
                setAgentCookie(ChatStatus.Waiting);
            }
        } else {
            switchBotOrAgentFail();
        }
    };

    const getInitialQuestion = () => {
        let chatBasicInfo = getValue(LocalStorageType.CHAT_BASIC_INFO);
        let showTranslate = !!(
            (chatBasicInfo.questionTranslate && chatBasicInfo.questionTranslate.length > 0) ||
            getValue(LocalStorageType.CHAT_LANGUAGE) != 'en'
        );
        return renderMsgUtil([], MsgType.User, {
            msgList: [
                {
                    oriMsg: chatBasicInfo.question,
                    translateMsg: chatBasicInfo.questionTranslate
                        ? chatBasicInfo.questionTranslate
                        : showTranslate
                        ? chatBasicInfo.question
                        : '',
                    isTranslated: showTranslate,
                    date: chatBasicInfo.dateTime ? new Date(chatBasicInfo.dateTime) : new Date()
                }
            ],
            time: convertDate(chatBasicInfo.dateTime)
        });
    };

    const switchBotOrAgentFail = () => {
        if (currentPageStatus.additionInfo?.botToAgentStatus) {
            botToAgentFailed();
        } else {
            connectToAgentFailed();
        }
    };

    const botToAgentFailed = () => {
        if (
            initialState.Config.BizChatBot.MaxConnectToAgentRetryCounts &&
            connectToAgentRetryCounts.current <
                initialState.Config.BizChatBot.MaxConnectToAgentRetryCounts
        ) {
            connectToAgentRetryCounts.current += 1;
            connectToAgent();
        } else {
            setWindowChatMsgList((prevList) => {
                return prevList.filter(
                    (t) =>
                        !(
                            t.type == MsgType.Notice &&
                            (t.additionInfo as NoticeAdditionalInfo).id ==
                                NoticeConst.ChatBotToAgent.id
                        ),
                );
            });
            connectToAgentFailed();
        }
    };

    const connectToAgentFailed = () => {
        clearInfo();
        setValue(LocalStorageType.CHAT_STATE, ChatStatus.Ended);
        remove(LocalStorageType.CHAT_AGENT_NAME);
        setWindowChatMsgList((prevList) => {
            return [
                ...renderMsgUtil(
                    currentPageStatus.additionInfo?.botToAgentStatus ? prevList : [],
                    MsgType.Notice,
                    {
                        notice: NoticeConst.AgentConnectFailed.value,
                        id: NoticeConst.AgentConnectFailed.id,
                    },
                ),
            ];
        });
        setHeaderInfo((prev) => {
            return {
                ...prev,
                showCloseIcon: true,
            };
        });
        setAgentCookie(ChatStatus.Ended);
    };

    const createWebSocket = (socketUrl: string) => {
        if (socketUrl) {
            try {
                socketRef.current = new WebSocket(socketUrl);
                socketRef.current.addEventListener('open', openSocket);
                socketRef.current.addEventListener('message', getGuestWebChatMessage);
                // socketRef.current.addEventListener('error', () => reConnectedWebSocket(socketUrl));
                socketRef.current.addEventListener('close', function (event) {
                    if (!componentUnmountedRef.current) {
                        intervalRef.current && clearInterval(intervalRef.current);
                        reConnectedWebSocket(socketUrl);
                    }
                });
                socketRef.current.addEventListener('error', function(err) {
                    console.log(err);
                });
            } catch (e) {
                reConnectedWebSocket(socketUrl);
            }
        }
    };

    const reConnectedWebSocket = (socketUrl: string) => {
        if (!isChatting()) {
            return;
        }
        setTimeout(() => {
            createWebSocket(socketUrl);
        }, 2000);
    };

    const removeTyping = _.debounce(
        () => {
            setWindowChatMsgList((prevList) => {
                return prevList.filter((t) => t.type !== MsgType.Typing);
            });
            needScrollRef.current = false;
        },
        3000,
        {
            leading: false,
            trailing: true,
        },
    );

    const sendUserTyping = useCallback(_.debounce(() => memberTyping(), 5000, {
        leading: true,
        trailing: false,
    }), []);

    const openSocket = () => {
        setHeaderInfo((prev) => {
            return {
                ...prev,
                showCloseIcon: true,
            };
        });
        if (!isChatting()) {
            return;
        }
        intervalRef.current = setInterval(() => {
            keepAlive(socketRef.current as WebSocket);
        }, 3000);

        if (hasAgentConversationAndToken() && memberIdRef.current) {
            getAgentConversationState()?.then((res) => {
                if (!res?.data) {
                    showChatEnd();
                }
            });
        }
    };

    const getGuestWebChatMessage = (event) => {
        let msg = JSON.parse(event?.data);
        if (msg.metadata) {
            switch (msg.metadata.type.toLocaleLowerCase()) {
                case 'message':
                    getMessageFromWebSocket(msg);
                    break;
                case 'member-change':
                    getMemberChangeFromWebSocket(msg);
                    break;
                case 'typing-indicator':
                    getMemberTypeFromWebSocket(msg);
                    break;
                default:
                    break;
            }
        }
    };

    const getMemberTypeFromWebSocket = (message) => {
        if (
            message &&
            message.eventBody &&
            message.eventBody.sender &&
            message.eventBody.sender.id &&
            message.eventBody.sender.id != memberIdRef.current
        ) {
            setWindowChatMsgList((prevList) => {
                if (prevList.findIndex((t) => t.type == MsgType.Typing) > -1) {
                    return prevList;
                }
                return [...renderMsgUtil(prevList, MsgType.Typing, {})];
            });
            removeTyping();
        }
    };

    const getMessageFromWebSocket = (message) => {
        if (message) {
            // ignore member-join or member-leave
            if (message.eventBody && message.eventBody.bodyType.toLocaleLowerCase() == 'standard') {
                if (memberIdRef.current != message.eventBody.sender.id) {
                    //agent msg
                    getAgentMsgData({
                        body: {
                            agentMessage: message.eventBody.body,
                            targetLanguage: getValue(LocalStorageType.CHAT_LANGUAGE),
                            agentId: message.eventBody.sender.id,
                            msgID: message.eventBody.id,
                            agentName: agentNameRef.current,
                            sendTime: message.eventBody.timestamp
                                ? new Date(message.eventBody.timestamp).getTime()
                                : new Date().getTime(),
                        },
                    })?.then((res) => {
                        let agentMsgData = res.data;
                        // if (!getValue(LocalStorageType.CHAT_WINDOW_IS_OPEN)) {
                        if (curRedTipsStatusRef.current === ChatRedTipsStatus.close) {
                            setHeaderInfo((prev) => {
                                return {
                                    ...prev,
                                    showRedTips: true,
                                };
                            });
                            setValue(LocalStorageType.CHAT_HAS_RED_TIPS, true);
                            chatPostMessage({ action: 'showRedTip' });
                        }
                        let date = agentMsgData?.sendTime
                            ? new Date(agentMsgData?.sendTime)
                            : new Date();
                        setWindowChatMsgList((prevList) => {
                            return [
                                ...renderMsgUtil(prevList, MsgType.Agent, {
                                    msgList: [
                                        {
                                            oriMsg: agentMsgData?.originText ?? '',
                                            translateMsg: agentMsgData?.translateText ?? '',
                                            isTranslated: agentMsgData?.needTranslate,
                                            date: date,
                                        },
                                    ],
                                    time: convertDate(date),
                                }),
                            ];
                        });
                        saveChatMessage({
                            role: 'AGENT',
                            sendMessage: agentMsgData?.originText ?? '',
                            sendDate: date.toString(),
                            translateMessage: agentMsgData?.needTranslate
                                ? agentMsgData?.translateText ?? ''
                                : '',
                            targetLanguage: agentMsgData?.translateLanguageCode ?? '',
                            oriLanguage: agentMsgData?.oriLanguageCode ?? '',
                            messageId: agentMsgData?.messageId ?? '',
                        });
                        setAgentCookie(ChatStatus.Chatting);
                    });
                } else {
                    // customer msg
                    setTimeout(() => {
                        let msg = message.eventBody.body;
                        let id = message.eventBody.id;
                        let translateInfo = ConvertPrefix(msg);
                        let fileInfo = GetAttachmentInfo(translateInfo.oriMsg);
                        setWindowChatMsgList((prevList) => {
                            let needRemove = false;
                            prevList.forEach((t) => {
                                if (
                                    t.type == MsgType.User &&
                                    (t.additionInfo as UserAdditionalInfo).msgList.findIndex(
                                        (m) => m.msgId && m.msgId == id,
                                    ) > -1
                                ) {
                                    needRemove = true;
                                }
                            });
                            if (needRemove) {
                                return prevList;
                            }
                            return [
                                ...renderMsgUtil(prevList, MsgType.User, {
                                    msgList: [
                                        {
                                            oriMsg: translateInfo.oriMsg,
                                            translateMsg: translateInfo.translatedMsg,
                                            isTranslated: !!translateInfo.translatedMsg,
                                            isAttachment: checkIsAttachment(translateInfo.oriMsg),
                                            fileName: fileInfo.fileName,
                                            fileType: fileInfo.fileType,
                                            date: new Date(),
                                            msgId: id,
                                        },
                                    ],
                                }),
                            ];
                        });
                    }, 500);
                }
            }
        }
    };

    const getMemberChangeFromWebSocket = (message) => {
        if (
            message &&
            message.eventBody &&
            message.eventBody.member &&
            message.eventBody.member.id
        ) {
            // connected
            let memberId = message.eventBody.member.id;
            if (message.eventBody.member.state.toUpperCase() === 'CONNECTED') {
                if (memberIdRef.current == memberId) {
                    return;
                }
                getMemberState({
                    apiParam: `agentchat/${getValue(
                        LocalStorageType.CHAT_CONVERSATION_ID,
                    )}/members/${memberId}`,
                })?.then((res) => {
                    if (res.data) {
                        showAgentJoinMsg(res.data);
                    }
                });
            } else if (
                message.eventBody.member.state.toUpperCase() === 'DISCONNECTED' &&
                memberIdRef.current == memberId
            ) {
                // disconnected
                if (componentUnmountedRef.current) {
                    resetRecoilAndStorage();
                } else {
                    getMemberState()?.then((res) => {
                        if (res.data && res.data?.role?.toUpperCase() == 'CUSTOMER') {
                            if (
                                conversationIdRef.current !==
                                getValue(LocalStorageType.CHAT_CONVERSATION_ID)
                            ) {
                                return;
                            }

                            if (!isChatting()) {
                                showChatEnd();
                                return;
                            }
                            getAgentConversationState()?.then((response) => {
                                if (!response?.data) {
                                    showChatEnd();
                                    agentEnd();
                                }
                            });
                        }
                    });
                }
            }
        }
    };

    const resetRecoilAndStorage = () => {
        socketRef.current && socketRef.current.close();
        setWindowChatMsgList((prevList) => {
            const newMsgList = prevList
                .filter((item) => item.type !== MsgType.Actions)
                .map((item) => {
                    if (item.type === MsgType.User) {
                        const { additionInfo } = item;
                        const { msgList } = additionInfo as UserAdditionalInfo;
                        const newMsgList = msgList.map((item) => ({ ...item, retryFn: undefined }));

                        return {
                            ...item,
                            additionInfo: {
                                ...additionInfo,
                                msgList: newMsgList,
                            },
                        };
                    }
                    return item;
                });

            return [
                ...renderMsgUtil(newMsgList, MsgType.Notice, {
                    notice: NoticeConst.ChatEnded.value,
                    id: NoticeConst.ChatEnded.id,
                }),
            ];
        });
        // setCurrentChatLayoutStatus((prevState) => {
        //     return {
        //         ...prevState,
        //         avatarType: AvatarType.offLine,
        //     };
        // });
        // setValue(LocalStorageType.CHAT_STATE, ChatStatus.Ended);
        // setValue(LocalStorageType.CHAT_HAS_SUBMIT_FEEDBACK, false);
        // setAgentCookie(ChatStatus.Ended);
        chatPostMessage({
            action: 'showAvatarIcon',
            classes: 'is-agent-offline',
        });
    };

    const showChatEnd = () => {
        onUploadCancel();
        setInputStatus({ disabled: true });
        setValue(LocalStorageType.CHAT_HAS_SUBMIT_FEEDBACK, false);
        resetRecoilAndStorage();

        if (!componentUnmountedRef.current) {
            setCurrentChatLayoutStatus((prevState) => {
                return {
                    ...prevState,
                    avatarType: AvatarType.offLine,
                };
            });
            setValue(LocalStorageType.CHAT_STATE, ChatStatus.Ended);
            setAgentCookie(ChatStatus.Ended);
        }
    };

    const showAgentJoinMsg = (data: MemberEntity) => {
        if (data && data.role.toUpperCase() == 'AGENT') {
            if (agentNameRef.current !== data.memberName) {
                setWindowChatMsgList((prevList) => {
                    return [
                        ...renderMsgUtil(prevList, MsgType.Avatar, {
                            notice: `Chatting with ${data.memberName}`,
                            style: {
                                backgroundImage: data.avatarImageUrl
                                    ? `url('${data.avatarImageUrl}')`
                                    : '',
                            },
                        }),
                    ];
                });
                setCurrentChatLayoutStatus((prevState) => {
                    return {
                        ...prevState,
                        avatarType: AvatarType.None,
                    };
                });
                setValue(LocalStorageType.CHAT_AGENT_NAME, data.memberName);
                agentNameRef.current = data.memberName;
            }

            setHeaderInfo((prev) => {
                return {
                    ...prev,
                    noName: false,
                    styles: data.avatarImageUrl
                        ? {
                              backgroundImage: `url('${data.avatarImageUrl}')`,
                          }
                        : {
                              backgroundColor: '#cc4e00',
                              backgroundSize: '90%',
                          },
                    member: data?.memberName,
                    isChatBot: false,
                };
            });
            setInputStatus({ disabled: false });
            setValue(LocalStorageType.CHAT_STATE, ChatStatus.Chatting);
            chatPostMessage({
                style: `background-image:url(${
                    data.avatarImageUrl ??
                    `${initialState.Config.WebConfig.CDN.staticImageServer}${HeaderIcon}`
                })`,
                action: 'showAvatarIcon',
            });
            if (!currentPageStatus.additionInfo?.isReconnected) {
                setAgentCookie(ChatStatus.Chatting);
            }
        }
    };

    const showHistoryMessage = (messages: Array<GuestCustomerMessageResponse>) => {
        let msgList = getValue(LocalStorageType.CHAT_MSG_LIST) || [];
        if (messages && messages.length > 0) {
            for (let i = 0; i < messages.length; i++) {
                let msg = messages[i];
                if (msg.role.toLocaleUpperCase() === 'AGENT') {
                    let isExist = false;
                    for (let j = 0; j < msgList.length; j++) {
                        if (msgList[j].messageId == msg.messageId) {
                            isExist = true;
                            break;
                        }
                    }
                    if (!isExist) {
                        getAgentMsgData({
                            body: {
                                agentMessage: msg.sendMessage,
                                targetLanguage: getValue(LocalStorageType.CHAT_LANGUAGE),
                                agentId: msg.senderID,
                                msgID: msg.messageId,
                                agentName: agentNameRef.current,
                                sendTime: msg.sendTime,
                            },
                        })?.then((res) => {
                            let msg: ChatMsg = {
                                role: 'AGENT',
                                sendMessage: res.data?.originText ?? '',
                                sendDate: res.data?.sendTime
                                    ? new Date(res.data?.sendTime).toString()
                                    : new Date().toString(),
                                translateMessage: res.data?.translateText ?? '',
                                targetLanguage: res.data?.translateLanguageCode ?? '',
                                oriLanguage: res.data?.oriLanguageCode ?? '',
                                messageId: res.data?.messageId ?? '',
                            };
                            let needTranslate =
                                !!msg.targetLanguage &&
                                !!msg.translateMessage &&
                                msg.oriLanguage !== msg.targetLanguage &&
                                msg.sendMessage !== msg.translateMessage;
                            setWindowChatMsgList((prevList) => {
                                let date = msg.sendDate ? new Date(msg.sendDate) : new Date();
                                return [
                                    ...renderMsgUtil(prevList, MsgType.Agent, {
                                        msgList: [
                                            {
                                                oriMsg: msg.sendMessage,
                                                translateMsg: msg.translateMessage,
                                                isTranslated: needTranslate,
                                                date: date,
                                            },
                                        ],
                                        time: convertDate(date),
                                    }),
                                ];
                            });
                            msg.role = 'AGENT';
                            if (!needTranslate) {
                                msg.translateMessage = '';
                            }
                            saveChatMessage(msg);
                            setAgentCookie(ChatStatus.Chatting);
                        });
                    }
                }
            }
        }
        for (let index = 0; index < msgList.length; index++) {
            let message = msgList[index];
            let date = message.sendDate ? new Date(message.sendDate) : new Date();
            if (message.role.toLocaleUpperCase() === 'CUSTOMER') {
                let fileInfo = GetAttachmentInfo(message.sendMessage);
                setWindowChatMsgList((prevList) => {
                    return [
                        ...renderMsgUtil(prevList, MsgType.User, {
                            msgList: [
                                {
                                    oriMsg: message.sendMessage,
                                    translateMsg: message.translateMessage,
                                    isTranslated:
                                        !!message.targetLanguage &&
                                        message.oriLanguage !== message.targetLanguage,
                                    isAttachment: checkIsAttachment(message.sendMessage),
                                    fileName: fileInfo.fileName,
                                    fileType: fileInfo.fileType,
                                    date: date,
                                },
                            ],
                            time: convertDate(date),
                        }),
                    ];
                });
            } else if (message.role.toLocaleUpperCase() === 'AGENT') {
                let needTranslate =
                    !!message.targetLanguage &&
                    !!message.translateMessage &&
                    message.oriLanguage !== message.targetLanguage &&
                    message.sendMessage !== message.translateMessage;
                setWindowChatMsgList((prevList) => {
                    return [
                        ...renderMsgUtil(prevList, MsgType.Agent, {
                            msgList: [
                                {
                                    oriMsg: message.sendMessage,
                                    translateMsg: message.translateMessage,
                                    isTranslated: needTranslate,
                                    date: date,
                                },
                            ],
                            time: convertDate(date),
                        }),
                    ];
                });
            }
        }
    };

    const sendCustomerMsgToAgent = (data?: { sendTime: number, message: string }, isRetryMsg: boolean = false) => {
        needScrollRef.current = true;
        let inputVal = data?.message ?? inputRef?.current?.getValue() ?? '';
        let date = new Date();
        if (inputVal) {
            !isRetryMsg && setWindowChatMsgList((prevList) => {
                prevList = prevList.filter((i) => i.type !== MsgType.Typing);
                return [
                    ...renderMsgUtil(prevList, MsgType.User, {
                        msgList: [
                            {
                                oriMsg: inputVal,
                                translateMsg: '',
                                isTranslated:
                                    getValue(LocalStorageType.CHAT_LANGUAGE).toLocaleLowerCase() !==
                                    'en',
                                date: date,
                            },
                        ],
                    }),
                ];
            });

            sendCustomerMessageToAgent({
                body: {
                    message: inputVal,
                    sendTime: date.getTime(),
                    memberName: getValue(LocalStorageType.CHAT_BASIC_INFO)?.fullName,
                    sourceLanguage:
                        getValue(LocalStorageType.CHAT_LANGUAGE) == 'en'
                            ? getValue(LocalStorageType.CHAT_LANGUAGE)
                            : '',
                },
            })?.then((res) => {
                if (res.data && res.data.sendSuccess) {
                    const msgData: Partial<UserMsgInfo> = {
                        oriMsg: inputVal ?? '',
                        msgId: res.data?.msgId,
                        isTranslated: false,
                        date,
                        isRetryMsg: false,
                    };

                    if (
                        res.data.oriLanguage !== res.data.targetLanguage &&
                        res.data.translateMessage
                    ) {
                        msgData.isTranslated = true;
                        msgData.translateMsg = res.data?.translateMessage ?? '';
                    }
                    removeRepeatCustomerMsg(res.data.msgId);
                    handleWindowChatMsgListChange(msgData, isRetryMsg, data?.sendTime);

                    if (res.data.oriLanguage !== 'en') {
                        setValue(LocalStorageType.CHAT_LANGUAGE, res.data.oriLanguage);
                    }
                    saveChatMessage({
                        role: 'CUSTOMER',
                        sendMessage: res.data.oriMessage,
                        sendDate: res.data.pureCloudSendTime
                            ? new Date(res.data.pureCloudSendTime).toString()
                            : new Date().toString(),
                        translateMessage: res.data.translateMessage,
                        targetLanguage: res.data.targetLanguage,
                        oriLanguage: res.data.oriLanguage,
                        messageId: res.data.msgId,
                    });
                    setAgentCookie(ChatStatus.Chatting);
                } else {
                    const retryData = {
                        sendTime: data?.sendTime ?? date.getTime(),
                        message: inputVal,
                    };
                    sendCustomerMsgFailed(
                        retryData,
                        () => sendCustomerMsgToAgent(retryData, true),
                        {
                            isRetryRenderMsg: false,
                            isRemoveMsg: false,
                        },
                    );
                }
            });
        }
    };

    const removeRepeatCustomerMsg = (id) => {
        setWindowChatMsgList((prevList) => {
            prevList.length > 0 &&
                prevList.forEach((t) => {
                    if (t.type == MsgType.User && t.additionInfo) {
                        (t.additionInfo as UserAdditionalInfo).msgList = (t.additionInfo as UserAdditionalInfo).msgList.filter(
                            (m) => !(m.msgId && m.msgId == id),
                        );
                    }
                });
            return prevList;
        });
    };

    const handleClose = () => {
        onUploadCancel();
        if (isChatting()) {
            setIsShowChatEnd(true);
        } else {
            setWindowChatMsgList([]);
            if (getValue(LocalStorageType.CHAT_HAS_SUBMIT_FEEDBACK)) {
                hideChatWindow();
            } else {
                if (agentNameRef.current) {
                    setCurrentPageStatus({
                        pageType: PageType.ChatSurvey,
                    });
                } else {
                    hideChatWindow();
                }
            }
        }
    };

    const sendCustomerAttachmentMsgToAgent = (body, errMsg, date) => {
        sendCustomerMessageToAgent({ body })?.then((res) => {
            needScrollRef.current = false;
            if (res.data && res.data.sendSuccess) {
                removeRepeatCustomerMsg(res.data.msgId);
                handleWindowChatMsgListChange({
                    isUploading: false,
                    oriMsg: '',
                    progress: 100,
                    msgId: res.data.msgId,
                    date,
                });
                saveChatMessage({
                    role: 'CUSTOMER',
                    sendMessage: res.data.oriMessage,
                    sendDate: res.data.pureCloudSendTime
                        ? new Date(res.data.pureCloudSendTime).toString()
                        : new Date().toString(),
                    translateMessage: res.data.translateMessage,
                    targetLanguage: res.data.targetLanguage,
                    oriLanguage: res.data.oriLanguage,
                    messageId: res.data.msgId,
                });
                setAgentCookie(ChatStatus.Chatting);
            } else {
                sendCustomerMsgFailed({
                    message: errMsg,
                    sendTime: date.getTime(),
                    isAttachment: true,
                });
            }
        });
    };

    const handleWindowChatMsgListChange = (data: Partial<UserMsgInfo>, isRetryMsg?: boolean, prevDate?: number) => {
        setWindowChatMsgList((prevList) => {
            let list: Array<RenderChatMsg<RenderMsgByType, MsgType>> = [];

            prevList.forEach((t) => {
                if (t.type == MsgType.User) {
                    if (isRetryMsg) {
                        (t.additionInfo as UserAdditionalInfo).msgList = (t.additionInfo as UserAdditionalInfo).msgList
                            .filter((m) => m.date.getTime() !== prevDate);
                    } else {
                        (t.additionInfo as UserAdditionalInfo).msgList.forEach((item, index) => {
                            if (item.date.getTime() == data.date?.getTime()) {
                                (t.additionInfo as UserAdditionalInfo).msgList[index] = {
                                    ...item,
                                    ...data,
                                };
                            }
                        });
                    }

                    (t.additionInfo as UserAdditionalInfo).msgList.length > 0 && list.push(t);
                } else {
                    list.push(t);
                }
            });
            return isRetryMsg ? [
                ...renderMsgUtil(list, MsgType.User, {
                    msgList: [data as UserMsgInfo],
                }),
            ] : [...list];
        });
    };

    const handleUploadProgress = (progressEvent, date) => {
        needScrollRef.current = false;
        const progress = ((progressEvent.loaded / progressEvent.total) * 100) | 0;
        handleWindowChatMsgListChange({
            progress: progress > 95 ? 95 : progress,
            date,
        });
    };

    const handleAttachmentSend = async ({ file, rule, date, errMsg }) => {
        try {
            const [result] = await onSendUpload(file, uploadReqParams as UploadReqData, {
                rule,
                onUploadProgress: (progressEvent) => handleUploadProgress(progressEvent, date),
            });

            if (result.ErrorCode !== 100000) {
                throw result;
            }
            const errMsg = rule?.CustomFields?.UploadFailedRightBottomMsg || 'Failed to send';
            const { Result } = result;
            let message = Result.FileInfo;
            const { data } =
                (await getAttachmentFileLink({
                    query: {
                        message,
                    },
                })) ?? {};

            if (data?.Success && data?.shortUrl) {
                message = `${data.shortUrl} (This is attachment file link,file name is ${file.name})`;
            }
            needScrollRef.current = false;
            handleWindowChatMsgListChange({
                isUploading: false,
                date,
            });

            sendCustomerAttachmentMsgToAgent(
                {
                    message,
                    sendTime: date.getTime(),
                    MemberId: memberIdRef.current,
                    ConversationID: getValue(LocalStorageType.CHAT_CONVERSATION_ID),
                    Token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN),
                    memberName: getValue(LocalStorageType.CHAT_BASIC_INFO)?.fullName,
                    sourceLanguage: 'en',
                },
                errMsg,
                date,
            );
        } catch (e) {
            sendCustomerMsgFailed({
                message: errMsg,
                sendTime: date.getTime(),
                isAttachment: true,
            });
        }
    };

    const handleUploadBefore = (files) => {
        const [file] = files;
        const { UploadRule = {}, Accept = [] } = permission ?? {};
        const fileType = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
        const key = Object.keys(UploadRule).find((val) => val.includes(fileType)) ?? '';
        const rule = UploadRule[key];
        const date = new Date();

        beforeUploadFileCheck({
            files,
            fileList: [],
            rules: UploadRule,
            accept: Accept,
        })
            .then(() => {
                const errMsg =
                    rule?.CustomFields?.UploadFailedMsg || 'Upload failed, please try again';

                setWindowChatMsgList((prevList) => {
                    return [
                        ...renderMsgUtil(prevList, MsgType.User, {
                            msgList: [
                                {
                                    oriMsg: '',
                                    date,
                                    isAttachment: true,
                                    fileName: file.name,
                                    isUploading: true,
                                    fileType,
                                    progress: 0,
                                },
                            ],
                            isError: false,
                        }),
                    ];
                });

                handleAttachmentSend({
                    file,
                    date,
                    rule,
                    errMsg,
                });
            })
            .catch((err) => {
                const { code } = err;
                let errMsg =
                    rule?.CustomFields?.[errTypeCustomFieldsKeyMapping[code]] ??
                    'Unsupported file type';

                setWindowChatMsgList((prevList) => {
                    return [
                        ...renderMsgUtil(prevList, MsgType.User, {
                            msgList: [
                                {
                                    oriMsg: errMsg,
                                    date,
                                    isAttachment: true,
                                    fileName: file.name,
                                    fileType,
                                },
                            ],
                            isError: true,
                        }),
                    ];
                });
            });
    };

    const handleCollapseIcon = () => {
        setChatRedTipsStatus({
            status: ChatRedTipsStatus.close,
        });
        collapsePopup();
    }

    return (
        <>
            {renderInputBar({
                accept: permission?.Accept?.join(',') ?? '',
                maxLength: 500,
                onUpload: handleUploadBefore,
                onClick: sendCustomerMsgToAgent,
                onInput: () => {
                    if (initialState?.Config?.BizChatAgent?.EnableTyping) {
                        let chatStatus = getValue(LocalStorageType.CHAT_STATE);
                        if (chatStatus == ChatStatus.Chatting || chatStatus == ChatStatus.Waiting) {
                            sendUserTyping();
                        }
                    }
                },
                onKeyUp: sendCustomerMsgToAgent,
                disabled: inputStatus?.disabled,
                showUploadIcon: !!initialState.AdditionInfo?.encryptedCustomerNumber &&
                    permission?.UploadEnabled,
                ref: inputRef,
            })}
            {isShowChatEnd && (
                <>
                    <ChatEnd
                        handleLeaveChatClick={() => {
                            if (
                                conversationIdRef.current &&
                                conversationIdRef.current !=
                                    getValue(LocalStorageType.CHAT_CONVERSATION_ID)
                            ) {
                                hideChatWindow();
                                return;
                            }
                            setLoading(true);
                            componentUnmountedRef.current = true;
                            setWindowChatMsgList([]);
                            endConversation()?.then((res) => {
                                setLoading(false);
                                if (res.errorCode == BaseErrorCode.NO_ERROR) {
                                    socketRef.current && socketRef.current.close();
                                    setShowErrorDialog(false);
                                    if (
                                        getValue(LocalStorageType.CHAT_STATE) == ChatStatus.Chatting
                                    ) {
                                        setCurrentPageStatus({ pageType: PageType.ChatSurvey });
                                    } else {
                                        hideChatWindow();
                                    }
                                    setValue(LocalStorageType.CHAT_STATE, ChatStatus.Ended);
                                    setAgentCookie(ChatStatus.Ended);
                                } else {
                                    setShowErrorDialog(true);
                                }
                            });
                        }}
                        handleContinueChatClick={() => {
                            setIsShowChatEnd(false);
                        }}
                    />
                    {showErrorDialog && (
                        <DialogBackdrop
                            onClick={() => {
                                setShowErrorDialog(false);
                            }}
                        />
                    )}
                    {loading && <LoadingBackdrop isShowMask={true} />}
                </>
            )}
        </>
    );
};

ChatAgent.displayName = 'ChatAgent';

export default React.forwardRef(ChatAgent);
