import React, { useEffect, useRef, useState, useImperativeHandle } from 'react';
import { useRecoilState, useSetRecoilState } from 'recoil';
import * as signalR from '@microsoft/signalr';
import { isEmpty } from 'lodash';
import { UploadPicturesDialog } from '../../../component/ChatBotMessage';
import { useLocalStorage } from '../../../../common/hook';
import { ChatStatus, LocalStorageType } from '../../../../common/storage';
import { useInitialState } from '../../../../common/server/interceptors/context/GlobalContext';
import { ChatInputBarRefMethod, HeaderProps } from '../../../component';
import { ChatBotEndType, ChatWindowCompProps, ChatWindowCompRef } from '../../../types';

import {
    chatPostMessage,
    collapsePopup,
    connectWithChatStatus,
    convertDate,
    hasChatBotConversationAndToken,
    isIE,
    RenderChatMsg,
    renderMsgUtil,
} from '../../../utils';
import {
    ActionButton,
    ActionsAdditionalInfo,
    ChatBotAdditionalInfo,
    ConnectWith,
    InitialState,
    MsgType,
    NoticeAdditionalInfo,
    RenderMsgByType,
    RichResponseTypeEnum,
    UserAdditionalInfo,
    UserMsgInfo,
} from '../../../types';
import {
    AvatarType,
    chatWindowMsgListAtom,
    currentChatLayoutStatusAtom,
    currentPageStatusAtom,
    PageType,
} from '../../../atom';
import { useChatAgentAPI, useChatAPI, useChatBotAPI, useChatUtils } from '../../../hooks';
import { HeaderIcon, NoticeConst } from '../../../const/browser';
import { InitialChatBotRes, PermissionType } from '../../../models';
import {
    defaultPermissionData,
    PermissionData,
    UploadReqData,
    useUploadPermission,
} from '../../../../common/component/upload';
import { ChatEnd } from '../../ng-chat-end/ChatEnd';

const { getValue, setValue } = useLocalStorage();

const ChatBot: React.ForwardRefRenderFunction<ChatWindowCompRef, ChatWindowCompProps> = ({
    setHeaderInfo,
    onMsgListScroll,
    renderInputBar,
}, ref) => {
    const { onGetPermission } = useUploadPermission(false);
    const setCurrentChatLayoutStatus = useSetRecoilState(currentChatLayoutStatusAtom);
    const [windowChatMsgList, setWindowChatMsgList] = useRecoilState(chatWindowMsgListAtom);
    const [currentPageStatus, setCurrentPageStatus] = useRecoilState(currentPageStatusAtom);

    const { initiateBot, getChatBotConversationState, getChatBotHistory } = useChatBotAPI();
    const { inAgentServiceTime } = useChatAgentAPI();
    const { getUploadReqParams } = useChatAPI();

    const {
        sendCustomerMsgFailed,
        hideChatWindow,
        setAgentCookie,
        resetChatBotLocalStorage,
    } = useChatUtils();

    const initialState = useInitialState<InitialState>();

    const [inputStatus, setInputStatus] = useState<{ disabled: boolean }>({ disabled: true });
    const [uploadDialogVisible, setUploadDialogVisible] = useState<boolean>(false);
    const [permissionData, setPermissionData] = useState<PermissionData>();
    const [actionBtnData, setActionBtnData] = useState<ActionButton>();
    const [alreadyUploaded, setAlreadyUploaded] = useState<boolean>(false);
    const [isShowChatEnd, setIsShowChatEnd] = useState<boolean>(false);

    const onlineRef = useRef<boolean>(true);
    const uploadReqParams = useRef<UploadReqData>();
    const connectionRef = useRef<signalR.HubConnection>();
    const connectionIDRef = useRef<string>();
    const chatBotHistoryLinkRef = useRef<string>();
    const inputRef = useRef<ChatInputBarRefMethod>(null);
    const retryCountRef = useRef<number>(0);
    const chatbotReq = useRef<string>();
    const componentUnmountedRef = useRef<boolean>(false);
    const botEndStatusRef = useRef<ChatBotEndType>(ChatBotEndType.Initial);

    useEffect(() => {
        handleGetReqParams();
        setWindowChatMsgList([]);
        setHeaderInfo((prev) => ({ ...prev, isChatBot: true }));
        if (
            initialState.Config.SocketConfig.ChatBotConnection?.HostAddress &&
            initialState.Config.SocketConfig.ChatBotConnection?.HubUrl
        ) {
            chatbotReq.current = `${initialState.Config.SocketConfig.ChatBotConnection?.HostAddress}${initialState.Config.SocketConfig.ChatBotConnection?.HubUrl}`;
        }
        if (currentPageStatus.additionInfo?.isReconnected) {
            connectWithPreCheck();
        } else {
            initConnect();
        }

        window.addEventListener('online', setOnlineStatus);
        window.addEventListener('offline', setOfflineStatus);

        return () => {
            window.removeEventListener('online', setOnlineStatus);
            window.removeEventListener('offline', setOfflineStatus);
            componentUnmountedRef.current = true;
        };
    }, []);

    useEffect(() => {
        onMsgListScroll();
    }, [windowChatMsgList, onMsgListScroll]);

    useImperativeHandle(ref, () => ({
        onCollapse: collapsePopup,
        onClose: handleClose,
    }));


    const handleGetReqParams = async () => {
        try {
            const reqParams = await getUploadReqParams();
            const { host = '', nvtc = '', authorization = '' } = reqParams?.data ?? {};
            if (host && authorization) {
                const query: UploadReqData = {
                    bizType: 6,
                    host,
                    header: {
                        nvtc,
                        Authorization: authorization,
                    },
                };
                uploadReqParams.current = query;
            }
        } catch (e) {
            uploadReqParams.current = undefined;
        }
    };

    const initConnect = () => {
        setWindowChatMsgList(() => {
            return [
                ...renderMsgUtil([], MsgType.Notice, {
                    notice: NoticeConst.Connecting.value,
                    id: NoticeConst.Connecting.id,
                }),
            ];
        });
        const basicInfo = getValue(LocalStorageType.CHAT_BASIC_INFO);
        initiateBot({
            body: {
                Broadcasting: true,
                Payload: {
                    EmailAddress: basicInfo.emailAddress,
                    Topic: basicInfo.topic,
                    Reason: basicInfo.reason,
                    InitialQuestion: basicInfo.question,
                    CustomerNumber: initialState.AdditionInfo.encryptedCustomerNumber,
                },
            },
        })?.then((res) => {
            if (res?.SessionId && res?.Token) {
                createChatBotWebSocket(res);
            } else {
                removeConnectingNotice();
                botToAgent(true);
            }
        });
    };

    const removeConnectingNotice = () => {
        setWindowChatMsgList((prevList) => {
            return prevList.filter(
                (t) =>
                    !(
                        t.type == MsgType.Notice &&
                        (t.additionInfo as NoticeAdditionalInfo).id == NoticeConst.Connecting.id
                    ),
            );
        });
    };

    const setOnlineStatus = () => {
        let reSession = false;
        if (connectWithChatStatus() == ConnectWith.ChatBot) {
            onlineRef.current = true;
            setInputStatus({ disabled: false });
            setHeaderInfo((rest) => ({ ...rest, showCloseIcon: true }));
            if (!connectionRef.current || connectionRef.current.state != 'Connected') {
                reSession = true;
                connectWithPreCheck();
            }

            setWindowChatMsgList((prevList) => {
                const newMsgList = prevList.filter(
                    (t) =>
                        !(
                            t.type == MsgType.Notice &&
                            (t.additionInfo as NoticeAdditionalInfo).id == NoticeConst.Connecting.id
                        ),
                );

                if (connectionRef?.current?.state === 'Connected') {
                    newMsgList.forEach((item) => {
                        if (item.type === MsgType.ChatBot) {
                            (item.additionInfo as ChatBotAdditionalInfo).isInteraction = true;
                        }
                    });
                }

                if (reSession) {
                    return [
                        ...renderMsgUtil(newMsgList, MsgType.Notice, {
                            notice: NoticeConst.Reconnect.value,
                            id: NoticeConst.Connecting.id,
                        }),
                    ];
                }

                newMsgList.forEach((item) => {
                    if (item.type === MsgType.Actions) {
                        (item.additionInfo as ActionsAdditionalInfo).visible = true;
                    }
                });
                return newMsgList;
            });
        }
    };

    const setOfflineStatus = () => {
        if (connectWithChatStatus() == ConnectWith.ChatBot) {
            onlineRef.current = false;
            setInputStatus({ disabled: true });
            setHeaderInfo((rest) => ({ ...rest, showCloseIcon: false }));
            setWindowChatMsgList((prevList) => {
                prevList.forEach((item) => {
                    if (item.type === MsgType.Actions) {
                        (item.additionInfo as ActionsAdditionalInfo).visible = false;
                    }

                    if (item.type === MsgType.ChatBot) {
                        (item.additionInfo as ChatBotAdditionalInfo).isInteraction = false;
                    }
                });
                return [
                    ...renderMsgUtil(prevList, MsgType.Notice, {
                        notice: NoticeConst.Offline.value,
                        id: NoticeConst.Connecting.id,
                    }),
                ];
            });
        }
    };

    const createChatBotWebSocket = (data: InitialChatBotRes) => {
        if (connectionRef.current) {
            stopConnection();
        }
        if (data && data.SessionId && data.Token && chatbotReq.current) {
            let cc: signalR.HubConnection;
            const protocol = new signalR.JsonHubProtocol();
            cc = new signalR.HubConnectionBuilder()
                .withUrl(`${chatbotReq.current}?sessionid=${data.SessionId}&token=${data.Token}`, {
                    skipNegotiation:
                        initialState.Config.SocketConfig.ChatBotConnection?.SkipNegoTiation,
                    transport: initialState.Config.SocketConfig.ChatBotConnection?.Transport ?? 1,
                })
                .withHubProtocol(protocol)
                .configureLogging(signalR.LogLevel.Warning)
                .build();
            cc.serverTimeoutInMilliseconds =
                initialState.Config.SocketConfig.ChatBotConnection?.ServerTimeoutInMilliseconds ??
                120000;
            cc.keepAliveIntervalInMilliseconds =
                initialState.Config.SocketConfig.ChatBotConnection
                    ?.KeepAliveIntervalInMilliseconds ?? 999999999;
            cc.on('UserMessage', (sender, data) => {
                let msgList: UserMsgInfo[];
                try {
                    const attachmentInfo = JSON.parse(data);
                    if (attachmentInfo?.Attachments && attachmentInfo.Attachments.length > 0) {
                        msgList = attachmentInfo.Attachments.map((item) => ({
                            oriMsg: item.DisplayName,
                            date: new Date(),
                        }));
                    } else {
                        msgList = [
                            {
                                oriMsg: data,
                                date: new Date(),
                            },
                        ];
                    }
                } catch (e) {
                    msgList = [
                        {
                            oriMsg: data,
                            date: new Date(),
                        },
                    ];
                }
                setWindowChatMsgList((prevList) => {
                    const newMsgList = prevList.filter((item) => item.type !== MsgType.Actions);
                    return [
                        ...renderMsgUtil(newMsgList, MsgType.User, {
                            msgList,
                        }),
                    ];
                });
            });
            cc.on('UserAttachmentMessage', (sender, data) => {
                try {
                    const uploadInfo = JSON.parse(data);

                    setAlreadyUploaded(uploadInfo?.AlreadyUploaded ?? false);
                } catch (e) {
                    setAlreadyUploaded(false);
                }
            });
            cc.on('BotMessage', async (sender, data) => {
                let suggestions = [];
                let actionButton;
                let msgData;
                try {
                    msgData = JSON.parse(data);
                    if (msgData && msgData.Metadata && msgData.Metadata.ConversationFinished) {
                        let metaData = msgData.Metadata;
                        if (metaData.ConnectToAgent) {
                            let connectionId =
                                connectionRef.current?.connectionId || connectionIDRef.current;
                            chatBotHistoryLinkRef.current = metaData.ChatHistory;
                            setWindowChatMsgList((prevList) => {
                                return [
                                    ...renderMsgUtil(prevList, MsgType.Notice, {
                                        notice: NoticeConst.ChatBotToAgent.value,
                                        id: NoticeConst.ChatBotToAgent.id,
                                    }),
                                ];
                            });
                            botEndStatusRef.current = ChatBotEndType.ToAgent;
                            if (connectionId == sender) {
                                botToAgent();
                            } else {
                                let timer = setInterval(() => {
                                    if (connectWithChatStatus() == ConnectWith.Agent) {
                                        clearInterval(timer);
                                        setCurrentPageStatus({
                                            pageType: PageType.ChatAgentWindow,
                                            additionInfo: {
                                                otherBotWindowToAgent: true,
                                                isReconnected: true,
                                                member: botEndStatusRef.current === ChatBotEndType.ToAgent ? 'Newegg Chat Bot' : '',
                                            },
                                        });
                                    } else if (getValue(LocalStorageType.CHAT_STATE) === ChatStatus.Ended) {
                                        clearInterval(timer);
                                        setWindowChatMsgList((prevList) => {
                                            const newMsgList = prevList.filter(
                                                (t) =>
                                                    !(
                                                        t.type == MsgType.Notice &&
                                                        (t.additionInfo as NoticeAdditionalInfo).id == NoticeConst.ChatBotToAgent.id
                                                    ),
                                            );

                                            return [
                                                ...renderMsgUtil(newMsgList, MsgType.Notice, {
                                                        notice: NoticeConst.AgentConnectFailed.value,
                                                        id: NoticeConst.AgentConnectFailed.id,
                                                    },
                                                ),
                                            ];
                                        });
                                    }
                                }, 1000);
                            }
                            return;
                        } else {
                            showChatEnd();
                            return;
                        }
                    }

                    const { RichResponses = [] } = msgData;
                    suggestions = msgData?.Suggestions ?? [];
                    actionButton = RichResponses.find(
                        (item) => item.Type === RichResponseTypeEnum.ActionButton,
                    );

                    if (!isEmpty(actionButton)) {
                        const permission = await handleGetPermissionData(actionButton);
                        actionButton = permission?.UploadEnabled && actionButton;
                        setPermissionData(permission);
                    }
                    setActionBtnData(actionButton);
                } catch (e) {
                    msgData = data;
                }
                setUploadDialogVisible(false);
                setWindowChatMsgList((prevList) => {
                    prevList = prevList.filter(
                        (t) =>
                            !(
                                t.type == MsgType.Notice &&
                                ((t.additionInfo as NoticeAdditionalInfo).id ==
                                    NoticeConst.ChatBotTimeout.id ||
                                    (t.additionInfo as NoticeAdditionalInfo).id ==
                                        NoticeConst.ChatBotUploadConfigError.id)
                            ),
                    );

                    let newChatMsgList = renderMsgUtil(prevList, MsgType.ChatBot, {
                        msgList: [
                            {
                                data: msgData,
                                onSendMessage: sendCustomerMsg,
                            },
                        ],
                    });

                    if (!isEmpty(suggestions) || !isEmpty(actionButton)) {
                        newChatMsgList = renderMsgUtil(newChatMsgList, MsgType.Actions, {
                            suggestions,
                            actionButton,
                            onSendMessage: sendCustomerMsg,
                            onUploadVisible: handleUploadDialog,
                            visible: true,
                        });
                    }

                    return [...newChatMsgList];
                });
            });
            cc.on('EndChat', (sender) => {
                if (botEndStatusRef.current === ChatBotEndType.Initial) {
                    botEndStatusRef.current = ChatBotEndType.BotEnd;
                }
                if (!componentUnmountedRef.current) {
                    showChatEnd();
                } else {
                    resetRecoilAndStorage();
                }
            });
            cc.on('TimeoutWarning', function (sender, message) {
                setWindowChatMsgList((prevList) => {
                    prevList = prevList.filter(
                        (t) =>
                            !(
                                t.type == MsgType.Notice &&
                                (t.additionInfo as NoticeAdditionalInfo).id ==
                                    NoticeConst.ChatBotTimeout.id
                            ),
                    );
                    return [
                        ...renderMsgUtil(prevList, MsgType.Notice, {
                            notice: message,
                            id: NoticeConst.ChatBotTimeout.id,
                        }),
                    ];
                });
            });

            cc.on('ClientConnectionID', function (sender, message) {
                connectionIDRef.current = message;
            });
            cc.onclose((error) => {
                if (!error) {
                    return;
                }
                if (error.toString().toLowerCase().includes('timeout')) {
                    setWindowChatMsgList((prevList) => {
                        const newList = prevList.filter((item) => item.type !== MsgType.Notice);
                        return [
                            ...renderMsgUtil(newList, MsgType.Notice, {
                                notice: NoticeConst.ChatEnded.value,
                                id: NoticeConst.Connecting.id,
                            }),
                        ];
                    });

                    showChatEnd();
                } else {
                    if (hasChatBotConversationAndToken()) {
                        retryCountRef.current = 0;
                        connectWithPreCheck();
                    }
                }
            });
            cc.start()
                .then(() => {
                    if (
                        hasChatBotConversationAndToken() &&
                        getValue(LocalStorageType.CHATBOT_TOKEN) !== data.Token &&
                        getValue(LocalStorageType.CHATBOT_SESSIONID) !== data.SessionId
                    ) {
                        getChatBotConversationState().then((res) => {
                            if (res > PermissionType.NONEEDDISCONNECTED) {
                                cc.stop();
                                createChatBotWebSocket({
                                    Token: getValue(LocalStorageType.CHATBOT_TOKEN),
                                    SessionId: getValue(LocalStorageType.CHATBOT_SESSIONID),
                                });
                            }
                        });
                    } else {
                        connectionRef.current = cc;
                        setValue(LocalStorageType.CHAT_STATE, ChatStatus.ChatBotChatting);
                        removeConnectingNotice();
                        showChatBotJoinMsg();
                        if (hasChatBotConversationAndToken()) {
                            showChatBotHistoryMsg();
                        } else {
                            sendCustomerMsg(getValue(LocalStorageType.CHAT_BASIC_INFO).question);
                            setValue(LocalStorageType.CHATBOT_SESSIONID, data.SessionId);
                            setValue(LocalStorageType.CHATBOT_TOKEN, data.Token);
                            setAgentCookie(ChatStatus.ChatBotChatting);
                        }
                        setInputStatus({ disabled: false });
                    }
                })
                .catch((err) => {
                    if (isIE()) {
                        removeConnectingNotice();
                        botToAgent(true);
                    } else {
                        connectWithPreCheck();
                    }
                    console.error('SignalR Connection Error: ', err);
                });

            return () => {
                if (cc) {
                    cc.stop();
                }
            };
        }
    };

    const showChatBotHistoryMsg = () => {
        getChatBotHistory()?.then(async (res) => {
            if (res) {
                let historyMsgList: Array<RenderChatMsg<RenderMsgByType, MsgType>> = [];
                for (let i = 0; i < res.length; i++) {
                    const date = new Date(res[i].EventTime);
                    if (res[i].Participant.toLowerCase() == 'user') {
                        let msgList: UserMsgInfo[] = [];
                        if (res[i].Payload) {
                            if (res[i].Payload.Attachments) {
                                msgList = res[i].Payload.Attachments.map((item) => ({
                                    oriMsg: item.DisplayName,
                                    date: date,
                                }));
                            }
                            if (res[i].Payload.Messages) {
                                msgList = res[i].Payload.Messages.map((msg) => ({
                                    oriMsg: msg,
                                    date: date,
                                }));
                            }
                        }

                        historyMsgList = renderMsgUtil(historyMsgList, MsgType.User, {
                            msgList,
                            time: convertDate(date),
                        });
                    } else if (res[i].Participant.toLowerCase() == 'bot') {
                        let suggestions = [];
                        let actionButton;
                        if (i + 1 === res.length) {
                            const { RichResponses = [], Suggestions = [] } = res[i].Payload;
                            actionButton = RichResponses.find(
                                (item) => item.Type === RichResponseTypeEnum.ActionButton,
                            );
                            suggestions = Suggestions;

                            if (!isEmpty(actionButton)) {
                                const permission = await handleGetPermissionData(actionButton);
                                actionButton = permission?.UploadEnabled && actionButton;
                                setPermissionData(permission);
                            }
                            setActionBtnData(actionButton);
                        }

                        historyMsgList = renderMsgUtil(historyMsgList, MsgType.ChatBot, {
                            msgList: [
                                {
                                    data: res[i].Payload,
                                    date,
                                    onSendMessage: sendCustomerMsg,
                                },
                            ],
                            time: convertDate(date),
                        });

                        if (!isEmpty(suggestions) || !isEmpty(actionButton)) {
                            historyMsgList = renderMsgUtil(historyMsgList, MsgType.Actions, {
                                suggestions,
                                actionButton,
                                onSendMessage: sendCustomerMsg,
                                onUploadVisible: handleUploadDialog,
                            });
                        }
                    }
                }
                setWindowChatMsgList((prevList) => {
                    const avatar = prevList.find((item) => item.type === MsgType.Avatar);
                    const otherList = prevList.filter((item) => item.type !== MsgType.Avatar);
                    const newMsgList = [...historyMsgList, ...otherList];
                    if (!isEmpty(avatar)) {
                        newMsgList.unshift(avatar as RenderChatMsg<RenderMsgByType, MsgType>);
                    }
                    return newMsgList;
                });
            }
        });
    };

    const showChatBotJoinMsg = () => {
        const avatar = windowChatMsgList.find((item) => item.type === MsgType.Avatar);
        if (isEmpty(avatar)) {
            setHeaderInfo((prev) => {
                return {
                    ...prev,
                    showCloseIcon: true,
                    member: 'Newegg Chat Bot',
                    noName: false,
                    styles: {
                        backgroundColor: '#cc4e00',
                        backgroundSize: '90%',
                    },
                };
            });
            setWindowChatMsgList((prevList) => {
                return [
                    ...renderMsgUtil(prevList, MsgType.Avatar, {
                        notice: `Chatting with Newegg Chat Bot`,
                        style: {
                            backgroundColor: '#cc4e00',
                            backgroundSize: '90%',
                        },
                    }),
                ];
            });
            chatPostMessage({
                style: `background-image:url(${initialState.Config.WebConfig.CDN.staticImageServer}${HeaderIcon});background-color: rgb(204, 78, 0)`,
                action: 'showAvatarIcon',
            });
        }
    };

    const botToAgent = (needShowQuestion?:boolean) => {
        setValue(LocalStorageType.CHATBOT_TO_AGENT, true);
        handleEndChatMsg();
        sendEndChatMsg();
        inAgentServiceTime()?.then((res) => {
            if (res && !res.data?.close) {
                setCurrentPageStatus({
                    pageType: PageType.ChatAgentWindow,
                    additionInfo: {
                        botToAgentStatus: true,
                        chatbotHistoryLink: chatBotHistoryLinkRef.current,
                        needShowQuestion: needShowQuestion,
                        member:
                            botEndStatusRef.current === ChatBotEndType.ToAgent
                                ? 'Newegg Chat Bot'
                                : ''
                    }
                });
            } else {
                setCurrentPageStatus({
                    pageType: PageType.ChatClose,
                    additionInfo: {
                        message: res.data?.message,
                    },
                });
            }
        });
    };

    const connectWithPreCheck = () => {
        if (
            retryCountRef.current <
            initialState.Config.SocketConfig.ChatBotConnection.MaxRetryCounts
        ) {
            let sessionid = getValue(LocalStorageType.CHATBOT_SESSIONID);
            let token = getValue(LocalStorageType.CHATBOT_TOKEN);
            if (sessionid && token) {
                getChatBotConversationState()?.then((res) => {
                    if (res) {
                        if (res > PermissionType.NONEEDDISCONNECTED) {
                            if (connectionRef.current) {
                                connectionRef.current
                                    .start()
                                    .then(() => {})
                                    .catch((e) => {
                                        setTimeout(() => {
                                            retryCountRef.current = retryCountRef.current + 1;
                                            connectWithPreCheck();
                                        }, 2000);
                                    });
                            } else {
                                createChatBotWebSocket({
                                    Token: getValue(LocalStorageType.CHATBOT_TOKEN),
                                    SessionId: getValue(LocalStorageType.CHATBOT_SESSIONID),
                                });
                            }
                        } else {
                            if (
                                res > PermissionType.NEEDDISCONNECTED &&
                                res < PermissionType.NONEEDDISCONNECTED
                            ) {
                                retryCountRef.current =
                                    initialState.Config.SocketConfig.ChatBotConnection.MaxRetryCounts;
                            }
                            showChatEnd();
                        }
                    }
                });
            } else {
                showChatEnd();
                setWindowChatMsgList(() => {
                    return [
                        ...renderMsgUtil([], MsgType.Notice, {
                            notice: NoticeConst.AgentConnectFailed.value,
                            id: NoticeConst.AgentConnectFailed.id
                        })
                    ];
                });
            }
        }
    };

    const clearEffectAboutComponent = () => {
        stopConnection();
        setHeaderInfo((prev) => ({
            ...prev,
            showCloseIcon: true,
        }));
        setInputStatus({
            disabled: true,
        });
        setActionBtnData(undefined);
        setUploadDialogVisible(false);
        handleEndChatMsg();
        setCurrentChatLayoutStatus((prevState) => {
            return {
                ...prevState,
                avatarType: AvatarType.offLine,
            };
        });

        chatPostMessage({
            action: 'showAvatarIcon',
            classes: 'is-agent-offline',
        });
    };

    const resetRecoilAndStorage = () => {
        resetChatBotLocalStorage(botEndStatusRef.current);
        setWindowChatMsgList((prevList) => {
            if (
                prevList.findIndex(
                    (t) =>
                        t.type == MsgType.Notice &&
                        (t.additionInfo as NoticeAdditionalInfo).id == NoticeConst.Connecting.id,
                ) > -1
            ) {
                return prevList;
            }
            if (
                retryCountRef.current ==
                initialState.Config.SocketConfig.ChatBotConnection.MaxRetryCounts
            ) {
                return [
                    ...renderMsgUtil(prevList, MsgType.Notice, {
                        notice: NoticeConst.ChatBotRetryMaxCounts.value,
                        id: NoticeConst.ChatBotRetryMaxCounts.id,
                    }),
                ];
            } else if (getValue(LocalStorageType.CHATBOT_TO_AGENT)) {
                return prevList;
            } else {
                return [
                    ...renderMsgUtil(prevList, MsgType.Notice, {
                        notice: NoticeConst.ChatEnded.value,
                        id: NoticeConst.Connecting.id,
                    }),
                ];
            }
        });
    };

    const showChatEnd = () => {
        clearEffectAboutComponent();
        resetRecoilAndStorage();
    };

    const sendEndChatMsg = () => {
        if (!connectionRef.current || connectionRef.current.state != 'Connected') {
            return;
        }
        connectionRef.current.invoke('EndChat').then(function () {
            stopConnection();
        });
    };

    const stopConnection = () => {
        if (!connectionRef.current) {
            return;
        }
        connectionRef.current.stop();
        connectionRef.current = undefined;
    };

    const handleEndChatMsg = () => {
        setWindowChatMsgList((prevList) => {
            const newMsgList = prevList
                .filter((item) => item.type !== MsgType.Actions)
                .map((item) => {
                    if (item.type === MsgType.ChatBot) {
                        const { additionInfo } = item;
                        return {
                            ...item,
                            additionInfo: {
                                ...additionInfo,
                                isInteraction: false,
                            },
                        };
                    }

                    if (item.type === MsgType.User) {
                        const { additionInfo } = item;
                        const { msgList } = additionInfo as UserAdditionalInfo;
                        const newMsgList = msgList.map((item) => ({ ...item, retryFn: undefined }));

                        return {
                            ...item,
                            additionInfo: {
                                ...additionInfo,
                                msgList: newMsgList,
                            },
                        };
                    }
                    return item;
                });

            return [...newMsgList];
        });
    };

    const sendCustomerMsg = (msg?: string, isAttachment: boolean = false) => {
        if (
            (msg || inputRef.current?.getValue()) &&
            connectionRef.current &&
            connectionRef.current.state == 'Connected'
        ) {
            let message = inputRef.current?.getValue() ?? '';
            let date = new Date();
            const sendDate = new Date();
            if (msg) {
                try {
                    const [msgList] = JSON.parse(msg);
                    message = msgList?.oriMsg || message;
                    date = msgList?.date ? new Date(msgList?.date) : date;
                } catch (e) {
                    message = msg;
                }
            }
            if (onlineRef.current) {
                const methodName = isAttachment ? 'SendAttachmentMessage' : 'SendMessage';
                connectionRef.current.invoke(methodName, message);
            } else {
                const msgList = [
                    {
                        oriMsg: message,
                        date: sendDate,
                    },
                ];
                setWindowChatMsgList((prevList) => {
                    const list: Array<RenderChatMsg<RenderMsgByType, MsgType>> = prevList.map(
                        (t) => {
                            if (t.type == MsgType.User) {
                                (t.additionInfo as UserAdditionalInfo).msgList = (t.additionInfo as UserAdditionalInfo).msgList.filter(
                                    (m) => m.date.getTime() !== date.getTime(),
                                );
                            }

                            return t;
                        },
                    );
                    return [
                        ...renderMsgUtil(list, MsgType.User, {
                            msgList,
                        }),
                    ];
                });

                sendCustomerMsgFailed(
                    {
                        message,
                        sendTime: sendDate.getTime(),
                    },
                    () =>
                        sendCustomerMsg(
                            JSON.stringify([
                                {
                                    oriMsg: message,
                                    date: sendDate.getTime(),
                                },
                            ]),
                        ),
                    {
                        isRetryRenderMsg: false,
                        isRemoveMsg: true,
                    },
                );
            }
        }
    };

    const handleUploadDialog = () => {
        setUploadDialogVisible(!uploadDialogVisible);
    };

    const handleClose = () => {
        if (connectionRef.current?.state == 'Disconnected') {
            setWindowChatMsgList([]);
            hideChatWindow();
        } else if (connectionRef.current?.state == 'Connected') {
            setIsShowChatEnd(true);
        } else {
            setWindowChatMsgList([]);
            hideChatWindow();
        }
    };

    const handleGetPermissionData = async (actionBtn) => {
        const { bizType, host, header } = uploadReqParams.current as UploadReqData;
        try {
            const result = await onGetPermission({
                bizType,
                host,
                header,
                options: {
                    Identity: actionBtn.Parameters.Identity,
                },
            });

            const { permission } = result;
            return permission;
        } catch (e) {
            return defaultPermissionData;
        }
    };

    return (
        <>
            {renderInputBar({
                maxLength: 255,
                onClick: sendCustomerMsg,
                onKeyUp: sendCustomerMsg,
                disabled: inputStatus?.disabled,
                showUploadIcon: false,
                ref: inputRef,
            })}
            {!isEmpty(actionBtnData) && (
                <UploadPicturesDialog
                    onlineStatus={onlineRef.current}
                    uploadReqParams={uploadReqParams.current}
                    permissionData={permissionData}
                    alreadyUploaded={alreadyUploaded}
                    visible={uploadDialogVisible}
                    actionData={actionBtnData as ActionButton}
                    onSubmit={(msg) => sendCustomerMsg(msg, true)}
                    onCancel={handleUploadDialog}
                />
            )}
            {isShowChatEnd && (
                <>
                    <ChatEnd
                        handleLeaveChatClick={() => {
                            setWindowChatMsgList(() => []);
                            resetChatBotLocalStorage();
                            sendEndChatMsg();
                            hideChatWindow();
                        }}
                        handleContinueChatClick={() => {
                            setIsShowChatEnd(false);
                        }}
                        needShowEmailCheckBox={false}
                    />
                </>
            )}
        </>
    );
};

ChatBot.displayName = 'ChatBot';

export default React.forwardRef(ChatBot);
