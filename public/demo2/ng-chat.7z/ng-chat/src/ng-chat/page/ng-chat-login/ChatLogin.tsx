import cn from 'classnames';
import React, { useState, useEffect, FC } from 'react';
import { useSetRecoilState, useRecoilValue } from 'recoil';

import { Textarea, Cascader, Input, Checkbox, Select, Button } from '../../../common/component';
import { ChatStatus } from '../../../common/storage';
import { useInitialState } from '../../../common/server/interceptors/context/GlobalContext';
import { Header } from '../../component';

import { ChatLoginSubmitVal } from '../../types/chatLogin/chatLoginSubmitVal';
import { currentPageStatusAtom, PageType, chatLayoutBasicInfoAtom } from '../../atom';
import {
    closePopup,
    collapsePopup,
    connectWithChatStatus,
    isChatting,
    saveLoginInfoToLocalStorage
} from '../../utils';
import { ChatType, ConnectWith, InitialState } from '../../types';
import { useChatLoginUtils, useChatUtils } from '../../hooks';

export const ChatLogin: FC = () => {
    const setCurrentPageStatus = useSetRecoilState(currentPageStatusAtom);
    // const setCurrentChatLayoutStatus = useSetRecoilState(currentChatLayoutStatusAtom);
    const chatLayoutBasicInfo = useRecoilValue(chatLayoutBasicInfoAtom);

    const { sendToAdobeOnClick, setAgentCookie, initialPage } = useChatUtils();
    const { checkConnectToChatBot } = useChatLoginUtils();
    const initialState = useInitialState<InitialState>();

    const reg = new RegExp(initialState?.Config?.BizChatLoginConfig?.EmailValidRegex);

    const [submitVal, setSubmitVal] = useState<ChatLoginSubmitVal>({
        FullName: {
            value: '',
            error: false
        },
        EmailAddress: {
            value: '',
            error: false
        },
        EnableSendMeTranscript: initialState?.Config?.BizChatLoginConfig?.EnableTranscript,
        Category: {
            value: initialState?.Config?.BizChatLoginConfig?.DefaultCategory,
            error: false
        },
        Topic: {
            value: initialState?.Config?.BizChatLoginConfig?.DefaultTopic,
            error: false
        },
        Reason: {
            value: initialState?.Config?.BizChatLoginConfig?.DefaultReason,
            error: false
        },
        Question: {
            value: '',
            needShow: false,
            error: false
        }
    });

    const [connectChatBot, setConnectChatBot] = useState<boolean>(false);

    useEffect(() => {
        setSubmitVal((pre) => {
            pre.FullName.value = chatLayoutBasicInfo?.loginName ?? '';
            pre.EmailAddress.value = chatLayoutBasicInfo?.emailAddress ?? '';
            pre.Category.value =
                chatLayoutBasicInfo?.category ??
                initialState?.Config?.BizChatLoginConfig?.DefaultCategory;
            pre.Topic.value =
                chatLayoutBasicInfo?.topic ??
                initialState?.Config?.BizChatLoginConfig?.DefaultTopic;
            pre.Reason.value =
                chatLayoutBasicInfo?.reason ??
                initialState?.Config?.BizChatLoginConfig?.DefaultReason;
            pre.Question.needShow = chatLayoutBasicInfo.type == ChatType.SpecialQueue;
            return { ...pre };
        });
    }, [
        chatLayoutBasicInfo.loginName,
        chatLayoutBasicInfo.emailAddress,
        chatLayoutBasicInfo.category,
        chatLayoutBasicInfo.topic,
        chatLayoutBasicInfo.reason,
        chatLayoutBasicInfo.type
    ]);

    useEffect(() => {
        const connectChatBot = checkConnectToChatBot(
            initialState.Config.BizChatLoginConfig.TopicAndReasonOptions,
            submitVal?.Topic?.value ?? '',
            submitVal?.Reason?.value ?? ''
        );
        setSubmitVal((pre) => {
            pre.Question.needShow =
                chatLayoutBasicInfo.type == ChatType.SpecialQueue ||
                (!connectChatBot &&
                    !!submitVal.Topic.value &&
                    !!submitVal.Reason.value &&
                    submitVal.Topic.value !==
                        initialState?.Config?.BizChatLoginConfig?.DefaultTopic &&
                    submitVal.Reason.value !==
                        initialState?.Config?.BizChatLoginConfig?.DefaultReason);
            return { ...pre };
        });
        setConnectChatBot(connectChatBot);
    }, [submitVal.Reason, submitVal.Topic]);

    useEffect(() => {
        if (!isChatting()) {
            initialPage();
        }
    }, []);

    const validateUserInfo = () => {
        const fullNameError = !submitVal.FullName?.value?.trim();
        const emailError = !reg.test(submitVal.EmailAddress?.value);
        const categoryError =
            submitVal.Category?.value == initialState?.Config?.BizChatLoginConfig?.DefaultCategory;
        const topicError =
            submitVal.Topic?.value == initialState?.Config?.BizChatLoginConfig?.DefaultTopic;
        const reasonError =
            submitVal.Reason?.value == initialState?.Config?.BizChatLoginConfig?.DefaultReason;
        const questionError = !submitVal.Question?.value?.trim() && !!submitVal.Question?.needShow;
        setSubmitVal((pre) => {
            pre.FullName.error = fullNameError;
            pre.EmailAddress.error = emailError;
            pre.Category.error = categoryError;
            pre.Topic.error = topicError;
            pre.Reason.error = reasonError;
            pre.Question.error = questionError;
            return { ...pre };
        });

        return !(
            fullNameError ||
            emailError ||
            categoryError ||
            topicError ||
            reasonError ||
            questionError
        );
    };

    const handleContinueClick = () => {
        if (validateUserInfo()) {
            if (connectWithChatStatus() == ConnectWith.Agent) {
                setCurrentPageStatus({
                    pageType: PageType.ChatAgentWindow,
                    additionInfo: {
                        isReconnected: true
                    }
                });
            } else if (connectWithChatStatus() == ConnectWith.ChatBot) {
                setCurrentPageStatus({
                    pageType: PageType.ChatBotWindow,
                    additionInfo: {
                        isReconnected: true
                    }
                });
            } else {
                if (connectChatBot && initialState.AdditionInfo.type != ChatType.SpecifiedQueue) {
                    setCurrentPageStatus({
                        pageType: PageType.ChatBotWindow
                    });
                } else {
                    setCurrentPageStatus({
                        pageType: PageType.ChatAgentWindow
                    });
                }
                sendToAdobeOnClick(submitVal.Topic.value, submitVal.Reason.value);
                saveLoginInfoToLocalStorage(submitVal, connectChatBot);
                setAgentCookie(ChatStatus.Initial);
            }
        }
    };

    return (
        <>
            <Header handleCloseIcon={closePopup} handleCollapseIcon={collapsePopup} />
            <div
                className="NE-chat-content show-login"
                style={{
                    top: initialState?.AdditionInfo?.injectionType == 'popup' ? '95px' : '59px'
                }}
            >
                <div className="login-section">
                    <Input
                        name="Full Name"
                        defaultValue={chatLayoutBasicInfo?.loginName ?? ''}
                        onBlur={(e) => {
                            setSubmitVal((pre) => {
                                pre.FullName = {
                                    ...pre.FullName,
                                    value: e?.target?.value?.trim()
                                };
                                return { ...pre };
                            });
                        }}
                        errorMsg="This field is required."
                        error={submitVal.FullName.error}
                        maxLength={80}
                    />
                    <Input
                        name="Email Address"
                        defaultValue={chatLayoutBasicInfo?.emailAddress ?? ''}
                        errorMsg="Please enter a valid email address."
                        error={submitVal.EmailAddress.error}
                        maxLength={128}
                        onBlur={(e) => {
                            setSubmitVal((pre) => {
                                pre.EmailAddress = {
                                    ...pre.EmailAddress,
                                    value: e?.target?.value?.trim()
                                };

                                return { ...pre };
                            });
                        }}
                    />
                    <div className="row">
                        <Checkbox
                            children="Send me a chat transcript"
                            onChange={(e) => {
                                setSubmitVal((pre) => {
                                    pre.EnableSendMeTranscript = e.target.checked;
                                    return { ...pre };
                                });
                            }}
                            checked={submitVal.EnableSendMeTranscript}
                        />
                    </div>
                    {chatLayoutBasicInfo.type != ChatType.SpecialQueue && (
                        <>
                            {initialState.Config.BizChatLoginConfig.CategoryOptions?.length > 1 && (
                                <div
                                    className={cn('row', {
                                        'is-error': submitVal?.Category?.error
                                    })}
                                >
                                    <label className="form-cell-name">
                                        Which category of products your inquiry would be associated
                                        with?
                                    </label>

                                    <Select
                                        title={
                                            initialState?.Config?.BizChatLoginConfig
                                                ?.DefaultCategory
                                        }
                                        defaultValue={
                                            initialState?.Config?.BizChatLoginConfig
                                                ?.DefaultCategory
                                        }
                                        isWide={true}
                                        customerClass="category-select"
                                        onChange={(val) => {
                                            setSubmitVal((pre) => {
                                                pre.Category = {
                                                    ...pre.Category,
                                                    value: val
                                                };
                                                return { ...pre };
                                            });
                                        }}
                                    >
                                        {initialState.Config.BizChatLoginConfig.CategoryOptions?.map(
                                            (t, i) => (
                                                <option key={`category-${i}`}>{t}</option>
                                            )
                                        )}
                                    </Select>
                                </div>
                            )}
                            {initialState.Config.TopicAndReasonConfig &&
                                initialState.Config.TopicAndReasonConfig.length > 0 && (
                                    <div
                                        className={cn('row', {
                                            'is-error':
                                                submitVal?.Topic?.error || submitVal?.Reason?.error
                                        })}
                                    >
                                        <label className="form-cell-name">Contact Topic</label>
                                        <Cascader
                                            onChange={(val) => {
                                                setSubmitVal((pre) => {
                                                    pre.Topic = {
                                                        ...pre.Topic,
                                                        value: val[0]
                                                    };
                                                    pre.Reason = {
                                                        ...pre.Reason,
                                                        value: val[1]
                                                    };
                                                    return { ...pre };
                                                });
                                            }}
                                            options={initialState.Config.TopicAndReasonConfig}
                                            CustomerOptions={{
                                                defaultValue: [
                                                    initialState?.Config?.BizChatLoginConfig
                                                        ?.DefaultTopic,
                                                    initialState?.Config?.BizChatLoginConfig
                                                        ?.DefaultReason
                                                ],
                                                class: [`is-wide`, `is-wide`],
                                                title: [
                                                    initialState?.Config?.BizChatLoginConfig
                                                        ?.DefaultTopic,
                                                    initialState?.Config?.BizChatLoginConfig
                                                        ?.DefaultReason
                                                ]
                                            }}
                                            ReplaceDefaultValue={false}
                                        />
                                    </div>
                                )}
                        </>
                    )}

                    {submitVal.Question.needShow && (
                        <div
                            className={cn('row question-input', {
                                'is-error': submitVal?.Question?.error
                            })}
                        >
                            <Textarea
                                maxHeight={74}
                                minHeight={57}
                                label="Question"
                                customerClass="is-wide expandable"
                                maxLength={800}
                                limit={800}
                                errorMessage="This field is required."
                                error={submitVal?.Question?.error}
                                onBlur={(e) => {
                                    setSubmitVal((pre) => {
                                        pre.Question = {
                                            ...pre.Question,
                                            value: e.target.value?.trim()
                                        };
                                        return { ...pre };
                                    });
                                }}
                            />
                            <p>Note: Please include your Order # or Return # if available.</p>
                        </div>
                    )}
                    {initialState?.Config?.BizCustomizedUIConfig?.ChatWindow?.Disclaimer && (
                        <div
                            className="row"
                            dangerouslySetInnerHTML={{
                                __html:
                                    initialState?.Config?.BizCustomizedUIConfig?.ChatWindow
                                        ?.Disclaimer
                            }}
                        ></div>
                    )}
                </div>
            </div>
            <div className="NE-chat-input-bar show-continue">
                <div className="columns continue-bar">
                    <div className="column">
                        <Button
                            text="continue"
                            className="btn-primary continue-btn"
                            onClick={handleContinueClick}
                        />
                    </div>
                </div>
            </div>
        </>
    );
};

ChatLogin.displayName = 'ChatLogin';
