import { useAjaxRequest, useLocalStorage } from '../../common/hook';
import { ResponseBody } from '../../common/client/response/model';

import {
    CreateAgentChatResponse,
    AgentMemberResponse,
    AgentSaveResponse,
    CustomerMsgToAgentRes,
    GuestCustomerMessageResponse,
    CreateAgentChatRequest,
    MemberEntity,
    AgentMemberRequestBody,
    GetAttachmentFileLinkResponse,
    OverChatServiceTime,
    OverChatServiceTimeReqQuery
} from '../models';
import { LocalStorageType } from '../../common/storage';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';
import { ChatType, InitialState } from '../types';
import { useRecoilValue } from 'recoil';
import { chatLayoutBasicInfoAtom, currentPageStatusAtom } from '../atom';
import { BaseErrorCode, CompanyCode, CreateAgentChatErrorCodeErrorCode } from '../const/server';

const { getValue, setValue } = useLocalStorage();

export const useChatAgentAPI = () => {
    const { getValue } = useLocalStorage();
    const initialState = useInitialState<InitialState>();
    const currentPageStatus = useRecoilValue(currentPageStatusAtom);
    const chatLayoutBasicInfo = useRecoilValue(chatLayoutBasicInfoAtom);

    const { sendRequest: CreateAgentApi } = useAjaxRequest<
        ResponseBody<CreateAgentChatResponse, CreateAgentChatErrorCodeErrorCode>
    >(false, {
        api: {
            apiParam: 'agentchat/create',
            method: 'POST',
            body: () => getAgentChatRequest()
        }
    });

    const { sendRequest: inAgentServiceTime } = useAjaxRequest<
        ResponseBody<OverChatServiceTime, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () => `agentchat/agent/time`,
            method: 'GET',
            buildQuery: (): OverChatServiceTimeReqQuery => {
                return {
                    category: chatLayoutBasicInfo?.category ?? '',
                    type: chatLayoutBasicInfo?.type ?? ChatType.NormalChat,
                    country: initialState.AdditionInfo.country
                };
            }
        }
    });

    const { sendRequest: getMemberState } = useAjaxRequest<
        ResponseBody<MemberEntity, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () =>
                `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/members/${getValue(
                    LocalStorageType.CHAT_CUSTOMER_MEMBER_ID
                )}`,
            method: 'GET',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    const { sendRequest: getAgentConversationState } = useAjaxRequest<
        ResponseBody<boolean, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () =>
                `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/members/${getValue(
                    LocalStorageType.CHAT_CUSTOMER_MEMBER_ID
                )}/status`,
            method: 'POST',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    const { sendRequest: getAllMembersState } = useAjaxRequest<
        ResponseBody<AgentMemberResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () => `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/members`,
            method: 'GET',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    const { sendRequest: memberTyping } = useAjaxRequest(false, {
        api: {
            apiParam: () =>
                `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/typing/${getValue(
                    LocalStorageType.CHAT_CUSTOMER_MEMBER_ID
                )}`,
            method: 'GET',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    const { sendRequest: getAgentMsgData } = useAjaxRequest<
        ResponseBody<AgentSaveResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () =>
                `agentchat/save/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/messageId`,
            method: 'POST'
        }
    });

    const { sendRequest: agentEnd } = useAjaxRequest<
        ResponseBody<AgentMemberResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () =>
                `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/${getValue(
                    LocalStorageType.CHAT_CUSTOMER_MEMBER_ID
                )}/end`,
            method: 'POST',
            body: (): AgentMemberRequestBody => {
                return {
                    companyCode: CompanyCode,
                    sendTransScript: !!getValue(LocalStorageType.CHAT_BASIC_INFO).sendMeTranscript,
                    country: initialState.AdditionInfo.country,
                    language: initialState.AdditionInfo.language
                };
            }
        }
    });

    const { sendRequest: endConversation } = useAjaxRequest<
        ResponseBody<AgentMemberResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () =>
                `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/${getValue(
                    LocalStorageType.CHAT_CUSTOMER_MEMBER_ID
                )}/endConversation`,
            method: 'POST',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            },
            body: (): AgentMemberRequestBody => {
                return {
                    companyCode: CompanyCode,
                    sendTransScript: !!getValue(LocalStorageType.CHAT_BASIC_INFO).sendMeTranscript,
                    country: initialState.AdditionInfo.country,
                    language: initialState.AdditionInfo.language
                };
            }
        }
    });

    const { sendRequest: sendCustomerMessageToAgent } = useAjaxRequest<
        ResponseBody<CustomerMsgToAgentRes, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () =>
                `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/${getValue(
                    LocalStorageType.CHAT_CUSTOMER_MEMBER_ID
                )}/message`,
            method: 'POST',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    const { sendRequest: getConversationMessages } = useAjaxRequest<
        ResponseBody<Array<GuestCustomerMessageResponse>, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () => `agentchat/${getValue(LocalStorageType.CHAT_CONVERSATION_ID)}/messages`,
            method: 'POST',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    const getAgentChatRequest = (): CreateAgentChatRequest => {
        const basicInfo = getValue(LocalStorageType.CHAT_BASIC_INFO);
        let agentChatRequest: CreateAgentChatRequest = {
            fullName: basicInfo?.fullName,
            emailAddress: basicInfo?.emailAddress,
            sendMeTranscript: basicInfo?.sendMeTranscript,
            category: basicInfo?.category,
            topic: basicInfo?.topic,
            reason: basicInfo?.reason,
            question: basicInfo?.question,
            nvtc: initialState.AdditionInfo.nvtc ?? '',
            type: chatLayoutBasicInfo?.type ?? ChatType.NormalChat,
            country: initialState.AdditionInfo.country,
            encryptedCustomerNumber: initialState.AdditionInfo.encryptedCustomerNumber ?? '',
            SpecifiedQueue: initialState.AdditionInfo.specifiedQueue ?? ''
        };
        if (
            currentPageStatus.additionInfo?.botToAgentStatus &&
            currentPageStatus.additionInfo.chatbotHistoryLink
        ) {
            agentChatRequest.question = `ChatBotHistoryLink:
            ${currentPageStatus.additionInfo.chatbotHistoryLink}
            Question:
            ${agentChatRequest.question}
            `;
        }
        return agentChatRequest;
    };

    const { sendRequest: getAttachmentFileLink } = useAjaxRequest<
        ResponseBody<GetAttachmentFileLinkResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () => `agentchat/getAttachmentFileLink`,
            method: 'GET',
            buildQuery: () => {
                return {
                    token: getValue(LocalStorageType.CHAT_CONVERSATION_TOKEN)
                };
            }
        }
    });

    return {
        CreateAgentApi,
        getMemberState,
        memberTyping,
        getAgentMsgData,
        agentEnd,
        sendCustomerMessageToAgent,
        getAllMembersState,
        getConversationMessages,
        endConversation,
        getAttachmentFileLink,
        getAgentConversationState,
        inAgentServiceTime
    };
};
