import { useRecoilState, useSetRecoilState } from 'recoil';
import { isFunction } from 'lodash';
import {
    AvatarType,
    chatWindowMsgListAtom,
    currentPageStatusAtom,
    PageType,
    currentChatLayoutStatusAtom
} from '../atom';
import { useLocalStorage } from '../../common/hook';
import {
    chatBotEndStorageChatStatusMapping,
    ChatBotEndType,
    InitialState,
    MsgType,
    RenderMsgByType,
    UserAdditionalInfo,
    UserMsgInfo,
} from '../types';
import { chatPostMessage, isPC, RenderChatMsg, renderMsgUtil } from '../utils';
import { ChatStatus, LocalStorageType } from '../../common/storage';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';

const { setValue, remove } = useLocalStorage();
declare let Biz: any;
declare let s: any;
declare let sentToPacketBeatClick: any;

interface MsgFailedOptions {
    isRetryRenderMsg?: boolean;
    isRemoveMsg?: boolean;
}

export const useChatUtils = () => {
    const [windowChatMsgList, setWindowChatMsgList] = useRecoilState(chatWindowMsgListAtom);
    const [currentPageStatus, setCurrentPageStatus] = useRecoilState(currentPageStatusAtom);
    const setCurrentChatLayoutStatus = useSetRecoilState(currentChatLayoutStatusAtom);
    const initialState = useInitialState<InitialState>();
    const sendCustomerMsgFailed = (
        data: { sendTime: number; message: string; isAttachment?: boolean },
        sendCustomerMsg?: () => void,
        options: MsgFailedOptions = {
            isRetryRenderMsg: true,
            isRemoveMsg: true
        }
    ) => {
        let sendTime = new Date(data.sendTime);
        setWindowChatMsgList((prevList) => {
            let error = false;
            let newList = prevList.reduce((total, item) => {
                const { type, additionInfo } = item;
                if (type == MsgType.User) {
                    const {
                        msgList,
                        time = '',
                        isError = false,
                        ...rest
                    } = additionInfo as UserAdditionalInfo;
                    const newMsgList: UserAdditionalInfo[] = [];
                    let startIndex = 0;

                    msgList.forEach((msgItem, index, list) => {
                        if (msgItem.date.getTime() == sendTime.getTime()) {
                            if (index > startIndex) {
                                const beforeList = list.slice(startIndex, index);

                                newMsgList.push({
                                    msgList: beforeList,
                                    isError: false,
                                    time
                                });
                            }

                            startIndex = index + 1;
                            if (data.isAttachment) {
                                msgItem.isUploading = false;
                                msgItem.oriMsg = data.message;
                                msgItem.progress = 0;
                            }
                            msgItem.retryFn = isFunction(sendCustomerMsg)
                                ? () => retryCustomerMsg(msgItem, sendCustomerMsg, options)
                                : undefined;
                            msgItem.isTranslated = false;
                            msgItem.translateMsg = '';
                            msgItem.isRetryMsg = false;
                            newMsgList.push({
                                msgList: [msgItem],
                                isError: true
                            });
                            error = true;
                        }
                    });

                    if (startIndex < msgList.length) {
                        const beforeList = msgList.slice(startIndex, msgList.length);
                        newMsgList.push({
                            msgList: beforeList,
                            isError,
                            time
                        });
                    }

                    const renderMsgList = newMsgList.reduce((total, msgItem) => {
                        return [...renderMsgUtil(total, MsgType.User, msgItem)];
                    }, []);

                    return [...total, ...renderMsgList];
                }

                return [...total, item];
            }, []);
            if (error) {
                newList = newList.filter((t) => t.type !== MsgType.Typing);
            }
            return [...newList];
        });
    };

    const retryCustomerMsg = (
        msg: UserMsgInfo,
        sendCustomerMsg?: () => void,
        options: MsgFailedOptions = {
            isRetryRenderMsg: true,
            isRemoveMsg: true
        }
    ) => {
        const { isRetryRenderMsg = true, isRemoveMsg = true } = options;
        if (msg && msg.date) {
            setWindowChatMsgList((prevList) => {
                let list: Array<RenderChatMsg<RenderMsgByType, MsgType>> = [];
                prevList.forEach((t) => {
                    if (t.type == MsgType.User) {
                        (t.additionInfo as UserAdditionalInfo).msgList = (t.additionInfo as UserAdditionalInfo).msgList.reduce(
                            (prev, item) => {
                                if (item.date.getTime() === msg.date.getTime()) {
                                    return isRemoveMsg
                                        ? prev
                                        : [
                                              ...prev,
                                              {
                                                  ...item,
                                                  isRetryMsg: true
                                              }
                                          ];
                                }

                                return [...prev, item];
                            },
                            []
                        );
                        // .filter((m) => m.date.getTime() !== msg.date.getTime());
                        (t.additionInfo as UserAdditionalInfo).msgList.length > 0 && list.push(t);
                    } else {
                        t.type !== MsgType.Typing && list.push(t);
                    }
                });
                return isRetryRenderMsg
                    ? [
                          ...renderMsgUtil(list, MsgType.User, {
                              msgList: [
                                  {
                                      ...msg,
                                      date: new Date()
                                  }
                              ]
                          })
                      ]
                    : [...list];
            });
            sendCustomerMsg && sendCustomerMsg();
        }
    };

    const hideChatWindow = () => {
        if (
            initialState.AdditionInfo.injectionType &&
            initialState.AdditionInfo.injectionType == 'embed'
        ) {
            setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, true);
        } else {
            setValue(LocalStorageType.CHAT_WINDOW_IS_OPEN, false);
            chatPostMessage({ action: 'close' });
        }
        setCurrentChatLayoutStatus((prevState) => {
            return {
                ...prevState,
                avatarType: AvatarType.None
            };
        });
        setCurrentPageStatus({
            pageType: PageType.ChatLogin
        });
    };

    const setAgentCookie = (chatStatus: ChatStatus, expireMin?: number) => {
        if (initialState) {
            if (chatStatus == ChatStatus.Initial) {
                chatPostMessage({
                    action: 'setCookie',
                    cookieExpire:
                        expireMin ??
                        -initialState?.Config?.BizCommonConfig?.ChatStatusCookieExpireDate
                            ?.ChattingExpireMinute,
                    cookieValue: ChatStatus.Initial
                });
            } else if (chatStatus == ChatStatus.Waiting) {
                chatPostMessage({
                    action: 'setCookie',
                    cookieExpire:
                        expireMin ??
                        initialState?.Config?.BizCommonConfig?.ChatStatusCookieExpireDate
                            ?.WaitingChatExpireMinute,
                    cookieValue: ChatStatus.Waiting
                });
            } else if (chatStatus == ChatStatus.ChatBotChatting) {
                chatPostMessage({
                    action: 'setCookie',
                    cookieExpire:
                        expireMin ??
                        initialState?.Config?.BizCommonConfig?.ChatStatusCookieExpireDate
                            ?.ChattingExpireMinute,
                    cookieValue: ChatStatus.ChatBotChatting
                });
            } else if (chatStatus == ChatStatus.Chatting) {
                chatPostMessage({
                    action: 'setCookie',
                    cookieExpire:
                        expireMin ??
                        initialState?.Config?.BizCommonConfig?.ChatStatusCookieExpireDate
                            ?.ChattingExpireMinute,
                    cookieValue: ChatStatus.Chatting
                });
            } else if (chatStatus == ChatStatus.Ended) {
                chatPostMessage({
                    action: 'setCookie',
                    cookieExpire:
                        expireMin ??
                        -initialState?.Config?.BizCommonConfig?.ChatStatusCookieExpireDate
                            ?.ChattingExpireMinute,
                    cookieValue: ChatStatus.Ended
                });
            }
        }
    };

    const clearInfo = () => {
        // remove(LocalStorageType.CHAT_CONVERSATION_ID);
        // remove(LocalStorageType.CHAT_SEND_TRANSCRIPT_EMAIL);
        // remove(LocalStorageType.CHAT_CONVERSATION_TOKEN);
        // remove(LocalStorageType.CHAT_CUSTOMERNUMBER);
        remove(LocalStorageType.CHAT_SOURCE);
        // remove(LocalStorageType.CHAT_CUSTOMER_MEMBER_ID);
        remove(LocalStorageType.CHAT_CONVERSATION_WEBSOCKETURL);
        // remove(LocalStorageType.CHAT_USER_NAME);
        // remove(LocalStorageType.CHAT_EMAIL);
        remove(LocalStorageType.CHAT_MSG_LIST);
        remove(LocalStorageType.CHAT_LANGUAGE);
        remove(LocalStorageType.CHAT_HAS_RED_TIPS);

        remove(LocalStorageType.CHATBOT_SESSIONID);
        remove(LocalStorageType.CHATBOT_TOKEN);
        remove(LocalStorageType.CHATBOT_TO_AGENT);

        setValue(LocalStorageType.CHAT_STATE, ChatStatus.Initial);
        setAgentCookie(ChatStatus.Ended);
    };

    const sendToAdobeOnClick = (topic, reason) => {
        let eVar35Value = reason ? topic + '|' + reason : topic;
        let name = 'live chat login';
        let sendTrackingValue: { [k: string]: string } = {
            events: 'event55',
            eVar35: eVar35Value
        };
        if (!isPC()) {
            sendTrackingValue['prop20'] = 'mbl';
            sendTrackingValue['eVar42'] = 'mbl';
        }
        try {
            // for not iframe
            if (
                Biz &&
                Biz?.Common &&
                Biz?.Common?.SiteCatalyst &&
                Biz?.Common?.SiteCatalyst?.sendForOnClick
            ) {
                Biz?.Common?.SiteCatalyst?.sendForOnClick(sendTrackingValue, name);
                return;
            }
        } catch (e) {}

        // for iframe
        if (
            typeof s != 'undefined' &&
            initialState &&
            initialState.AdditionInfo.country &&
            initialState.AdditionInfo.currencyCode
        ) {
            s.pageName = initialState.AdditionInfo.country + ':help:contactus';
            s.prop19 = initialState.AdditionInfo.nvtc;
            sendTrackingValue.prop12 = sendTrackingValue.eVar51 = initialState.AdditionInfo.country;
            sendTrackingValue.currencyCode = sendTrackingValue.prop13 = sendTrackingValue.eVar52 =
                initialState.AdditionInfo.currencyCode;
            let trackVars: Array<string> = [];
            if (s.prop19 != undefined) {
                trackVars.push('prop19');
            }
            if (s.prop23 != undefined) {
                trackVars.push('prop23');
            }
            if (sendTrackingValue.eVar1) {
                s.eVar1 = sendTrackingValue.eVar1;
            }
            let keys = Object.keys(sendTrackingValue);
            if (keys && keys.length > 0) {
                keys.forEach((prop) => {
                    trackVars.push(prop);
                    if (prop == 'events') {
                        s.linkTrackEvents = s.events = sendTrackingValue[prop];
                    } else {
                        if (!!sendTrackingValue[prop]?.substring) {
                            sendTrackingValue[prop] = sendTrackingValue[prop]?.substring(0, 15000);
                        }
                        s[prop] = sendTrackingValue[prop];
                    }
                });
            }

            s.linkTrackVars = trackVars.join(',');
            try {
                s.tl(this, 'o', name);
                sentToPacketBeatClick(s, name);
            } catch (eee) {}
        }
    };

    const resetChatBotLocalStorage = (botEndStatus: ChatBotEndType = ChatBotEndType.BotEnd) => {
        remove(LocalStorageType.CHATBOT_SESSIONID);
        remove(LocalStorageType.CHATBOT_TOKEN);
        setValue(LocalStorageType.CHAT_STATE, chatBotEndStorageChatStatusMapping[botEndStatus]);
        setAgentCookie(ChatStatus.Ended);
    };

    const isPopup = () => {
        return (
            initialState &&
            initialState?.AdditionInfo?.injectionType &&
            initialState?.AdditionInfo?.injectionType == 'popup'
        );
    };

    const isEmbed = () => {
        return (
            initialState &&
            initialState?.AdditionInfo?.injectionType &&
            initialState?.AdditionInfo?.injectionType == 'embed'
        );
    };

    const initialPage = () => {
        setCurrentChatLayoutStatus((pre) => {
            return {
                ...pre,
                avatarType: AvatarType.None
            };
        });
        clearInfo();
        chatPostMessage({ action: 'showNormalIcon' });
    };

    return {
        sendCustomerMsgFailed,
        hideChatWindow,
        setAgentCookie,
        clearInfo,
        sendToAdobeOnClick,
        isPopup,
        isEmbed,
        resetChatBotLocalStorage,
        initialPage
    };
};
