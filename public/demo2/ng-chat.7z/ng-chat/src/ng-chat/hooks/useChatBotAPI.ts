import { useAjaxRequest, useLocalStorage } from '../../common/hook';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';
import { LocalStorageType } from '../../common/storage';

import { InitialState } from '../types/initialState.type';
import { InitialChatBotRes, PermissionType } from '../models';
import { useRef } from 'react';

export const useChatBotAPI = () => {
    const { getValue } = useLocalStorage();
    const initialState = useInitialState<InitialState>();
    const chatbotReq = useRef<string>(
        `${initialState.Config.SocketConfig.ChatBotConnection?.HostAddress}${initialState.Config.SocketConfig.ChatBotConnection?.HubUrl}`,
    );
    const { sendRequest: initiateBot } = useAjaxRequest<InitialChatBotRes>(false, {
        api: {
            withAxios: true,
            apiParam: `${chatbotReq.current}/initiate`,
            method: 'POST',
        },
    });

    const { sendRequest: getChatBotConversationState } = useAjaxRequest<PermissionType>(false, {
        api: {
            withAxios: true,
            apiParam: `${chatbotReq.current}/preconnection`,
            buildQuery: () => {
                return {
                    sessionid: getValue(LocalStorageType.CHATBOT_SESSIONID),
                    token: getValue(LocalStorageType.CHATBOT_TOKEN),
                };
            },
            method: 'GET',
        },
    });

    const { sendRequest: getChatBotHistory } = useAjaxRequest<any>(false, {
        api: {
            withAxios: true,
            apiParam: `${chatbotReq.current}/history`,
            buildQuery: () => {
                return {
                    sessionid: getValue(LocalStorageType.CHATBOT_SESSIONID),
                };
            },
            method: 'GET',
        },
    });

    return {
        initiateBot,
        getChatBotConversationState,
        getChatBotHistory,
    };
};
