import { useAjaxRequest, useLocalStorage } from '../../common/hook';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';
import { LocalStorageType } from '../../common/storage';
import { ResponseBody } from '../../common/client/response/model';

import { BaseErrorCode } from '../const/server';
import { CustomerFeedbackEntityResponse } from '../models/chatSurvey/chat-survey-respones.model';
import { PostFeedbackResponse } from '../models/chatSurvey/post-feedback-response.model';
import { InitialState } from '../types';
import { PostFeedBackQuery } from '../models/chatSurvey/chat-survey-Submit-request.model';

const { getValue } = useLocalStorage();
export const useChatSurveyAPI = () => {
    const initialState = useInitialState<InitialState>();

    const { sendRequest: getChatSurveyInfo } = useAjaxRequest<
        ResponseBody<CustomerFeedbackEntityResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: `customer-feedback/CommentCard/${getValue(
                LocalStorageType.CHAT_CONVERSATION_ID,
            )}`,
            method: 'GET',
        },
    });
    const { sendRequest: submitFeedback } = useAjaxRequest<
        ResponseBody<PostFeedbackResponse, BaseErrorCode>
    >(false, {
        api: {
            apiParam: `customer-feedback/Submit`,
            method: 'POST',
            buildQuery: (): PostFeedBackQuery => {
                return {
                    EncryptedCustomerNumber:
                        initialState.AdditionInfo.encryptedCustomerNumber ?? '',
                };
            },
        },
    });
    return {
        getChatSurveyInfo,
        submitFeedback,
    };
};
