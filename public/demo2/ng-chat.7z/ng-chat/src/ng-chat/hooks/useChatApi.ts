import { useAjaxRequest, useLocalStorage } from '../../common/hook';
import { ResponseBody } from '../../common/client/response/model';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';

import { DecryptLogin, DecryptLoginQuery, UploadReqParams } from '../models';

import { BaseErrorCode } from '../const/server';
import { InitialState } from '../types';

export const useChatAPI = () => {
    const initialState = useInitialState<InitialState>();

    const { sendRequest: getUploadReqParams } = useAjaxRequest<
        ResponseBody<UploadReqParams, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () => `chat/uploadReqParams`,
            method: 'GET',
        },
    });

    const { sendRequest: getDecryptLogin } = useAjaxRequest<
        ResponseBody<DecryptLogin, BaseErrorCode>
    >(false, {
        api: {
            apiParam: () => `chat/decrypt/login`,
            buildQuery: (): DecryptLoginQuery => {
                return {
                    encryptedEmailAddress: initialState.AdditionInfo.encryptedEmailAddress ?? '',
                };
            },
            method: 'GET',
        },
    });

    return {
        getUploadReqParams,
        getDecryptLogin,
    };
};
