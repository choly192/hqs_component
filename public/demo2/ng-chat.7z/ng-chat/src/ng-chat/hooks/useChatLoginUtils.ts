import { useLocalStorage } from '../../common/hook';
import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';
import { LocalStorageType } from '../../common/storage';
import { TopicAndReasonOption } from '../../common/types';

import { InitialState } from '../types';
import { chatBasicInfo } from '../atom';

const { setValue } = useLocalStorage();

export const useChatLoginUtils = () => {
    const initialState = useInitialState<InitialState>();

    const checkConnectToChatBot = (
        topicAndReasonOptions: Array<TopicAndReasonOption>,
        topic: string,
        reason: string,
    ): boolean => {
        if (initialState) {
            if (!initialState?.Config?.BizChatLoginConfig?.ChatBotEntrance?.Enable) {
                return false;
            }
            if (initialState?.Config?.BizChatLoginConfig?.ChatBotEntrance?.AllowAllTopicAndReason) {
                return true;
            }
        }
        return (
            topicAndReasonOptions
                ?.find((t) => t?.Name == topic)
                ?.Reason?.find((t) => t?.Name == reason)?.AllowChatBot ?? false
        );
    };

    const saveChatBasicInfoByChatDirectlyType = (chatBasicInfo: chatBasicInfo) => {
        if (initialState) {
            setValue(LocalStorageType.CHAT_BASIC_INFO, {
                fullName: chatBasicInfo.loginName ?? '',
                emailAddress: chatBasicInfo.emailAddress ?? '',
                sendMeTranscript: initialState.Config?.BizChatLoginConfig?.EnableTranscript,
                category: chatBasicInfo?.category ?? '',
                topic: chatBasicInfo?.topic ?? '',
                reason: chatBasicInfo?.reason ?? '',
                question: '',
                dateTime: new Date(),
            });
        }
    };

    const noActiveChatBot = (): boolean => {
        if (initialState) {
            if (!initialState.Config.BizChatLoginConfig.ChatBotEntrance.Enable) {
                return true;
            }
            if (initialState.Config.BizChatLoginConfig.ChatBotEntrance.AllowAllTopicAndReason) {
                return false;
            }
            return (
                initialState.Config.BizChatLoginConfig.TopicAndReasonOptions.filter(
                    (t) => t.Reason.filter((m) => m.AllowChatBot).length > 0,
                ).length == 0
            );
        }
        return true;
    };

    return { checkConnectToChatBot, saveChatBasicInfoByChatDirectlyType, noActiveChatBot };
};
