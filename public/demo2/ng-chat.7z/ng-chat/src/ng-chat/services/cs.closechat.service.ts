import { FastifyRequest } from 'fastify';

import { BizCommon, Country } from '../../common/types';
import { ConfigurationManagement } from '../../common/utils/configurationManage';
import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';

import { OverChatServiceTime } from '../models/agent/overChatService.model';
import { ConfigurationManager } from '@framework-frontend/node';
import { ChatType } from '../types';

interface Strategy {
    inCloseTime(
        source: string,
        type: ChatType,
        req: FastifyRequest,
        countryCode?: Country
    ): Promise<OverChatServiceTime>;
}

/**
 * 通过CS tool维护服务时间
 */
class CSToolStrategy implements Strategy {
    constructor(private readonly httpFactory: NodeHttpFactory) {}

    async inCloseTime(
        source: string,
        type: ChatType,
        req: FastifyRequest,
        countryCode: Country
    ): Promise<OverChatServiceTime> {
        const defaultCloseMessage = ConfigurationManagement.BizChatLoginConfig?.DefaultCloseMessage ?? '';
        let domain: Country;
        let closeTime: OverChatServiceTime = {
            close: true,
            message: defaultCloseMessage
        };
        if (type == ChatType.ChatDirectly) {
            domain = 'header';
        } else if (countryCode.toLocaleUpperCase() == 'USA') {
            domain = 'usa';
        } else if (countryCode.toLocaleUpperCase() == 'CAN') {
            domain = 'can';
        } else if (countryCode.toLocaleUpperCase() == 'USB') {
            domain = 'usb';
        } else {
            domain = 'intl';
        }

        try {
            const result = await this.httpFactory
                .create('GetHelpSiteCenterSetting')
                .send({ Domain: domain, Type: 'C' });
            const isClose = result?.data?.IsClose && true;
            closeTime = {
                close: isClose,
                message: isClose ? result?.data?.DisplayMessage || defaultCloseMessage : ''
            };
        } catch (e) {
            (req as any).getLogger().error(`Error in CSToolStrategy(get inCloseTime):${e}`);
        }
        return closeTime;
    }
}

/**
 * 查询purecloud相关队列是否有人
 */
class PureCloudAgent implements Strategy {
    constructor(
        private readonly httpFactory: NodeHttpFactory,
        private readonly configurationManager: ConfigurationManager
    ) {}

    async inCloseTime(
        source: string,
        type: ChatType,
        req: FastifyRequest
    ): Promise<OverChatServiceTime> {
        const defaultCloseMessage = ConfigurationManagement.BizChatLoginConfig?.DefaultCloseMessage ?? '';
        let closeTime: OverChatServiceTime = {
            close: true,
            message: defaultCloseMessage
        };
        const SpecialBusinessConfig = ConfigurationManagement.BizCommonConfig?.SpecialBusiness?.find(
            (t) => t?.BizType == type
        );

        const apiInfo =
            SpecialBusinessConfig &&
            SpecialBusinessConfig?.Config?.SpecialApi?.find(
                (t) => t.key && t.key.toLowerCase() === source.toLowerCase()
            );
        if (!apiInfo || !apiInfo.api) {
            return { close: true, message: defaultCloseMessage };
        }

        try {
            const result = await this.httpFactory.create(apiInfo.api).send<boolean>();

            const isClose = !result?.data;
            closeTime = {
                close: isClose,
                message: isClose ? defaultCloseMessage : ''
            };
        } catch (e) {
            (req as any).getLogger().error(`Error in PureCloudAgent(get inCloseTime):${e}`);
        }
        return closeTime;
    }
}

async function inAgentServiceTime(
    source: string,
    type: ChatType,
    countryCode: Country,
    httpFactory: NodeHttpFactory,
    configurationManager: ConfigurationManager,
    req: FastifyRequest
): Promise<OverChatServiceTime> {
    let strategy: Strategy = new CSToolStrategy(httpFactory);
    if (type == ChatType.SpecialQueue) {
        const SpecialBusinessConfig = ConfigurationManagement.BizCommonConfig?.SpecialBusiness?.find(
            (t) => t?.BizType == type
        );
        if (
            !!source &&
            SpecialBusinessConfig &&
            SpecialBusinessConfig.Config?.SpecialApi?.some(
                (x) => x.key && x?.key.toLowerCase() === source?.toLowerCase()
            )
        ) {
            strategy = new PureCloudAgent(httpFactory, configurationManager);
        }
    }

    return await strategy.inCloseTime(source, type, req, countryCode);
}

export { inAgentServiceTime };
