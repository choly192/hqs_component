import { ConfigurationManager, Injectable, Scope } from '@framework-frontend/node';
import { Model } from '../../common/server/response/model';
import { setResponse } from '../../common/server/response/utils';

import { BaseErrorCode, BaseErrorCodeMapping } from '../const/server';
import { ValidationError } from '../validator/validationError';

@Injectable({ scope: Scope.REQUEST })
export class BaseService {
    constructor() {}

    public buildSuccessMsg<T>(data: T): Model<T, BaseErrorCode> {
        let code = BaseErrorCode.NO_ERROR;
        return setResponse(code, BaseErrorCodeMapping, data, '');
    }

    public buildErrorMsg(error, customerCode?, customerCodeMapping?): Model<object, BaseErrorCode> {
        let code = BaseErrorCode.SERVICE_ERROR;
        if (error instanceof ValidationError) {
            code = error.code as BaseErrorCode;
        }
        return setResponse(
            customerCode ?? code,
            customerCodeMapping ?? BaseErrorCodeMapping,
            null,
            error?.message,
        );
    }
}
