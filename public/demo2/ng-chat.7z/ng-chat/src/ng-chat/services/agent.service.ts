import { FastifyRequest } from 'fastify';
import { REQUEST } from '@nestjs/core';
import { Inject } from '@nestjs/common';

import { ConfigurationManager, Injectable, Scope } from '@framework-frontend/node';

import {
    BizChatLogin,
    BizCommon,
    CategoryAndQueueInfo,
    Country,
    PureCloud
} from '../../common/types';
import { ConfigurationManagement } from '../../common/utils/configurationManage';
import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';
import { TripleDES } from '../../common/utils';
import {
    BizChatLoginByCountry,
    convertBizChatLoginConfig,
    getBu
} from '../../common/utils/convert-config.util';

import {
    CreateAgentChatRequest,
    CreateAgentChatResponse,
    IPDataInfo,
    MemberEntity,
    PureCloudWebChatConversationRequest,
    PureCloudWebChatConversationResponse,
    SaveConversationMessageRequest,
    Translate,
    TranslateRequest,
    TranslateResponse
} from '../models';
import { CompanyCode, CreateAgentChatErrorCodeErrorCode } from '../const/server';
import { ValidationError } from '../validator/validationError';
import { inAgentServiceTime } from './cs.closechat.service';
import { ChatType } from '../types';

@Injectable({ scope: Scope.REQUEST })
export class AgentService {
    constructor(
        private readonly httpFactory: NodeHttpFactory,
        private readonly configurationManager: ConfigurationManager,
        @Inject(REQUEST) readonly request: FastifyRequest
    ) {}

    public async create(
        request: CreateAgentChatRequest,
        countryCode: string,
        req: FastifyRequest
    ): Promise<Partial<CreateAgentChatResponse> | null> {
        const bizCommon = this.configurationManager.getConfiguration<BizCommon>('Biz.Common');
        if (!bizCommon.PureCloud) {
            return null;
        }
        const chatLoginConfig = ConfigurationManagement.BizChatLoginConfig;
        const chatLoginByCountry = convertBizChatLoginConfig(chatLoginConfig, countryCode);
        const errorCode = this.validateCreateRequest(chatLoginByCountry, request);
        if (CreateAgentChatErrorCodeErrorCode.NO_ERROR != errorCode) {
            throw new ValidationError(errorCode, '');
        }

        const overServiceTime = await inAgentServiceTime(
            request?.category ?? '',
            request.type ?? ChatType.NormalChat,
            countryCode,
            this.httpFactory,
            this.configurationManager,
            req
        );
        if (overServiceTime.close) {
            throw new ValidationError(
                CreateAgentChatErrorCodeErrorCode.CHAT_UNAVAILABLE,
                overServiceTime.message
            );
        }
        const chatQueue = this.findChatQueue(chatLoginByCountry, request);

        let response: Partial<CreateAgentChatResponse> = {
            sourceLanguage: 'en',
            chatSource: `LiveChat${getBu(countryCode)}`
        };
        await this.setPureCloudQuestion(request, response);
        await this.setChatWebSocket(
            request,
            response,
            bizCommon.PureCloud,
            chatQueue as CategoryAndQueueInfo,
            countryCode,
            await this.getSpecialChatSkill(
                chatQueue as CategoryAndQueueInfo,
                request,
                chatLoginConfig,
                req.headers['ip']
            ),
            req.headers['ip']
        );

        return response;
    }

    private validateCreateRequest(
        chatLoginConfig: BizChatLoginByCountry,
        request: CreateAgentChatRequest
    ): CreateAgentChatErrorCodeErrorCode {
        const existCategory = this.findChatQueue(chatLoginConfig, request);
        if (!existCategory) {
            return CreateAgentChatErrorCodeErrorCode.INPUT_CATEGORY_EMPTY;
        }

        if (request.type == ChatType.NormalChat) {
            const existTopic = chatLoginConfig?.TopicAndReasonOptions.find(
                (t) => t.Name == request.topic
            );
            if (!existTopic) {
                return CreateAgentChatErrorCodeErrorCode.INPUT_TOPIC_EMPTY;
            }
            if (request.reason) {
                const existReason = existTopic.Reason?.find((r) => r.Name == request.reason);
                if (!existReason) {
                    return CreateAgentChatErrorCodeErrorCode.INPUT_REASON_EMPTY;
                }
            }
        }

        if (request.type != ChatType.ChatDirectly && !request.reason) {
            return CreateAgentChatErrorCodeErrorCode.INPUT_REASON_EMPTY;
        }
        return CreateAgentChatErrorCodeErrorCode.NO_ERROR;
    }

    private findChatQueue(chatLoginConfig: BizChatLoginByCountry, request: CreateAgentChatRequest) {
        let category = chatLoginConfig?.CategoryAndQueueMapping?.find(
            (t) => t.CategoryName === request.category && !!t.QueueName
        );

        if (request.SpecifiedQueue && request.type == ChatType.SpecifiedQueue) {
            const bizCommon = this.configurationManager.getConfiguration<BizCommon>('Biz.Common');
            let categoryName = bizCommon.SpecialBusiness.find(
                (t) => t.BizType == 4
            )?.Config?.SpecifiedQueueList?.find((t) => t == request.SpecifiedQueue);
            if (categoryName) {
                category = chatLoginConfig?.CategoryAndQueueMapping?.find(
                    (t) => t.CategoryName === categoryName && !!t.QueueName
                );
            }
        }
        return category;
    }

    public async translate(
        text: string,
        targetLanguageCode: string = 'en',
        sourceLanguageCode: string = ''
    ): Promise<Translate> {
        const defaultValue: Translate = {
            originText: text,
            oriLanguageCode: sourceLanguageCode,
            translateText: '',
            translateLanguageCode: targetLanguageCode
        };
        try {
            if (!text || targetLanguageCode?.toLowerCase() == sourceLanguageCode?.toLowerCase()) {
                return defaultValue;
            }

            let request: TranslateRequest = {
                targetLanguageCode: targetLanguageCode,
                text: text
            };
            if (!!sourceLanguageCode) {
                request.sourceLanguageCode = sourceLanguageCode;
            }
            const translateResult = await this.httpFactory
                .create('TranslateText')
                .send<TranslateResponse>(request);
            if (translateResult?.data?.body && translateResult?.data?.header?.code === 200) {
                return {
                    originText: text,
                    oriLanguageCode: !sourceLanguageCode
                        ? translateResult.data.body.detectedLanguageCode
                        : sourceLanguageCode,
                    translateText: translateResult.data.body.translateText,
                    translateLanguageCode: targetLanguageCode
                };
            } else {
                return {
                    originText: text,
                    oriLanguageCode: 'en',
                    translateText: text,
                    translateLanguageCode: 'en'
                };
            }
        } catch (error) {
            (this.request as any).getLogger().error(`Error in translate(translate msg):${error}`);
            return {
                originText: text,
                oriLanguageCode: 'en',
                translateText: text,
                translateLanguageCode: 'en'
            };
        }
    }

    private async setPureCloudQuestion(
        request: CreateAgentChatRequest,
        response: Partial<CreateAgentChatResponse>
    ): Promise<Partial<CreateAgentChatResponse>> {
        const question = request.question?.trim();
        if (!!question) {
            const translateQuestion = await this.translate(question);
            response.sourceLanguage = translateQuestion?.oriLanguageCode ?? 'en';
            if (
                !translateQuestion.translateText ||
                translateQuestion.translateText == request.question ||
                translateQuestion.translateLanguageCode == translateQuestion?.oriLanguageCode
            ) {
                response.translateQuestion = '';
            } else {
                response.translateQuestion = translateQuestion.translateText;
            }
            response.question = question;
        }
        return response;
    }

    private async setChatWebSocket(
        request: CreateAgentChatRequest,
        response: Partial<CreateAgentChatResponse>,
        pureCloudInfo: PureCloud,
        chatQueue: CategoryAndQueueInfo,
        country: string,
        optionalSkill?: string,
        ip?: string
    ) {
        try {
            let bu = getBu(country);
            const pureCloudChatRequest = this.buildPurecloudWebChatRequest(
                request,
                response,
                pureCloudInfo,
                chatQueue,
                optionalSkill
            );

            const pureCloudResponse = await this.createPureCloudConversation(pureCloudChatRequest);

            if (pureCloudResponse != null) {
                response.conversationID = pureCloudResponse.id;
                response.token = pureCloudResponse.jwt;
                response.socketUrl = pureCloudResponse.eventStreamUri;
                response.memberId = pureCloudResponse.member?.id || '';
            }
            await this.httpFactory
                .create('SaveConservation')
                .addBody({
                    CompanyCode: CompanyCode,
                    CountryCode: bu,
                    ConversationID: pureCloudResponse.id,
                    CustomerAddress: request.emailAddress,
                    Topic: request.category,
                    Reason: request.reason,
                    Question: request.question,
                    EnableSendTranscript: request.sendMeTranscript,
                    Indate: new Date(),
                    NVTC: request.nvtc,
                    ip: ip
                })
                .method('POST')
                .send();
            return response;
        } catch (e) {
            (this.request as any)
                .getLogger()
                .error(`Error in setChatWebSocket(create conversation):${e}`);
            return response;
        }
    }

    private buildPurecloudWebChatRequest(
        request: CreateAgentChatRequest,
        response: Partial<CreateAgentChatResponse>,
        pureCloudInfo: PureCloud,
        chatQueue: CategoryAndQueueInfo,
        optionalSkill?: string
    ): Partial<PureCloudWebChatConversationRequest> {
        const fullName = request.fullName.trim();
        const names = fullName.split(' ');
        let purecloudWebChatRequest: Partial<PureCloudWebChatConversationRequest> = {
            deploymentId: pureCloudInfo.deployMentKey.trim(),
            organizationId: pureCloudInfo.orgGuid.trim(),
            memberInfo: {
                displayName: fullName,
                customFields: {
                    email: request.emailAddress.trim(),
                    firstName: names[0]
                }
            }
        };

        if (purecloudWebChatRequest?.memberInfo?.customFields) {
            const SpecialBusinessConfig = ConfigurationManagement.BizCommonConfig?.SpecialBusiness?.find(
                (t) => t?.BizType == request.type
            );
            if (names.length > 1) {
                purecloudWebChatRequest.memberInfo.customFields.lastName = names.slice(1).join(' ');
            }
            try {
                purecloudWebChatRequest.memberInfo.customFields.customerId =
                    TripleDES.decrypt(request.encryptedCustomerNumber) ?? '0';
            } catch (e) {
                purecloudWebChatRequest.memberInfo.customFields.customerId = '0';
            }
            purecloudWebChatRequest.memberInfo.customFields.customField1Label = 'Topic';
            purecloudWebChatRequest.memberInfo.customFields.customField1 = request.topic.trim();
            if (!!request.reason) {
                if (request.type == ChatType.SpecialQueue) {
                    purecloudWebChatRequest.memberInfo.customFields.customField2Label =
                        SpecialBusinessConfig?.Config?.SpecialCustomField2 ?? 'ItemNumber';
                } else {
                    purecloudWebChatRequest.memberInfo.customFields.customField2Label = 'Reason';
                }
                purecloudWebChatRequest.memberInfo.customFields.customField2 = request.reason;
            }

            const question = request.question?.trim();
            if (!!question) {
                purecloudWebChatRequest.memberInfo.customFields.customField3Label = 'Question';
                if (!!response.translateQuestion) {
                    purecloudWebChatRequest.memberInfo.customFields.customField3 = `${request.question}(Translated:${response.translateQuestion})`.slice(
                        0,
                        1000
                    );
                } else {
                    purecloudWebChatRequest.memberInfo.customFields.customField3 = request.question;
                }
            }
        }

        purecloudWebChatRequest.routingTarget = {
            targetAddress: chatQueue.QueueName,
            targetType: 'QUEUE',
            priority: chatQueue.Priority?.split('+').reduce(
                (prev, current) => prev + parseInt(current, 10),
                0
            )
        };

        if (!!optionalSkill) {
            purecloudWebChatRequest.routingTarget.skills = optionalSkill.split(',');
        }
        return purecloudWebChatRequest;
    }

    private async createPureCloudConversation(
        request: Partial<PureCloudWebChatConversationRequest>
    ): Promise<PureCloudWebChatConversationResponse> {
        const res = await this.httpFactory
            .create('CreatePureCloudWebChatConversation')
            .addBody(request)
            .send<PureCloudWebChatConversationResponse>();
        return res.data;
    }

    private async getSpecialChatSkill(
        chatQueue: CategoryAndQueueInfo,
        request: CreateAgentChatRequest,
        chatLoginConfig: BizChatLogin,
        ip: string
    ) {
        let currentChatSkill = chatQueue.Skills;
        if (chatLoginConfig?.SpecialChatSkills?.length > 0) {
            const validateSkill = chatLoginConfig.SpecialChatSkills.filter(
                (s) => !(!s.HitCategory && !s.HitReason && !s.HitTopic)
            ).find((s) => {
                let hitCategory = true;
                let hitTopic = true;
                let hitReason = true;
                if (!!s.HitCategory) {
                    hitCategory = request.category.toLowerCase() === s.HitCategory.toLowerCase();
                }
                if (!!s.HitTopic) {
                    hitTopic = request.topic.toLowerCase() === s.HitTopic.toLowerCase();
                }
                if (!!s.HitReason) {
                    hitReason = request.reason?.toLowerCase() === s.HitReason.toLowerCase();
                }
                return hitCategory && hitTopic && hitReason;
            });
            currentChatSkill = !!validateSkill?.SkillName
                ? `${currentChatSkill},${validateSkill.SkillName}`
                : currentChatSkill;
        }
        // todo ip is belong to tx
        try {
            let res = await this.httpFactory.create('IPData').method('GET').send({
                ip: ip,
                'region&cyc': 1
            });
            let ipData: IPDataInfo = res.data[ip];

            if (
                ipData &&
                ipData?.region?.toLocaleUpperCase() == 'TX' &&
                ipData?.cyc?.toLocaleUpperCase() == 'US'
            ) {
                let specialSkill = chatLoginConfig.SpecialChatSkills.find((t) => t.HitCity == 'TX')
                    ?.SkillName;
                if (currentChatSkill) {
                    currentChatSkill = `${currentChatSkill},${specialSkill}`;
                } else {
                    currentChatSkill = specialSkill ?? '';
                }
            }
        } catch (e) {}
        return currentChatSkill;
    }

    public convertMemberName = (memberEntity: MemberEntity) => {
        if (memberEntity.displayName) {
            memberEntity.memberName = memberEntity.displayName;
        } else {
            memberEntity.memberName =
                memberEntity?.role?.toLocaleUpperCase() == 'AGENT' ? 'Agent' : 'Guest';
        }
    };

    public saveDataToDB = async (
        conversationID: string,
        msgId: string,
        sender: string,
        oriMsg: string,
        targetMsg: string,
        oriLanguage: string,
        targetLanguage: string,
        name: string,
        dateTime: number
    ) => {
        try {
            let messageRequest = new SaveConversationMessageRequest();
            messageRequest.ConversationID = conversationID;
            messageRequest.MsgID = msgId;
            messageRequest.FromID = sender;
            messageRequest.FromName = name;
            messageRequest.SourceLanguage = oriLanguage;
            messageRequest.SourceMessage = oriMsg;
            if (
                oriLanguage?.toLocaleLowerCase() !== targetLanguage?.toLocaleLowerCase() &&
                oriMsg?.toLocaleLowerCase() !== targetMsg?.toLocaleLowerCase()
            ) {
                messageRequest.TargetLanguage = targetLanguage;
                messageRequest.TargetMessage = targetMsg;
            }

            messageRequest.InDate = new Date(dateTime);
            await this.httpFactory
                .create('SaveConservationMessage')
                .method('POST')
                .addBody(messageRequest)
                .send();
        } catch (e) {
            (this.request as any)
                .getLogger()
                .error(`Error in saveDataToDB(save conversation):${e}`);
        }
    };

    public getBizCountry = (country: Country) => {
        return getBu((country ?? 'USA').toLocaleUpperCase());
    };
}
