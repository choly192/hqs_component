import { isNull } from 'lodash';
import { REQUEST } from '@nestjs/core';
import { FastifyRequest } from 'fastify';

import { Inject, Injectable, Scope } from '@framework-frontend/node';
import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';
import {
    CustomerFeedbackEntityResponse,
    FeedbackEntityResponse,
    QuestionResponse,
    Question,
    AswerResponse
} from '../models/chatSurvey/chat-survey-respones.model';
import {
    PostFeedbackResponse,
    PostFeedbackRequest
} from '../models/chatSurvey/post-feedback-response.model';
import { ConfigurationManagement } from '../../common/utils/configurationManage';
import { FeedbackCommentCardErrorCodeErrorCode } from '../const/server/errorCode/feedback-error-code-map.const';
import { ValidationError } from '../validator/validationError';
import { BizChatSurvey } from '../../common/types/biz-chatSurvey';
import { PrivateData } from '../controllers/feedback.api.controller';
@Injectable({ scope: Scope.REQUEST })
export class FeedbackService {
    private;
    constructor(
        private readonly httpFactory: NodeHttpFactory,
        @Inject(REQUEST) readonly request: FastifyRequest
    ) {}
    public async GetFeedbackData(): Promise<Partial<CustomerFeedbackEntityResponse> | null> {
        const chatSurveyConfig = ConfigurationManagement.BizChatSurvey;
        const feedbackHashCode = chatSurveyConfig.FeedBackInfo.HashCode;
        const validateCreateRequest = (
            chatSurveyConfig: BizChatSurvey,
            feedbackHashCode: string
        ): FeedbackCommentCardErrorCodeErrorCode => {
            if (!chatSurveyConfig.FeedBackInfo) {
                return FeedbackCommentCardErrorCodeErrorCode.SERVICE_ERROR;
            }
            if (!feedbackHashCode) {
                return FeedbackCommentCardErrorCodeErrorCode.SERVICE_ERROR;
            }
            return FeedbackCommentCardErrorCodeErrorCode.NO_ERROR;
        };
        const errorCode = validateCreateRequest(chatSurveyConfig, feedbackHashCode);
        if (FeedbackCommentCardErrorCodeErrorCode.NO_ERROR !== errorCode) {
            throw new ValidationError(errorCode, '');
        }

        const feedbackData = await this.GetFeedbackEntity(feedbackHashCode);
        const response = new CustomerFeedbackEntityResponse();
        let questions = feedbackData?.ResponseEntry?.Questions;
        if (questions == null || questions.length == 0) {
            return response;
        }
        if (!isNull(chatSurveyConfig.FeedBackInfo.ExcludeQuesion)) {
            let excludeQuestionIds = chatSurveyConfig.FeedBackInfo.ExcludeQuesion.split(',');
            questions = questions.filter(
                (question) => !excludeQuestionIds.includes(question.QuestionMasterId.toString())
            );
        }

        response.HashCode = feedbackHashCode;
        response.Questions = new Array<QuestionResponse>();
        const replacesInfos =
            chatSurveyConfig?.FeedBackInfo == null
                ? new Array<Question>()
                : chatSurveyConfig.FeedBackInfo.QuestionReplaceInfo.Question;
        questions.forEach((question) => {
            const questionResponse = new QuestionResponse();
            questionResponse.QuestionMasterId = question.QuestionMasterId;
            const existQuest = (replacesInfos as any)?.find(
                (t: { QuestionMasterId: number }) => t.QuestionMasterId == question.QuestionMasterId
            );
            if (existQuest != null) {
                questionResponse.QuestionText = existQuest.QuestionText;
            } else {
                questionResponse.QuestionText = question.QuestionText;
            }
            questionResponse.Priority = question.Priority;
            questionResponse.IsGeneralRating = question.IsGeneralRating;
            questionResponse.IsContactFeild = question.IsContactFeild;
            questionResponse.IsRequired = question.IsRequired;
            questionResponse.QuestionType = question.Answer.AnswerType;
            if (
                question.Answer != null &&
                question.Answer.Rating != null &&
                question.Answer.Rating.RatingLabels != null &&
                question.Answer.Rating.RatingLabels.length > 0
            ) {
                questionResponse.Answers = new Array<AswerResponse>();
                question.Answer.Rating.RatingLabels.forEach((rate) => {
                    const answer = new AswerResponse();
                    answer.Priority = rate.Priority;
                    answer.TransactionNumber = rate.TransactionNumber;
                    answer.Value = rate.Value;
                    questionResponse.Answers.push(answer);
                });
                questionResponse.Answers = questionResponse.Answers.sort((a, b) => {
                    return b.Priority - a.Priority;
                });
            }
            response.Questions.push(questionResponse);
        });
        return response;
    }

    private async GetFeedbackEntity(feedbackHashCode: string): Promise<FeedbackEntityResponse> {
        try {
            const result = await this.httpFactory
                .create('CommentCard')
                .send<FeedbackEntityResponse>({ hashCode: feedbackHashCode });
            return result.data;
        } catch (e) {
            return Promise.resolve({});
        }
    }

    public async PostFeedback(
        request,
        req: PrivateData
    ): Promise<Partial<PostFeedbackResponse> | boolean> {
        if (request == null) {
            return false;
        }

        try {
            request = JSON.parse(request);
        } catch {}
        // const validateCreateRequest = (request: ChatSurveySubmitVal): SubmitFeedbackCommentCardErrorCodeErrorCode => {
        //     const VariablesError = request.Variables.some((v) => !!v.Value === false)
        //     if (VariablesError) {
        //         return SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_Variables_EMPTY
        //     }
        //     if (!request.logingEmailAddress) {
        //         return SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_EMAIL_EMPTY
        //     }
        //     return SubmitFeedbackCommentCardErrorCodeErrorCode.NO_ERROR;
        // }
        // const errorCode = validateCreateRequest(request)
        // if (SubmitFeedbackCommentCardErrorCodeErrorCode.NO_ERROR !== errorCode) {
        //     throw new ValidationError(errorCode, '');
        // }

        if (request == null || (request && request?.Variables == null)) {
            return false;
        }

        const sendRequestData = new PostFeedbackRequest();
        sendRequestData.CommentHashCode = request.CommentHashCode;
        sendRequestData.ScreenResolution = request.ScreenResolution;
        sendRequestData.PreviousPage = request.PreviousPage;
        sendRequestData.RequestURL = request.RequestURL;
        sendRequestData.UserAgent = request.UserAgent;
        sendRequestData.OSName = request.OSName;
        sendRequestData.OSVersion = request.OSVersion;
        sendRequestData.IPAddress = req.iPAddress;
        sendRequestData.ScreenResolution = request.ScreenResolution;
        sendRequestData.BrowserVersion = request.BrowserVersion;
        sendRequestData.BrowserName = request.BrowserName;

        sendRequestData.LoginEmailAddress = req.loginEmailAddress;
        sendRequestData.IsPremier = req.isPremier;
        sendRequestData.NV_DVINFO = req.customerNumber;

        if (request.Answers !== null && request.Answers.length > 0) {
            sendRequestData.Answers = request.Answers;
        }
        if (request.Variables !== null && request.Variables.length > 0) {
            sendRequestData.Variables = request.Variables;
        }
        const response = await this.PostFeedbackService(sendRequestData);
        return !!response && response;
    }
    private async PostFeedbackService(
        sendRequestData: PostFeedbackRequest
    ): Promise<PostFeedbackResponse> {
        let res: PostFeedbackResponse = {
            Success: false
        };
        try {
            const result = await this.httpFactory
                .create('Submit')
                .addBody(sendRequestData)
                .send<PostFeedbackResponse>();
            return result.data;
        } catch (e) {
            (this.request as any)
                .getLogger()
                .error(`Error in PostFeedbackService(submit feedback):${e}`);
            return Promise.resolve(res);
        }
    }
}
