import { atom } from 'recoil';

export enum ChatAgentWindowStatus {
    ConnectToAgentPending = 'ConnectToAgentPending',
    ConnectToAgentSuccess = 'ConnectToAgentSuccess',
    ConnectToAgentFail = 'ConnectToAgentFail',
    EndChat = 'EndChat',
}

export const chatAgentWindowStatusAtom = atom<ChatAgentWindowStatus>({
    key: 'ChatAgentWindowStatus',
    default: ChatAgentWindowStatus.ConnectToAgentPending,
});
