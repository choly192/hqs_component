import { atom } from 'recoil';

export enum ChatLoginStatus {
    None,
}

export const chatLoginStatusAtom = atom<ChatLoginStatus>({
    key: 'ChatLoginStatus',
    default: ChatLoginStatus.None,
});
