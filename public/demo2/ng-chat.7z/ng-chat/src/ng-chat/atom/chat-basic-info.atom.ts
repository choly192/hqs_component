import { atom } from 'recoil';

import { ChatType, InitialState } from '../types';

export type chatBasicInfo = {
    isClose?: boolean;
    closeMsg?: string;
    loginName?: string;
    emailAddress?: string;
    category?: string;
    topic?: string;
    reason?: string;
    type?: ChatType;
};

export const chatLayoutBasicInfoAtom = atom<chatBasicInfo>({
    key: 'chatBasicInfo',
    default: {},
    dangerouslyAllowMutability: true,
});
