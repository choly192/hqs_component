import { atom } from 'recoil';

export type LayoutStatus = {
    avatarType: AvatarType;
};

export enum DialogType {
    show,
    close,
}

export enum AvatarType {
    None,
    inLine,
    offLine,
}

export const currentChatLayoutStatusAtom = atom<LayoutStatus>({
    key: 'CurrentChatLayout',
    default: {
        avatarType: AvatarType.None,
    },
});
