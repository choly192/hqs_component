import { atom } from 'recoil';

export enum ChatBotWindowStatus {
    ConnectToChatPending = 'ConnectToChatPending',
    ConnectToChatSuccess = 'ConnectToChatSuccess',
    ConnectToChatFail = 'ConnectToChatFail',
}

export const chatBotWindowStatusAtom = atom<ChatBotWindowStatus>({
    key: 'ChatBotWindowStatus',
    default: ChatBotWindowStatus.ConnectToChatPending,
});
