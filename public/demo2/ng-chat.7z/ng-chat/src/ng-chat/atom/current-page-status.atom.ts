import { atom } from 'recoil';

import { ResponseBody } from '../../common/client/response/model';
import { CreateAgentChatErrorCodeErrorCode } from '../const/server';

import { CreateAgentChatResponse } from '../models';

export enum PageType {
    ChatLogin = 'ChatLogin',
    ChatAgentWindow = 'ChatAgentWindow',
    ChatBotWindow = 'ChatBotWindow',
    ChatSurvey = 'ChatSurvey',
    ChatSurveySuccess = 'ChatSurveySuccess',
    ChatClose = 'ChatClose'
}

class CurrentPageStatus<T, K extends keyof T> {
    pageType: K;
    additionInfo?: T[K];
}

class AdditionInfo {
    [PageType.ChatLogin]: null;
    [PageType.ChatAgentWindow]: ChatAgentWindowAdditionInfo;
    [PageType.ChatBotWindow]: null;
    [PageType.ChatSurvey]: null;
    [PageType.ChatSurveySuccess]: null;
    [PageType.ChatClose]: null;
}

class ChatAgentWindowAdditionInfo {
    botToAgentStatus?: boolean;
    isReconnected?: boolean;
    otherBotWindowToAgent?: boolean;
    message?: string;
    chatbotHistoryLink?: string;
    member?: string;
    needShowQuestion?: boolean;
}

class ChatCloseAdditionInfo {
    message?: string;
}

export const currentPageStatusAtom = atom<CurrentPageStatus<AdditionInfo, PageType>>({
    key: 'CurrentPageStatus',
    default: {
        pageType: PageType.ChatLogin
    }
});
