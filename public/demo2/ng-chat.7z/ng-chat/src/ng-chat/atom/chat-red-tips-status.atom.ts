import { atom } from 'recoil';

export enum ChatRedTipsStatus {
    open,
    close,
}

interface ChatRedTipsStatusDefault {
    status: ChatRedTipsStatus;
}

export const ChatRedTipsStatusAtom = atom<ChatRedTipsStatusDefault>({
    key: 'ChatRedTipsStatus',
    default: {
        status: ChatRedTipsStatus.open,
    },
})