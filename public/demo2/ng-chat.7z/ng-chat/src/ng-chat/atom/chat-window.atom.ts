import { atom } from 'recoil';

import { MsgType, RenderMsgByType } from '../types/msg.type';
import { RenderChatMsg } from '../utils';

const chatWindowMsgListAtom = atom<Array<RenderChatMsg<RenderMsgByType, MsgType>>>({
    key: 'ChatWindowMsgList',
    dangerouslyAllowMutability: true,
    default: [],
});

export { chatWindowMsgListAtom };
