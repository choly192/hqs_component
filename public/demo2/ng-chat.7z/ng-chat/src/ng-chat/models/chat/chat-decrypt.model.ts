export interface DecryptLogin {
    EmailAddress: string;
}

export interface DecryptLoginQuery {
    encryptedEmailAddress: string;
}
