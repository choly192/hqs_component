import { Country } from '../../common/types';
import { ChatType } from '../types';

export class NgChatQuery {
    injectionType: InjectionType;
    country: Country = 'USA';
    language: string = 'en';
    topic?: string;
    reason?: string;
    category?: string;
    type?: ChatType = ChatType.NormalChat;
    loginName?: string;
    emailAddress?: string;
    encryptedEmailAddress?: string;
    encryptedCustomerNumber?: string;
    currencyCode: string = 'USD';
    nvtc: string;
    specifiedQueue?: string;
}

export type InjectionType = 'popup' | 'embed';
