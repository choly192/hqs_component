import { CustomFields } from './purecloud.create.model';
import { IsBoolean, IsOptional } from 'class-validator';
import { ParamAndQueryAndBodyErrorCode } from '../../const/server/errorCode/param-query-error-body-code-map.const';

class AgentMemberResponse {
    entities: Array<MemberEntity>;
    pageCount: number;
    pageNumber: number;
    pageSize: number;
    total: number;
}

class AgentMemberRequestBody {
    companyCode: number;

    @IsBoolean({ message: ParamAndQueryAndBodyErrorCode.INPUT_TRANSCRIPT_FORMAT_ERROR })
    @IsOptional()
    sendTransScript?: boolean;

    @IsOptional()
    country: string;
    
    @IsOptional()
    language: string;
}

class MemberEntity {
    id: string;
    displayName: string;
    avatarImageUrl: string;
    role: string;
    joinDate: string;
    authenticatedGuest: boolean;
    customFields: CustomFields;
    state: string;
    memberName: string;
}
export { AgentMemberResponse, MemberEntity, AgentMemberRequestBody };
