import { ChatType } from '../../types';

interface OverChatServiceTime {
    close: boolean;
    message: string;
}

interface OverChatServiceTimeReqQuery {
    country: string;
    category: string;
    type: ChatType;
}

export { OverChatServiceTime, OverChatServiceTimeReqQuery };
