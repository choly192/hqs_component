import { IsNotEmpty, IsBoolean, IsOptional, MaxLength } from 'class-validator'

import { ChatType } from '../../types';
import { ParamAndQueryAndBodyErrorCode } from '../../const/server/errorCode/param-query-error-body-code-map.const'
export class AgentQueryToken {
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_TOKEN_ILLEGAL })
    token: string;
}

export class AgentQueryCategoryAndType {
    category: string;
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_TYPE_EMPTY })
    type: ChatType;
}

export class AgentQueryAttachmentFile {
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_TOKEN_ILLEGAL })
    token: string;
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_MESSAGE_ILLEGAL })
    message: string;
}
