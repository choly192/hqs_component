import { ParamAndQueryAndBodyErrorCode } from '../../const/server/errorCode/param-query-error-body-code-map.const'
import { IsNotEmpty } from 'class-validator'

class ConversationAndMemberIdParam {
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_COVERSATIONI_ILLEGAL })
    conversationId: string;
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_MEMBERID_ILLEGAL })
    memberId: string;
}
class ConversationIdParam {
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_COVERSATIONI_ILLEGAL })
    conversationId: string;
}
class ConversationIdAndMessageIdParam {
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_COVERSATIONI_ILLEGAL })
    conversationId: string;
    @IsNotEmpty({ message: ParamAndQueryAndBodyErrorCode.INPUT_MESSAGEID_ILLEGAL })
    messageId:string
}

export {
    ConversationAndMemberIdParam,
    ConversationIdParam,
    ConversationIdAndMessageIdParam
}