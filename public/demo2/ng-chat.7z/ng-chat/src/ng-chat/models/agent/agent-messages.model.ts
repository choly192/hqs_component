export class ConversationMessagesResponse {
    pageSize: number;
    entities: Array<WebChatMessageEntity>;
}

export class WebChatMessageEntity {
    id: string;
    conversation: MessageConversation;
    sender: MessageSender;
    body: string;
    bodyType: string;
    timestamp: string;
    selfUri: string;
}

export class MessageConversation {
    id: string;
    selfUri: string;
}

export class MessageSender {
    id: string;
}

export class GuestCustomerMessageReqBody {
    msgId: string;
}
export class GuestCustomerMessageResponse {
    messageId: string;
    conversationId: string;
    senderName: string;
    sendMessage: string;
    sendTime: number;
    role: string;
    avatarImageUrl: string;
    senderID: string;
}
