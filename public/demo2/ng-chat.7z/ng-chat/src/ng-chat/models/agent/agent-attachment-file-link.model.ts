export class GetAttachmentFileLinkResponse {
    Success?: boolean;
    shortUrl: string;
}