interface TranslateRequest {
    sourceLanguageCode?: string;
    targetLanguageCode: string;
    text: string;
}

interface Translate {
    originText: string;
    oriLanguageCode:string;
    translateText: string;
    translateLanguageCode: string;
}

interface TranslateResponse {
    body: TranslateBody;
    header: TranslateHeader;
}

interface TranslateBody {
    detectedLanguageCode: string;
    sourceText: string;
    translateText: string;
}

interface TranslateHeader {
    code: number;
    message: string;
}

export { TranslateResponse, TranslateRequest, Translate };
