class EndConversation {
    ConversationID: string;
    EnableEmailTranscript?: boolean;
    CountryCode: string;
    CompanyCode: number;
    LanguageCode: string;
}
export { EndConversation };
