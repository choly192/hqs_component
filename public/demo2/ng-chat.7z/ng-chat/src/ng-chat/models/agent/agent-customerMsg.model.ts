import {
    SenCustomerMsgToAgentErrorCode,
} from '../../const/server/errorCode/customer-msg-agent-error-code-map.const'
import {
    IsNotEmpty,
    MaxLength,
} from 'class-validator';
class CustomerMsgToAgentRes {
    sendSuccess: boolean;
    oriMessage: string;
    translateMessage: string;
    sendTime: number;
    oriLanguage: string;
    targetLanguage: string;
    msgId: string;
    pureCloudSendTime: string;
}

class CustomerMsgToAgentReq {
    @IsNotEmpty({ message: SenCustomerMsgToAgentErrorCode.INPUT_MESSAGE_ILLEGAL })
    @MaxLength(500, { message: SenCustomerMsgToAgentErrorCode.INPUT_MESSAGE_TOO_LARGE })
    message: string;
    sendTime: number;
    memberName: string;
    sourceLanguage: string;
}

class WebChatMessageRes {
    id: string;
    conversation: MessageConversation;
    sender: MessageSender;
    body: string;
    bodyType: string;
    timestamp: string;
    selfUri: string;
}
class MessageConversation {
    id: string;
    selfUri: string;
}
class MessageSender {
    id: string;
}

class SaveConversationMessageRequest {
    MsgID: string;
    ConversationID: string;
    FromID: string;
    FromName: string;
    SourceMessage: string;
    SourceLanguage: string;
    TargetMessage: string;
    TargetLanguage: string;
    SendTime: string;
    CountryCode: string;
    CompanyCode: string;
    InDate: Date;
}

export {
    CustomerMsgToAgentRes,
    CustomerMsgToAgentReq,
    WebChatMessageRes,
    SaveConversationMessageRequest,
};
