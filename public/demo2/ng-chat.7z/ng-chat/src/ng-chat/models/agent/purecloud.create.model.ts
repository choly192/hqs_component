interface PureCloudWebChatConversationRequest {
    organizationId: string;
    deploymentId: string;
    routingTarget: Partial<RoutingTarget>;
    memberInfo: Partial<MemberInfo>;
    memberAuthToken: string;
}

interface RoutingTarget {
    targetType: string;
    targetAddress: string;
    skills: string[];
    // language: string;
    priority: number;
}

interface MemberInfo {
    displayName: string;
    customFields: Partial<CustomFields>;
}

interface CustomFields {
    firstName: string;
    lastName: string;
    email: string;
    customerId: string;
    customField1Label: string;
    customField2Label: string;
    customField3Label: string;
    customField1: string;
    customField2: string;
    customField3: string;
}

interface PureCloudWebChatConversationResponse {
    eventStreamUri: string;
    id: string;
    jwt: string;
    member: Member;
}

interface Member {
    id: string;
}

export {
    PureCloudWebChatConversationRequest,
    RoutingTarget,
    MemberInfo,
    CustomFields,
    PureCloudWebChatConversationResponse,
};
