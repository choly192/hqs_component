import { Translate } from './translate.model';

class AgentSaveRequest {
    agentMessage: string;
    agentId: string;
    targetLanguage: string;
    msgID: string;
    agentName: string;
    sendTime: number;
}

class AgentSaveResponse implements Translate {
    originText: string;
    oriLanguageCode: string;
    translateText: string;
    translateLanguageCode: string;
    messageId: string;
    agentId: string;
    sendTime: number;
    needTranslate: boolean;
}

export { AgentSaveRequest, AgentSaveResponse };
