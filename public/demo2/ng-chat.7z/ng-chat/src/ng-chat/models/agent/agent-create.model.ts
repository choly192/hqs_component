import {
    IsBoolean,
    IsEmail,
    IsIn,
    IsNotEmpty,
    IsOptional,
    Length,
    MaxLength
} from 'class-validator';

import { ChatType } from '../../types';
import { CreateAgentChatErrorCodeErrorCode } from '../../const/server';
class CreateAgentChatRequest {
    @Length(1, 80, { message: CreateAgentChatErrorCodeErrorCode.INPUT_FULLNAME_ILLEGAL })
    @IsNotEmpty({ message: CreateAgentChatErrorCodeErrorCode.INPUT_FULLNAME_EMPTY })
    fullName: string;

    @Length(1, 128, { message: CreateAgentChatErrorCodeErrorCode.EMAIL_TOO_LARGE })
    @IsNotEmpty({ message: CreateAgentChatErrorCodeErrorCode.INPUT_EMAIL_EMPTY })
    emailAddress: string;

    @IsBoolean({ message: CreateAgentChatErrorCodeErrorCode.INPUT_TRANSCRIPT_FORMAT_ERROR })
    @IsOptional()
    sendMeTranscript?: boolean;

    @MaxLength(200, { message: CreateAgentChatErrorCodeErrorCode.INPUT_CATEGORY_TOO_LARGE })
    @IsNotEmpty({ message: CreateAgentChatErrorCodeErrorCode.INPUT_CATEGORY_EMPTY })
    category: string;

    @MaxLength(50, { message: CreateAgentChatErrorCodeErrorCode.INPUT_TOPIC_TOO_LARGE })
    @IsNotEmpty({ message: CreateAgentChatErrorCodeErrorCode.INPUT_TOPIC_EMPTY })
    topic: string;

    @MaxLength(50, { message: CreateAgentChatErrorCodeErrorCode.INPUT_REASON_TOO_LARGE })
    @IsOptional()
    reason?: string;

    @MaxLength(800, { message: CreateAgentChatErrorCodeErrorCode.INPUT_QUESTION_TOO_LARGE })
    @IsOptional()
    question?: string;

    @IsOptional()
    nvtc: string;

    @IsNotEmpty({ message: CreateAgentChatErrorCodeErrorCode.INPUT_Type_EMPTY })
    type: ChatType;

    @IsOptional()
    country: string;

    @IsOptional()
    encryptedCustomerNumber: string;

    @IsOptional()
    SpecifiedQueue: string;
}

class CreateAgentChatResponse {
    socketUrl: string;
    token: string;
    conversationID: string;
    chatSource: string;
    memberId: string;
    sourceLanguage: string;
    question: string;
    translateQuestion: string;
}

class IPDataInfo {
    region: string;

    cyc: string;

    city: string;

    pcode: string;

    lat: string;

    lon: string;

    cyn: string;

    org: string;
}

export { CreateAgentChatRequest, CreateAgentChatResponse, IPDataInfo };
