export interface InitialChatBotRes {
    SessionId: string;
    Token: string;
    Valid?: boolean;
    ValidTo?: string;
    ValidToDateTime?: string;
}
