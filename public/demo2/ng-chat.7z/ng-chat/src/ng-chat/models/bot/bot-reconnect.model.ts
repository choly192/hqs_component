enum PermissionType {
    //PermissionType<-10，为需要断开且清理LocalStorage
    NEEDDISCONNECTED = -10,
    NIDInValid = -16,
    NIDInBlackList = -15,
    IPInBlackList = -14,
    NVTCInValid = -13,
    NVTCInBlackList = -12,
    SessionInValid = -11,

    //PermissionType<0 && value>-10，为需要断开，但不需要清理
    NONEEDDISCONNECTED = 0,
    UserConnectionTooMany = -1,
    IPConnectionTooMany = -2,
    ReachMaxConnection = -3,

    //Ok to connect
    Allow = 1,
}

export { PermissionType };
