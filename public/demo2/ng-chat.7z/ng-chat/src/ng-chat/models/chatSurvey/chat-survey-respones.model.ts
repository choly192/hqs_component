class FeedbackEntityResponse {
    Result?: Result;
    Succeeded?: boolean;
    ResponseEntry?: ResponseEntry;
    Success?: boolean;
    ResponseCode?: string;
}
class Result {
    HashCode: string;
    CardInfo: CardInfo;
    HeaderInfo: HeaderInfo;
    ThankYouTemplateInfo: ThankYouTemplateInfo;
    Question: Array<Question>;
}
class CardInfo {
    Name: string;
    Domain: string;
    EnableScreenShot: boolean;
    Status: number;
}

class HeaderInfo {
    Name: string;
    MainMessage: string;
}

class ThankYouTemplateInfo {
    Name: string;
    MainMessage: string;
    AutoCloseSeconds: number;
}
class Question {
    QuestionMasterId: number;
    QuestionText: string;
    Priority: number;
    IsRequired: boolean;
    IsContactFeild: boolean;
    IsGeneralRating: boolean;
    IsGaryBackground: boolean;
    GroupId: number;
    Answer: Answer;
}
class Answer {
    TransactionNumber: number;
    AnswerType: string;
    Status: number;
    InUser: string;
    InDate: string;
    LastEditUser: string;
    LastEditDate: string;
    Rating: Rating;
    RatingLists: Array<object>;
    OpenEndedQuestion: Openendedquestion;
}
class Rating {
    TransactionNumber: number;
    AnswerMasterId: number;
    Status: number;
    InUser: string;
    InDate: string;
    LastEditUser: string;
    LastEditDate: string;
    RatingLabels: Array<Ratinglabel>;
}
class Ratinglabel {
    TransactionNumber: number;
    RatingId: number;
    Priority: number;
    Value: string;
    Status: number;
    InUser: string;
    InDate: string;
    LastEditUser: string;
    LastEditDate: string;
}

class Openendedquestion {
    TransactionNumber: number;
    Status: number;
    AnswerMasterId: number;
    Rows: number;
    Placeholder: string;
    InUser: string;
    InDate: string;
    LastEditUser: string;
    LastEditDate: string;
}
class ResponseEntry {
    HashCode: string;
    CardInfo: CardInfo;
    HeaderInfo: HeaderInfo;
    ThankYouTemplateInfo: ThankYouTemplateInfo;
    Questions: Array<Question>;
}

class CustomerFeedbackEntityResponse {
    HashCode: string;
    Questions: Array<QuestionResponse>;
}

class QuestionResponse {
    QuestionMasterId: number;
    QuestionText: string;
    Priority: number;
    IsContactFeild: boolean;
    IsGeneralRating: boolean;
    IsRequired: boolean;
    QuestionType: string;
    Answers: Array<AswerResponse>;
    Value: string;
    error: boolean;
}

class AswerResponse {
    TransactionNumber: number;
    Value: string;
    Priority: number;
}

export {
    FeedbackEntityResponse,
    CustomerFeedbackEntityResponse,
    QuestionResponse,
    Question,
    AswerResponse
};
