class PostFeedbackResponse {
    Success: boolean;
    ResponseCode?: string;
}

class ResponseRecieveFromMobileRequest {
    CommentHashCode: string;
    ScreenResolution: string;
    PreviousPage: string;
    RequestURL: string;
    UserAgent: string;
    OSName: string;
    OSVersion: string;
    BrowserVersion: string;
    BrowserName: string;
    Answers: Array<AnswerRequest>;
    Variables: Array<VariablesRequest>;
}
class AnswerRequest {
    QuestionMasterId: number;
    Value: string;
}
class VariablesRequest {
    Key: string;
    Value: string;
}

class PostFeedbackRequest {
    CommentHashCode: string;
    ScreenResolution: string;
    Screenshot: string;
    PreviousPage: string;
    RequestURL: string;
    OSVersion: string;
    OSName: string;
    UserAgent: string;
    NVTC: string;
    BrowserVersion: string;
    BrowserName: string;
    IPAddress: string;
    Domain: string;
    NV_DVINFO: string;
    NV_ECARTID: string;
    LoginEmailAddress: string | null;
    IsPremier?: boolean | null;
    Answers: Array<PostFeedbackAnswer>;
    Variables: Array<ResponseRecieveFromMobileVariable>;
}

class PostFeedbackAnswer {
    QuestionMasterId: number;
    QuestionText: string;
    Value: string;
    OpendEndedQuestionText: string;
    RatingListId: number;
    OtherText: string;
}

class ResponseRecieveFromMobileVariable {
    Key: string;
    Value: string;
}

export {
    PostFeedbackResponse,
    ResponseRecieveFromMobileRequest,
    PostFeedbackRequest,
    PostFeedbackAnswer,
    ResponseRecieveFromMobileVariable
};
