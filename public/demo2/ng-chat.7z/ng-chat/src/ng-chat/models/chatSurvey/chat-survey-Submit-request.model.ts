import {
    IsBoolean,
    IsEmail,
    IsIn,
    IsNotEmpty,
    IsOptional,
    Length,
    MaxLength,
} from 'class-validator';
import { SubmitFeedbackCommentCardErrorCodeErrorCode } from '../../const/server/errorCode/feedback-error-code-map.const';

class ChatSurveySubmitVal {
    // @IsNotEmpty({ message: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_CommentHashCode_EMPTY })
    CommentHashCode: string;

    ScreenResolution: string;
    PreviousPage?: string;
    RequestURL: string;
    OSVersion: string;
    OSName: string;
    BrowserVersion: string;
    BrowserName: string;
    UserAgent: string;

    // @IsNotEmpty({ message: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_EMAIL_EMPTY })
    // @Length(1, 128, { message: SubmitFeedbackCommentCardErrorCodeErrorCode.EMAIL_TOO_LARGE })
    // @IsEmail({}, { message: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_EMAIL_FORMAT_ERROR })
    logingEmailAddress: string;

    Answers: Array<ChatSurveySubmitAnswersVal>;
    Variables: Array<ChatSurveySubmitVariablesVal>;
}
class ChatSurveySubmitAnswersVal {
    QuestionMasterId: number;
    Value: string | null;
    // NoRequiredValue?:string;
    // IsRequiredValue?:string
}
class ChatSurveySubmitVariablesVal {
    // @IsNotEmpty({ message: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_Variables_EMPTY })
    Key: string;
    // @IsNotEmpty({ message: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_Variables_EMPTY })
    Value: string;
}

class PostFeedBackQuery {
    EncryptedCustomerNumber: string;
}

export {
    ChatSurveySubmitVal,
    ChatSurveySubmitAnswersVal,
    ChatSurveySubmitVariablesVal,
    PostFeedBackQuery,
};
