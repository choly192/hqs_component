export class UploadReqParams {
    nvtc: string;
    authorization: string;
    contentType: string;
    host: string;
}