import { CascaderOptions } from '../../common/component';
import {
    BizChatBot,
    BizCommon,
    WebConfig,
    ApplicationWebsocket,
    BizChatAgent
} from '../../common/types';
import {
    BizChatLoginByCountry,
    BizCustomizedUIByCountry
} from '../../common/utils/convert-config.util';
import { NgChatQuery } from '../models';

export type InitialState = {
    Config: Config;
    AdditionInfo: NgChatQuery;
    IsClose: boolean;
    CloseMsg: string;
};

type Config = {
    BizChatLoginConfig: BizChatLoginByCountry;
    BizCommonConfig: BizCommon;
    BizCustomizedUIConfig: BizCustomizedUIByCountry;
    SocketConfig: ApplicationWebsocket;
    BizChatBot: BizChatBot;
    BizChatAgent: BizChatAgent;
    WebConfig: WebConfig;
    TopicAndReasonConfig: Array<CascaderOptions>;
};
