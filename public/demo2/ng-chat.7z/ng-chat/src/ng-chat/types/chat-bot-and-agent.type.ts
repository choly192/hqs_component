import { Ref } from 'react';
import { ChatInputBarProps, ChatInputBarRefMethod, HeaderProps } from '../component';

interface ChildrenProps extends ChatInputBarProps {
    ref: Ref<ChatInputBarRefMethod>;
}

export type ChatWindowChildrenType = (props: ChildrenProps) => JSX.Element;

export interface ChatWindowCompProps {
    setHeaderInfo: (data: any) => any;
    onMsgListScroll: (wait?: number) => void;
    renderInputBar: ChatWindowChildrenType;
}

export interface ChatWindowCompRef {
    onCollapse: () => void;
    onClose: () => void;
}