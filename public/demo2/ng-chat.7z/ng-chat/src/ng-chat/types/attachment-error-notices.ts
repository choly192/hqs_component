export enum AttachmentNotices {
    getUploadConfigError = "Uh-oh, it looks like we have our wires crossed. Please try again later.",
    uploadError = "Connection timeout.",
    fileTypeError = "Unsupported file type (supported: JPG, PNG and PDF).",
    fileSizeError = "Exceeded maximum file size (10M).",
    fileCountError = "Uploading files beyond the number limit.",
    hasUploadedInAnotherWindowError = "Upload in progress on another window.",
    checkFileHeaderTypeError = "Try saving it in a different format and upload again.",
    commonError ="The attachment(s) being uploaded does not meet the criteria!"
}
