export enum ConnectWith {
    Initial,
    Agent,
    ChatBot,
    Ended
}
