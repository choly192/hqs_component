export interface ChatLoginSubmitVal {
    FullName: ValueInfo;
    EmailAddress: ValueInfo;
    EnableSendMeTranscript: boolean;
    Category: ValueInfo;
    Topic: ValueInfo;
    Reason: ValueInfo;
    Question: ValueInfo;
}
interface ValueInfo {
    value: string;
    error: boolean;
    needShow?: boolean;
}
