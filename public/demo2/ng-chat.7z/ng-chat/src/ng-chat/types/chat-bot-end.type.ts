import { ChatStatus } from '../../common/storage';

export enum ChatBotEndType {
    Initial = 'Initial',
    ToAgent = 'ToAgent',
    BotEnd = 'BotEnd',
}

export const chatBotEndStorageChatStatusMapping = {
    [ChatBotEndType.Initial]: ChatStatus.Initial,
    [ChatBotEndType.ToAgent]: ChatStatus.BotToAgent,
    [ChatBotEndType.BotEnd]: ChatStatus.Ended,
}
