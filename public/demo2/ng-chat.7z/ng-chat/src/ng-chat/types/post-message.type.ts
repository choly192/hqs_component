export type PostMessage = {
    type?: 'CHAT';
    action?:
        | 'close'
        | 'collapse'
        | 'setCookie'
        | 'showAvatarIcon'
        | 'showNormalIcon'
        | 'showRedTip'
        | 'removeRedTip'
        | 'initialHeaderVal';
    classes?: string;
    style?: string;
    cookieExpire?: number;
    cookieValue?: string;
};

export type PostMessageFromPage = {
    key: 'chat';
    siteCookie?: string;
    loginName?: string;
    emailAddress?: string;
    category?: string;
    topic?: string;
    reason?: string;
    type?: ChatType;
    noAction?: boolean;
    fromHeader?: boolean;
};

export enum ChatType {
    NormalChat = 1,
    ChatDirectly,
    SpecialQueue,
    SpecifiedQueue
}
