import { NoticeType } from '../const/browser';
import { ActionButton, ChatBotMsg, LinkButton } from './chat-bot-message.type';

export enum MsgType {
    Agent = 'Agent',
    ChatBot = 'ChatBot',
    User = 'User',
    // AgentWithTranslate = 'AgentWithTranslate',
    // USerWithTranslate = 'USerWithTranslate',
    // ChatBotUSerAttachment = 'ChatBotUSerAttachment',
    // AgentUserAttachment = 'AgentUserAttachment',
    Avatar = 'Avatar',
    Notice = 'Notice',
    Typing = 'Typing',
    Actions = 'Actions',
}

export class RenderMsgByType {
    [MsgType.Agent]: AgentAdditionalInfo;
    // [MsgType.AgentWithTranslate]: AgentTranslateAdditionalInfo;
    [MsgType.ChatBot]: ChatBotAdditionalInfo;
    [MsgType.User]: UserAdditionalInfo;
    // [MsgType.USerWithTranslate]: UserTranslateAdditionalInfo;
    // [MsgType.ChatBotUSerAttachment]: NormalAdditionalInfo;
    [MsgType.Avatar]: AvatarAdditionalInfo;
    [MsgType.Notice]: NoticeAdditionalInfo;
    [MsgType.Typing]: TypingAdditionalInfo;
    [MsgType.Actions]: ActionsAdditionalInfo;
    // [MsgType.AgentUserAttachment]: AgentUserAdditionInfo;
}

export class BaseMsgInfo {
    oriMsg: string;
    date: Date;
    translateMsg?: string;
}

export class BaseAdditionalInfo {
    msgList: Array<BaseMsgInfo>;
    time?: string = '';
    isError?: boolean = false;
}

export class AgentMsgInfo extends BaseMsgInfo {
    isTranslated?: boolean = false;
    msgId?: string;
}
export class AgentAdditionalInfo extends BaseAdditionalInfo {
    msgList: Array<AgentMsgInfo>;
}

export class ChatBotAdditionalInfo {
    msgList: Array<{
        data: ChatBotMsg;
        date?: Date;
        onSendMessage: (msg: string) => void;
    }>;
    isInteraction?: boolean = true;
    time?: string = '';
}

export class UserMsgInfo extends BaseMsgInfo {
    msgId?: string;
    isTranslated?: boolean = false;
    isAttachment?: boolean = false;
    fileType?: AgentFileType = AgentFileType.None;
    fileName?: string = '';
    isRetryMsg?: boolean = false;
    progress?: number = 0;
    isUploading?: boolean = false;
    retryFn?: Function;
}
export class UserAdditionalInfo extends BaseAdditionalInfo {
    msgList: Array<UserMsgInfo>;
}

export interface AvatarAdditionalInfo {
    notice: string;
    style: React.CSSProperties;
}

export interface NoticeAdditionalInfo {
    notice: string;
    id: NoticeType;
}

export interface TypingAdditionalInfo {}

export interface ActionsAdditionalInfo {
    suggestions: LinkButton[];
    actionButton: ActionButton;
    onSendMessage: (msg: string) => void;
    onUploadVisible: () => void;
    visible?: boolean;
}

export enum AgentFileType {
    None = '',
    PDF = '.pdf',
    DOCX = '.docx',
    XLSX = '.xlsx',
    PNG = '.png',
    JPG = '.jpg',
    JPEG = '.jpeg',
    GIF = '.gif',
    BMP = '.bmp',
    TIFF = '.tiff',
}

export const FileTypeStyle = {
    [AgentFileType.None]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
    [AgentFileType.PDF]: {
        containerClass: 'attachment-pdf',
        iconClass: 'fa-file-pdf-o',
    },
    [AgentFileType.DOCX]: {
        containerClass: 'attachment-doc',
        iconClass: 'fa-file-word-o',
    },
    [AgentFileType.XLSX]: {
        containerClass: 'attachment-doc',
        iconClass: 'fa-file-excel-o',
    },
    [AgentFileType.PNG]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
    [AgentFileType.JPG]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
    [AgentFileType.JPEG]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
    [AgentFileType.GIF]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
    [AgentFileType.BMP]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
    [AgentFileType.TIFF]: {
        containerClass: 'attachment-txt',
        iconClass: 'fa-file-image-o',
    },
};
