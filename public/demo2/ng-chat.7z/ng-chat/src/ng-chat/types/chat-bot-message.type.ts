export enum RichResponseTypeEnum {
    List = 'List',
    Card = 'Card',
    Table = 'Table',
    SimpleText = 'SimpleText',
    ActionButton = 'ActionButton',
}

export type RichResponsesType = Array<List | Card | Table | SimpleText>;

export interface ChatBotMsg {
    DiagnosticInfo: DiagnosticInfo;
    IntentConfidence: number;
    IntentDetected: string;
    Messages: string[];
    Metadata: Metadata;
    RichResponses: RichResponsesType;
    SessionId: string;
    Suggestions: LinkButton[];
    Type: string;
}

export interface DiagnosticInfo {
    parent_trace_id: string;
    span_id: string;
    trace_id: string;
    webhook_latency_ms: number;
}

export interface Metadata {
    ConnectToAgent: boolean;
    ConversationFinished: boolean;
    Enabled: boolean;
    Type: string;
}

export interface Card {
    Type: RichResponseTypeEnum.Card;
    Title: string;
    Subtitle?: string;
    Description?: string;
    ImageUrl: string;
    Properties?: Properties[];
    Button?: LinkButton;
}

export interface Table {
    Type: RichResponseTypeEnum.Table;
    Title: string;
    Subtitle?: string;
    Headers: string[];
    Rows: Array<string[]>;
}

export interface List {
    InteractionEnabled?: boolean;
    Items: ListItems[];
    Type: RichResponseTypeEnum.List;
    Title: string;
}

export interface ListItems {
    Type: 'ListItem';
    Title: string;
    Description?: string;
    ImageUrl?: string;
    Properties?: Properties[];
    ResponseText?: string;
}

export interface Properties {
    Name: string;
    Value: string;
    Link?: string;
}

export interface SimpleText {
    Type: RichResponseTypeEnum.SimpleText;
    Messages?: string[];
}

export interface ActionButton {
    Type: RichResponseTypeEnum.ActionButton;
    Title: string;
    ResponseText: string;
    ResponseEvent?: string;
    Parameters: ActionButtonParameters;
}

export interface ActionButtonParameters {
    WindowTitle: string;
    Description: string;
    AcceptedType: string;
    MaxCount: number;
    Identity: string;
}

export interface LinkButton {
    ResponseText?: string;
    TargetLink?: string;
    Title: string;
}
