import { ErrorType } from '../../common/component/upload';

export const errTypeCustomFieldsKeyMapping = {
    [ErrorType.fileTypeError]: 'UnsupportedFileTypeMsg',
    [ErrorType.fileSizeError]: 'MaximumFileSizeMsg',
};
