import { ResponseCodeMap } from '../../../../common/server/response/responseCodeMap';
import { HttpStatus } from '../http-status.const';

enum CreateAgentChatErrorCodeErrorCode {
    NO_ERROR = '1000000',
    SERVICE_ERROR = '5000000',
    INPUT_SOURCE_ILLEGAL = '4000010',
    CHAT_UNAVAILABLE = '2000011',
    INPUT_FULLNAME_ILLEGAL = '4000020',
    INPUT_FULLNAME_EMPTY = '4000021',
    EMAIL_TOO_LARGE = '4000030',
    INPUT_EMAIL_EMPTY = '4000031',
    INPUT_EMAIL_FORMAT_ERROR = '4000032',
    INPUT_CATEGORY_EMPTY = '4000040',
    INPUT_TOPIC_EMPTY = '4000041',
    INPUT_CATEGORY_TOO_LARGE = '4000042',
    INPUT_TOPIC_TOO_LARGE = '4000043',
    INPUT_REASON_EMPTY = '4000050',
    INPUT_REASON_TOO_LARGE = '4000051',
    INPUT_ITEM_EMPTY = '4000050',
    INPUT_QUESTION_EMPTY = '4000060',
    INPUT_QUESTION_TOO_LARGE = '4000060',
    INPUT_Type_EMPTY = '4000070',
    INPUT_TRANSCRIPT_FORMAT_ERROR = '4000080',
}

const CreateAgentChatErrorCodeMapping: ResponseCodeMap<CreateAgentChatErrorCodeErrorCode>[] = [
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.SERVICE_ERROR,
        Message: 'Server error',
        Status: HttpStatus.INTERNAL_SERVER_ERROR,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_SOURCE_ILLEGAL,
        Message: 'source is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.CHAT_UNAVAILABLE,
        Message: '',
        Status: HttpStatus.OK,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_FULLNAME_ILLEGAL,
        Message: 'fullName is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_FULLNAME_EMPTY,
        Message: 'fullName is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.EMAIL_TOO_LARGE,
        Message: 'emailAddress is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_EMAIL_EMPTY,
        Message: 'email is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_EMAIL_FORMAT_ERROR,
        Message: 'email is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_CATEGORY_EMPTY,
        Message: 'category is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_TOPIC_EMPTY,
        Message: 'topic is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_REASON_EMPTY,
        Message: 'reason is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_Type_EMPTY,
        Message: 'type is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_QUESTION_EMPTY,
        Message: 'question is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_TRANSCRIPT_FORMAT_ERROR,
        Message: 'sendMeTranscript is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_CATEGORY_TOO_LARGE,
        Message: 'category is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_TOPIC_TOO_LARGE,
        Message: 'topic is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: CreateAgentChatErrorCodeErrorCode.INPUT_REASON_TOO_LARGE,
        Message: 'reason is too large',
        Status: HttpStatus.BAD_REQUEST,
    },
];


export {
    CreateAgentChatErrorCodeErrorCode,
    CreateAgentChatErrorCodeMapping,
};
