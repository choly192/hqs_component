import { ResponseCodeMap } from '../../../../common/server/response/responseCodeMap';
import { HttpStatus } from '../http-status.const';
enum SenCustomerMsgToAgentErrorCode {
    NO_ERROR = '1000000',
    SERVICE_ERROR = '5000000',
    INPUT_COVERSATIONID_ILLEGAL = '4000010',
    INPUT_MEMBERID_ILLEGAL = '4000020',
    INPUT_TOKEN_ILLEGAL = '4000030',
    INPUT_MESSAGE_ILLEGAL = '4000040',
    INPUT_MESSAGE_TOO_LARGE = '4000041',
}
const SenCustomerMsgToAgentErrorCodeMapping: ResponseCodeMap<SenCustomerMsgToAgentErrorCode>[] = [
    {
        ErrorCode: SenCustomerMsgToAgentErrorCode.SERVICE_ERROR,
        Message: 'Server error',
        Status: HttpStatus.INTERNAL_SERVER_ERROR,
    },
    {
        ErrorCode: SenCustomerMsgToAgentErrorCode.INPUT_COVERSATIONID_ILLEGAL,
        Message: 'coversationID is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SenCustomerMsgToAgentErrorCode.INPUT_MEMBERID_ILLEGAL,
        Message: 'memberId is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SenCustomerMsgToAgentErrorCode.INPUT_TOKEN_ILLEGAL,
        Message: 'token is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SenCustomerMsgToAgentErrorCode.INPUT_MESSAGE_ILLEGAL,
        Message: 'message is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SenCustomerMsgToAgentErrorCode.INPUT_MESSAGE_TOO_LARGE,
        Message: 'message is illegall',
        Status: HttpStatus.BAD_REQUEST,
    },

]
export {
    SenCustomerMsgToAgentErrorCode,
    SenCustomerMsgToAgentErrorCodeMapping
}