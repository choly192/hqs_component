import { ResponseCodeMap } from '../../../../common/server/response/responseCodeMap';
import { HttpStatus } from '../http-status.const';

export enum BaseErrorCode {
    NO_ERROR = '1000000',
    SERVICE_ERROR = '5000000',
}

export const BaseErrorCodeMapping: ResponseCodeMap<BaseErrorCode>[] = [
    {
        ErrorCode: BaseErrorCode.NO_ERROR,
        Message: '',
        Status: HttpStatus.OK,
    },
    {
        ErrorCode: BaseErrorCode.SERVICE_ERROR,
        Message: 'Server error',
        Status: HttpStatus.INTERNAL_SERVER_ERROR,
    },
];
