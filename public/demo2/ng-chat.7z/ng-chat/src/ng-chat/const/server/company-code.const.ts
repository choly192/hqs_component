export const CompanyCode = 1003;
