import { ResponseCodeMap } from '../../../../common/server/response/responseCodeMap';
import { HttpStatus } from '../http-status.const';
enum FeedbackCommentCardErrorCodeErrorCode {
    NO_ERROR = '1000000',
    SERVICE_ERROR = '5000000',
}
enum SubmitFeedbackCommentCardErrorCodeErrorCode {
    NO_ERROR = '1000000',
    SERVICE_ERROR = '5000000',
    INPUT_Variables_EMPTY = '4000010',
    INPUT_CommentHashCode_EMPTY = '4000020',
    INPUT_EMAIL_EMPTY = '4000030',
    INPUT_EMAIL_FORMAT_ERROR = '4000031',
    EMAIL_TOO_LARGE = '4000032',
    LOGIN_FAILED = '4000040'
}
const FeedbackCommentCardErrorCodeMapping: ResponseCodeMap<FeedbackCommentCardErrorCodeErrorCode>[] = [
    {
        ErrorCode: FeedbackCommentCardErrorCodeErrorCode.SERVICE_ERROR,
        Message: 'Server error',
        Status: HttpStatus.INTERNAL_SERVER_ERROR,
    },
]

const SubmitFeedbackCommentCardErrorCodeMapping: ResponseCodeMap<SubmitFeedbackCommentCardErrorCodeErrorCode>[] = [
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.SERVICE_ERROR,
        Message: 'Server error',
        Status: HttpStatus.INTERNAL_SERVER_ERROR,
    },
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_Variables_EMPTY,
        Message: 'Chatsurvey Variables is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_CommentHashCode_EMPTY,
        Message: 'Chatsurvey CommentHashCode is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_EMAIL_EMPTY,
        Message: 'email is EMPTY',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.INPUT_EMAIL_FORMAT_ERROR,
        Message: 'email is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.EMAIL_TOO_LARGE,
        Message: 'emailAddress is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: SubmitFeedbackCommentCardErrorCodeErrorCode.LOGIN_FAILED,
        Message: 'Login failed',
        Status: HttpStatus.BAD_REQUEST,
    }
];

export {
    FeedbackCommentCardErrorCodeErrorCode,
    FeedbackCommentCardErrorCodeMapping,
    SubmitFeedbackCommentCardErrorCodeMapping,
    SubmitFeedbackCommentCardErrorCodeErrorCode,
};