import { HttpStatus } from '../http-status.const'
enum ParamAndQueryAndBodyErrorCode {
    NO_ERROR = '1000000',
    SERVICE_ERROR = '5000000',
    INPUT_COVERSATIONI_ILLEGAL = '4000010',
    INPUT_MEMBERID_ILLEGAL = '4000020',
    INPUT_TOKEN_ILLEGAL = '4000030',
    INPUT_MESSAGEID_ILLEGAL = '4000021',
    INPUT_CATEGORY_EMPTY = '4000040',
    INPUT_CATEGORY_TOO_LARGE='4000041',
    INPUT_TYPE_EMPTY='4000070',
    INPUT_TRANSCRIPT_FORMAT_ERROR='4000080',
    INPUT_MESSAGE_ILLEGAL = '4000050',
}
const ParamAndQueryAndBodyErrorCodeMapping = [
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.SERVICE_ERROR,
        Message: 'Server error',
        Status: HttpStatus.INTERNAL_SERVER_ERROR,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_COVERSATIONI_ILLEGAL,
        Message: 'coversationID is illegal',
        Status: HttpStatus.BAD_REQUEST
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_MEMBERID_ILLEGAL,
        Message: 'memberId is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_TOKEN_ILLEGAL,
        Message: 'token  is illegal',
        Status: HttpStatus.BAD_REQUEST
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_MESSAGEID_ILLEGAL,
        Message: 'messageId is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_CATEGORY_EMPTY,
        Message: 'category is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_CATEGORY_TOO_LARGE,
        Message: 'category is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_TYPE_EMPTY,
        Message: 'type is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_TRANSCRIPT_FORMAT_ERROR,
        Message: 'sendTransScript is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
    {
        ErrorCode: ParamAndQueryAndBodyErrorCode.INPUT_MESSAGE_ILLEGAL,
        Message: 'message is illegal',
        Status: HttpStatus.BAD_REQUEST,
    },
]
export {
    ParamAndQueryAndBodyErrorCode,
    ParamAndQueryAndBodyErrorCodeMapping
}