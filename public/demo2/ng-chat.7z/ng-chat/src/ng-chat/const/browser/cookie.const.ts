const ChatStatusCookieName = 'wschat';
const ChatCookie = 'NV_CustomizedInfoes';
const ONE_DAY = 3600 * 1000 * 24;

export { ChatStatusCookieName, ChatCookie, ONE_DAY };
