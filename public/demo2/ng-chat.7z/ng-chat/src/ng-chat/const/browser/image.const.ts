const HeaderIcon = 'WebResource/Chat/Themes/Nest/agent-headset-icon.png';
export { HeaderIcon };
