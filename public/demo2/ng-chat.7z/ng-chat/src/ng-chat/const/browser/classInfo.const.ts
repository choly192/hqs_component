export const inputClassSteps = ['single-line', 'double-line', 'triple-line'];
