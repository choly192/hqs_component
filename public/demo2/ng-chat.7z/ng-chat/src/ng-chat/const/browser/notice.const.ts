enum NoticeType {
    Connecting = 'Connecting',
    AgentConnect = 'AgentConnect',
    AgentConnectFailed = 'AgentConnectFailed',
    ChatEnded = 'ChatEnded',
    ChatBotToAgent = 'ChatBotToAgent',
    ChatBotRetryMaxCounts = 'ChatBotRetryMaxCounts',
    ChatBotTimeout = 'ChatBotTimeout',
    ChatBotUploadConfigError = 'ChatBotUploadConfigError',
    Offline = 'Offline',
    Reconnect = 'Reconnect',
}

const NoticeConst = {
    [NoticeType.Connecting]: {
        value: 'Connecting',
        id: NoticeType.Connecting,
    },
    [NoticeType.AgentConnect]: {
        value: 'Agent is connecting...',
        id: NoticeType.AgentConnect,
    },
    [NoticeType.AgentConnectFailed]: {
        value: 'Failed to connect, please refresh the page and try again',
        id: NoticeType.AgentConnectFailed,
    },
    [NoticeType.ChatEnded]: {
        value: 'Chat session has ended',
        id: NoticeType.ChatEnded,
    },
    [NoticeType.ChatBotToAgent]: {
        value: 'Transferring to agent...',
        id: NoticeType.ChatBotToAgent,
    },
    [NoticeType.ChatBotRetryMaxCounts]: {
        value: 'Unable to connect, you may have exceeded the maximum number of connections.',
        id: NoticeType.ChatBotRetryMaxCounts,
    },
    [NoticeType.ChatBotTimeout]: {
        value: '',
        id: NoticeType.ChatBotTimeout,
    },
    [NoticeType.ChatBotUploadConfigError]: {
        value: 'Uh-oh, it looks like we have our wires crossed. Please try again later.',
        id: NoticeType.ChatBotUploadConfigError,
    },
    [NoticeType.Offline]: {
        value: 'No internet connection, please check your network.',
        id: NoticeType.Offline,
    },
    [NoticeType.Reconnect]: {
        value: 'Attempting to reconnect to your session...',
        id: NoticeType.Reconnect,
    }
};

export { NoticeConst, NoticeType };
