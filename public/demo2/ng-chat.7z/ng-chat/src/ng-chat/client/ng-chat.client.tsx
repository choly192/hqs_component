import { clientBootstrap } from "../../common/client/bootstrap/bootstrap-browser";

import { NgChatView } from "../views/NgChatView";


clientBootstrap(NgChatView);

