import React, { FC, forwardRef, Ref, useImperativeHandle, useRef, useState } from 'react';
import cn from 'classnames';

import { Button } from '../../common/component';

import { inputClassSteps } from '../const/browser';
import { getInputLine } from '../utils';

export interface ChatInputBarProps {
    accept?: string;
    disabled?: boolean;
    onInput?: () => void;
    onKeyUp?: () => void;
    onClick?: () => void;
    onUpload?: (files) => void;
    maxLength: number;
    showUploadIcon?: boolean;
}

export interface ChatInputBarRefMethod {
    getValue: () => string;
}

export const ChatInputBar: FC<
    ChatInputBarProps & { ref?: Ref<ChatInputBarRefMethod> }
> = forwardRef(
    ({
         accept = 'image/*,pdf/*',
         disabled = false,
         maxLength,
         showUploadIcon = false,
         onInput,
         onKeyUp,
         onClick,
         onUpload = () => {},
     }, ref) => {
        const [line, setLine] = useState<number>(1);
        const inputRef = useRef<HTMLTextAreaElement>(null);

        useImperativeHandle(ref, () => ({
            getValue() {
                return inputRef?.current?.value?.trim() ?? '';
            },
        }));

        const resetTextArea = () => {
            if (inputRef.current) {
                inputRef.current.value = '';
                setLine(1);
            }
        };

        const handleUploadChange = (e) => {
            e.stopPropagation();
            e.preventDefault();
            const files = e.target.files ?? [];
            if (files.length > 0) {
                onUpload([...files]);
            }
        }

        return (
            <div
                className={cn(
                    'NE-chat-input-bar show-message',
                    { disabled: disabled },
                    inputClassSteps[line - 1],
                )}
            >
                <div className="columns message-bar">
                    {showUploadIcon && (
                        <label className="upload-btn">
                            <input
                                style={{ fontSize: 0, cursor: 'pointer' }}
                                type="file"
                                value={''}
                                accept={accept}
                                onChange={handleUploadChange}
                            />
                            <i className="fa fa-paperclip" />
                        </label>
                    )}
                    <textarea
                        rows={1}
                        className={cn('form-textarea')}
                        placeholder='Type message here...'
                        ref={inputRef}
                        maxLength={maxLength}
                        onInput={() => {
                            setLine((preLine) => {
                                const count = getInputLine(inputRef.current as HTMLTextAreaElement);
                                if (count != preLine) {
                                    return count;
                                }
                                return preLine;
                            });
                            onInput && onInput();
                        }}
                        onKeyDown={(e) => {
                            if (e.keyCode == 13) {
                                e.preventDefault();
                                e.stopPropagation();
                                if (onKeyUp && inputRef.current?.value) {
                                    onKeyUp();
                                    resetTextArea();
                                }
                            }
                        }}
                    />
                    <Button
                        text="send"
                        className="btn-primary send-btn"
                        onClick={() => {
                            if (inputRef.current) {
                                if (onClick && inputRef.current?.value) {
                                    onClick();
                                    resetTextArea();
                                }
                            }
                        }}
                    />
                </div>
            </div>
        );
    },
);

ChatInputBar.displayName = 'ChatInputBar';
