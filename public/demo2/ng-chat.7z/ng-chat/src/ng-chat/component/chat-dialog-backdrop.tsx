import React, { useState, FC } from 'react';
interface DialogBackdropProps {
    onClick: (event: React.MouseEvent<HTMLSpanElement, MouseEvent>) => void;
}
export const DialogBackdrop: FC<DialogBackdropProps> = ({ onClick }) => {
    return (
        <div className="NE-chat-dialog-backdrop">
            <div className="NE-chat-dialog">
                <div className="NE-chat-dialog-inner">
                    <div className="NE-chat-dialog-title">Oops!</div>
                    <div className="NE-chat-dialog-text">
                        <p>Connection error, please try again.</p>
                    </div>
                </div>
                <div className="NE-chat-dialog-buttons">
                    <span
                        className="NE-chat-dialog-button btn btn-primary is-wide"
                        onClick={onClick}
                    >
                        OK
                    </span>
                </div>
            </div>
        </div>
    );
};
