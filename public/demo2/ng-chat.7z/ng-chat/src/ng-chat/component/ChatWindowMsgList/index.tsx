import React, { useEffect, useMemo } from 'react';
import { useRecoilState } from 'recoil';
import { chatWindowMsgListAtom } from '../../atom';

const ChatWindowMsgList = ({ msgScrollRef }) => {
    const [windowChatMsgList] = useRecoilState(chatWindowMsgListAtom);

    const renderMsgList = useMemo(() => {
        return windowChatMsgList &&
            windowChatMsgList.length > 0 &&
            windowChatMsgList.map((t, index) => t.ele(index, t.additionInfo));
    }, [windowChatMsgList]);

    return (
        <div className="NE-chat-content show-chat">
            <div className="chat-section">
                <ul className="chat-entries" ref={msgScrollRef}>
                    {renderMsgList}
                </ul>
            </div>
        </div>
    );

}

export default ChatWindowMsgList;
