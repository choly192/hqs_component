import React, { FC, useState, useCallback } from "react"
interface RatingEggProps {
    onClick?: (e: any) => void;
    value: any[]
}
export const RatingEgg: FC<RatingEggProps> = ({
    onClick,
    value
}) => {
    const [ratingIconClickIndex, steratingIconClickIndex] = useState<number>(0)
    const [ratingIconHoverindex, setRatingIconHoverindex] = useState<number>(0)

    return (
        <>
            <div className={`rating-eggs ${!!ratingIconClickIndex ? `rating-${ratingIconClickIndex}` : ""} ${!!ratingIconHoverindex ? `hover-${ratingIconHoverindex}` : ""}`} >
                {
                    value && value.length > 0 && value.map((item, index) => {
                        return (<span
                            onPointerOver={useCallback(() => { setRatingIconHoverindex(index + 1) }, [index])}
                            onPointerLeave={useCallback(() => { setRatingIconHoverindex(0) }, [ratingIconHoverindex])}
                            onClick={useCallback(() => { onClick && onClick(item), steratingIconClickIndex(index + 1), setRatingIconHoverindex(0) }, [])}
                            key={`RatingEggs-${index}`} className="rating-egg"></span>)
                    })
                }
            </div>
        </>
    )
}
