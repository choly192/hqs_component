import React, { FC, useEffect, useState, useCallback } from "react"
import { RatingEgg } from "./RatingEgg"
interface RatingEggsProps {
    questionMasterId: number;
    questionText: string;
    answers: Array<AnswerEntity>;
    isRequired: boolean;
    questionType: string;
    onClick?: (e: string, Id: number) => void;
    error?: boolean;
}
interface AnswerEntity {
    TransactionNumber: number;
    Value: string;
    Priority: number;
}

export const RatingEggs: FC<RatingEggsProps> = ({
    questionText,
    questionMasterId,
    answers,
    questionType,
    onClick,
    error

}) => {
    const [ratingValue, steRatingValue] = useState("")

    return (
        <>
            {questionType && questionType === "Rating" ? <div className={`rating-item ${error ? "is-error" : ""}`} >
                <label>{questionText}</label>
                <RatingEgg
                    value={answers}
                    onClick={(e) => {
                        steRatingValue(e.Value), onClick && onClick(e.Value, questionMasterId)
                    }} />
                {!!ratingValue && <p style={{ fontSize: 13, color: "#7ab676" }} >{ratingValue}</p>}
            </div> : null}
        </>
    )
}
