import React, { FC } from 'react';

import { useInitialState } from '../../common/server/interceptors/context/GlobalContext';

import { useChatUtils } from '../hooks';
import { InitialState } from '../types';

export interface HeaderProps {
    noName?: boolean;
    showCollapseIcon?: boolean;
    showCloseIcon?: boolean;
    showRedTips?: boolean;
    handleCollapseIcon?: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void;
    handleCloseIcon?: (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => void;
    styles?: React.CSSProperties;
    member?: string;
    isChatBot?: boolean;
}

export const Header: FC<HeaderProps> = ({
    noName = true,
    showCollapseIcon,
    showCloseIcon,
    showRedTips = false,
    handleCollapseIcon = () => {},
    styles,
    member,
    handleCloseIcon = () => {},
    isChatBot,
}) => {
    const initialState = useInitialState<InitialState>();
    const { isPopup } = useChatUtils();

    const needShowCollapseIcon = (): boolean => {
        if (showCollapseIcon !== undefined && typeof showCollapseIcon == 'boolean') {
            return showCollapseIcon;
        }
        return isPopup();
    };

    const needShowCloseIcon = (): boolean => {
        if (showCloseIcon !== undefined && typeof showCloseIcon == 'boolean') {
            return showCloseIcon;
        }
        return isPopup();
    };

    return (
        <div
            className={`NE-chat-header${noName ? ' no-name' : ''}`}
            style={{
                padding: initialState?.AdditionInfo?.injectionType == 'popup' ? '12px' : '3px 10px',
            }}
        >
            {needShowCollapseIcon() && (
                <a className="NE-collapse-chat" title="collapse chat" onClick={handleCollapseIcon}>
                    <i className='fa fa-chevron-down'/>
                </a>
            )}

            <figure className="agent-icon" style={styles}>
                <i className='fa fa-user'/>
                {showRedTips && <span className='NE-chat-badge color-red'/>}
            </figure>
            <div className="NE-chat-agent-name">
                <h5>
                    {initialState?.Config?.BizCustomizedUIConfig?.ChatWindow?.Title?.Main ??
                        'Chat With Us'}
                </h5>
                <h6 style={isChatBot ? { whiteSpace: 'nowrap', textTransform: 'none' } : {}}>
                    {member}
                </h6>
            </div>
            {needShowCloseIcon() && (
                <a className="NE-close-chat" title="close chat" onClick={handleCloseIcon}>
                    <i className='fa fa-times'/>
                </a>
            )}
            {initialState?.Config?.BizCustomizedUIConfig?.ChatWindow?.Title?.Sub && (
                <div
                    style={{
                        marginLeft: isPopup() ? '39px' : '5px',
                        marginTop: '5px',
                    }}
                    dangerouslySetInnerHTML={{
                        __html: initialState?.Config?.BizCustomizedUIConfig?.ChatWindow?.Title?.Sub,
                    }}
                />
            )}
        </div>
    );
};
