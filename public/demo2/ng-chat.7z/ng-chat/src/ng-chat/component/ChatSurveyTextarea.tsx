import React, { FC, useEffect, useState, useCallback } from "react"
import { Textarea } from "../../common/component/textarea/TextArea"
interface ChatSurveyTextareaProps {
    onBlur?: (e: string, Id: number) => void;
    label: string;
    questionMasterId: number;
    isRequired: boolean;
}


export const ChatSurveyTextarea: FC<ChatSurveyTextareaProps> = ({
    onBlur,
    label,
    questionMasterId,
    isRequired,
}) => {

    return (
        <div className="comment-input" >
            <Textarea
                maxHeight={74}
                minHeight={57}
                maxLength={300}
                limit={300}
                label={label}
                customerClass="is-wide expandable"
                isOption={!isRequired}
                onBlur={(e) => {
                    if (e.target.value) {
                        onBlur && onBlur(e.target.value, questionMasterId,)
                    }
                }}
            />
        </div>
    )
}