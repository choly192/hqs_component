import React from 'react';
import trim from 'lodash/trim';
import { replaceLineFeed, replaceToStrongOrSup } from '../../../utils';
import {
    Card as CardProps,
    Properties as ChatBotProperties,
} from '../../../types/chat-bot-message.type';

interface PropertiesListItem {
    Name: string;
    Value: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
    Title,
    Subtitle,
    Description,
    ImageUrl,
    Properties,
    Button,
}) => {
    const renderProperties = (data: ChatBotProperties[]) => {
        const propertiesName: string[] = [];
        const propertiesList: { [key: string]: PropertiesListItem } = {};
        for (let item of data) {
            const value = replaceToStrongOrSup(item.Value);
            const isTrue = propertiesName.includes(item.Name);
            const { ...propertiesItem } = propertiesList[item.Name];
            propertiesList[item.Name] = {
                Name: item.Name,
                Value: <>
                    {propertiesItem.Value}
                    {isTrue && <br />}
                    {item?.Link ? <a href={trim(item?.Link)} target="_blank">
                            {value}
                        </a> : <span>{value}</span>}
                </>,
            };
            if (!isTrue) {
                propertiesName.push(item.Name);
            }
        }

        const renderList = Object.keys(propertiesList).map((value) => {
            const { Name, Value } = propertiesList[value];
            return (
                <React.Fragment key={value}>
                    <li>
                        <label>{Name}</label>
                        {Value}
                    </li>
                    <li />
                </React.Fragment>
            );
        });

        return renderList.length > 0 ? (
            <>
                <hr className="NE-chat-bot-divider" />
                <ul className="NE-chat-bot-bullets">
                    {renderList}
                </ul>
            </>
        ) : null;

    };

    const renderDesc = () => {
        if (Description) {
            const newDesc = replaceLineFeed(Description.replace(/\*/g, ''));

            return <div className="NE-chat-bot-content">{newDesc}</div>;
        }

        return null;
    };

    const renderSubtitle = () => {
        if (Subtitle) {
            const newSubtitle = replaceToStrongOrSup(Subtitle.replace(/:/g, ' '));

            return <div className="NE-chat-bot-info">{newSubtitle}</div>;
        }

        return null;
    };

    const renderButton = () => {
        const { Title, TargetLink = '' } = Button ?? {};

        if (!Title) {
            return null;
        }

        return (
            <>
                <hr className="NE-chat-bot-divider" />
                <div className="NE-chat-bot-action">
                    {TargetLink ? (
                        <a target="_blank" href={TargetLink}>
                            {Title}
                            <i
                                className="fa fa-external-link"
                                style={{ fontFamily: 'FontAwesome !important' }}
                            />
                        </a>
                    ) : (
                        <div>{Title}</div>
                    )}
                </div>
            </>
        );
    };

    return (
        <div className="entry-text is-block">
            <div className="NE-chat-bot-title">{Title}</div>
            {renderDesc()}
            {ImageUrl && (
                <div className="NE-chat-bot-img">
                    <img src={ImageUrl} alt="" />
                </div>
            )}
            {renderSubtitle()}
            {renderProperties(Properties ?? [])}
            {renderButton()}
        </div>
    );
};
