import React, { useState, useRef, useCallback, useEffect } from 'react';
import cn from 'classnames';
import { Button } from '../../../../common/component';
import Upload, {
    UploadPropsRef,
    UploadFile,
    ViewMode,
    StatusType,
    PermissionData,
    UploadReqData,
} from '../../../../common/component/upload';
import { ActionButton, AttachmentNotices } from '../../../types';

interface SubmitFileList {
    DisplayName: string;
    AttachmentID: string;
    Type: 'AsyncAttachment';
    ID: number;
    Status: 'Success';
    AttachmentType: number;
}

interface UploadPicturesDialogProps {
    onlineStatus: boolean;
    uploadReqParams?: UploadReqData;
    permissionData?: PermissionData;
    alreadyUploaded?: boolean;
    actionData: ActionButton;
    visible: boolean;
    onCancel?: () => void;
    onSubmit?: (data: string) => void;
}

export const UploadPicturesDialog: React.FC<UploadPicturesDialogProps> = ({
    uploadReqParams,
    permissionData,
    alreadyUploaded = false,
    actionData,
    visible = false,
    onCancel = () => {},
    onSubmit = () => {},
}) => {
    const [disabled, setDisabled] = useState<boolean>(true);
    const [fileList, setFileList] = useState<UploadFile[]>([]);

    const uploadRef = useRef<UploadPropsRef>(null);

    useEffect(() => {
        if (!visible) {
            uploadRef?.current?.onAllReset();
            setFileList([]);
            setDisabled(true);
        }
    }, [visible]);

    const handleUploadChange = useCallback((file, list, successFileList) => {
        const status = uploadRef?.current?.onGetStatus?.() ?? '';
        setDisabled(status === StatusType.uploading || successFileList.length === 0);
        setFileList(successFileList);
    }, [uploadRef]);

    const handleCancel = useCallback(() => {
        onCancel();
    }, [onCancel, uploadRef]);

    const handleSubmit = useCallback(() => {
        const dateId = new Date().getTime();
        const newFileList: SubmitFileList[] = fileList.map((item) => {
            return {
                DisplayName: item.name,
                AttachmentID: item?.response?.FileName ?? '',
                Type: 'AsyncAttachment',
                ID: dateId,
                Status: 'Success',
                AttachmentType: item.AttachmentType,
            };
        });

        const submitData = {
            Type: 0,
            Name: '',
            Attachments: newFileList,
        };

        if (actionData.ResponseText) {
            submitData.Type = 1;
            submitData.Name = actionData.ResponseText;
        } else if (actionData.ResponseEvent) {
            submitData.Type = 2;
            submitData.Name = actionData.ResponseEvent;
        }
        onSubmit(JSON.stringify(submitData));
        handleCancel();
    }, [fileList, actionData, onSubmit, handleCancel]);

    // TODO Parameter replacement: host nvtc Authorization
    return (
        <div className="NE-chat-dialog-backdrop" style={{ display: visible ? 'flex' : 'none' }}>
            <div className="NE-chat-dialog">
                <div className="NE-chat-dialog-inner">
                    <div className="NE-chat-dialog-title">
                        {actionData?.Parameters?.WindowTitle ?? 'Upload Pictures'}
                    </div>
                </div>
                <Upload
                    ref={uploadRef}
                    permissionData={permissionData}
                    viewMode={alreadyUploaded ? ViewMode.view : ViewMode.create}
                    bizType={6}
                    reqParams={{
                        host: uploadReqParams?.host,
                        options: {
                            Identity: actionData.Parameters.Identity,
                        },
                        header: {
                            nvtc: uploadReqParams?.header?.nvtc ?? '',
                            Authorization: uploadReqParams?.header?.Authorization ?? '',
                        },
                    }}
                    isAllErrorMessage
                    errorMessage={AttachmentNotices}
                    onChange={handleUploadChange}
                />
                <div className="NE-chat-dialog-buttons clear-children-space">
                    <Button
                        className="NE-chat-dialog-button btn btn-mini layout-half"
                        text="CANCEL"
                        type="button"
                        onClick={handleCancel}
                    />
                    <Button
                        className={cn('NE-chat-dialog-button btn btn-primary layout-half', {
                            'inactive': alreadyUploaded || disabled,
                        })}
                        disabled={disabled}
                        text="SUBMIT"
                        type="button"
                        onClick={handleSubmit}
                    />
                </div>
            </div>
        </div>
    );
}
