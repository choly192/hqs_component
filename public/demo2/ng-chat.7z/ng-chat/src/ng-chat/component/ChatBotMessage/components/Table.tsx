import React from 'react';
import { replaceToStrongOrSup } from '../../../utils';
import { Table as TableProps } from '../../../types/chat-bot-message.type';

export const Table: React.FC<TableProps> = ({ Title, Subtitle, Rows = [] }) => {
    const renderRows = () => {
        if (Rows.length > 0) {
            const rowList = Rows.map((item) => {
                const [label, val] = item;
                const value = replaceToStrongOrSup(val);

                return (
                    <li>
                        <label>{label}</label>
                        {value}
                    </li>
                );
            });

            return <ul className="NE-chat-bot-bullets">{rowList}</ul>;
        }

        return null;
    };

    return (
        <div className="entry-text is-block">
            {Title && <div className="NE-chat-bot-title">{Title}</div>}
            {Subtitle && <div className="NE-chat-bot-info">{replaceToStrongOrSup(Subtitle)}</div>}
            {renderRows()}
        </div>
    );
};
