import React, { useCallback } from 'react';
import debounce from 'lodash/debounce';
import { List as ChatBoxList, Properties } from '../../../types/chat-bot-message.type';
import { replaceLineFeed, replaceToStrongOrSup } from '../../../utils';

interface ListProps extends ChatBoxList {
    isInteraction: boolean;
    onSendMessage: (msg: string) => void;
}

export const List: React.FC<ListProps> = ({
    Title,
    InteractionEnabled,
    Items,
    isInteraction,
    onSendMessage,
}) => {
    const handleSendMessage = debounce((msg) => {
        isInteraction && onSendMessage(msg);
    }, 300);

    const renderProperties = useCallback((properties: Properties[] = [], desc: string = '') => {
        const newDesc = replaceToStrongOrSup(desc, true);

        if (properties.length > 0) {
            let renderPrice;
            let renderSeller: React.ReactNode[] = [];
            properties.forEach((item) => {
                if (item.Name === 'Price') {
                    renderPrice = (
                        <ul className="NE-chat-bot-price">
                            <li className="NE-chat-bot-price-current">{replaceToStrongOrSup(item.Value)}</li>
                        </ul>
                    );
                }

                if (item.Name === 'Seller') {
                    if (item?.Value && item.Value.toLowerCase().indexOf('newegg') > -1) {
                        renderSeller = [
                            ...renderSeller,
                            (
                                <div className="NE-chat-bot-seller">{newDesc}</div>
                            ),
                        ];
                    } else {
                        renderSeller = [
                            ...renderSeller,
                            (
                                <div className="NE-chat-bot-seller">Sold by {replaceToStrongOrSup(item.Value)}{newDesc}</div>
                            )
                        ]
                    }
                }
            });

            return (
                <>
                    {renderSeller}
                    {renderPrice}
                </>
            );
        }

        return (
            <div className="NE-chat-bot-seller">{newDesc}</div>
        );
    }, []);

    const renderListItems = () => {
        const renderItems = Items.map((item) => {
            const sendMsg = item?.ResponseText ?? item?.Title;

            const renderImage = item?.ImageUrl && (
                InteractionEnabled ? (
                    <a
                        className="NE-chat-bot-img"
                        onClick={() => handleSendMessage(sendMsg)}
                        style={{ cursor: 'pointer' }}
                    >
                        <img src={item.ImageUrl} alt="product" />
                    </a>
                ) : (
                    <div className="NE-chat-bot-img">
                        <img src={item.ImageUrl} alt="product" />
                    </div>
                )
            );

            const renderTitle = InteractionEnabled ? (
                <a onClick={() => handleSendMessage(sendMsg)}>
                    {replaceToStrongOrSup(item.Title, true)}
                </a>
            ) : replaceToStrongOrSup(item.Title, true);

            const properties = renderProperties(item?.Properties, item?.Description);

            return (
                <div className="NE-chat-bot-item">
                    {renderImage}
                    <div className="NE-chat-bot-wrap">
                        <div className="NE-chat-bot-desc" style={{height: 'auto'}}>
                            {renderTitle}
                        </div>
                        {properties}
                    </div>
                </div>
            )
        });

        return (
            <div className="NE-chat-bot-items">
                {renderItems}
            </div>
        );
    };

    return (
        <div className="entry-text is-block" style={{ pointerEvents: isInteraction ? 'auto' : 'none' }}>
            {Title && <div className="NE-chat-bot-title">{Title}</div>}
            {renderListItems()}
        </div>
    )
};
