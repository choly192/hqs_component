import React, { useCallback } from 'react';
import { List } from './components/List';
import { Card } from './components/Card';
import { Table } from './components/Table';
import { Suggestion } from './components/Suggestion';
import { UploadPicturesDialog } from './components/UploadPicturesDialog';
import { replaceHttpUrl } from '../../utils';
import {
    ChatBotMsg,
    RichResponseTypeEnum,
} from '../../types';

interface ChatBotMessageProps {
    data: ChatBotMsg;
    isInteraction: boolean;
    onSendMessage: (msg: string) => void;
}

const ChatBotMessage: React.FC<ChatBotMessageProps> = ({
    data,
    isInteraction,
    onSendMessage,
}) => {
    const renderMsgList = useCallback(
        (msg: string[], type: string) =>
            msg.map((val, i) => (
                <div key={`${type}-${i}`} className="entry-text">
                    {replaceHttpUrl(val)}
                </div>
            )),
        [],
    );

    const renderMessage = () => renderMsgList(data?.Messages ?? [], 'message');

    const renderRichRes = () =>
        data?.RichResponses?.map?.((item, index) => {
            if (item.Type === RichResponseTypeEnum.List) {
                return <List
                    key={`list-${index}`}
                    {...item}
                    isInteraction={isInteraction}
                    onSendMessage={onSendMessage}
                />;
            }

            if (item.Type === RichResponseTypeEnum.Card) {
                return <Card key={`card-${index}`} {...item} />;
            }

            if (item.Type === RichResponseTypeEnum.Table) {
                return <Table key={`table-${index}`} {...item} />;
            }

            if (item.Type === RichResponseTypeEnum.SimpleText && Array.isArray(item.Messages)) {
                return renderMsgList(item.Messages, 'richRes');
            }

            return null;
        }) ?? [];

    return (
        <>
            {renderMessage()}
            {renderRichRes()}
        </>
    );
};

export {
    List,
    Table,
    Card,
    Suggestion,
    UploadPicturesDialog,
};

export default ChatBotMessage;

