import React, { useMemo } from 'react';
import { trim, debounce } from 'lodash';
import { LinkButton } from '../../../types';

const debounceOptions = {
    leading: true,
    trailing: false,
};
interface SuggestionProps {
    data: LinkButton[];
    onSendMessage: (msg: string) => void;
}

export const Suggestion: React.FC<SuggestionProps> = ({
    data,
    onSendMessage,
}) => {
    const renderActionsBtn = useMemo(() => {
        return data.map((action, index) => {
            if (action?.TargetLink) {
                return (
                    <a
                        key={`${action.Title}${index}`}
                        href={trim(action.TargetLink)}
                        target="_blank"
                    >
                        {action.Title}
                        <i className="fa fa-external-link" style={{fontFamily: 'FontAwesome !important'}} />
                    </a>
                );
            }

            return (
                <a
                    key={`${action.Title}${index}`}
                    onClick={debounce(() => onSendMessage(action?.ResponseText ?? action.Title), 300)}
                >
                    {action.Title}
                </a>
            );
        });
    }, [data, onSendMessage]);

    return (
        <>
            {renderActionsBtn}
        </>
    );
};
