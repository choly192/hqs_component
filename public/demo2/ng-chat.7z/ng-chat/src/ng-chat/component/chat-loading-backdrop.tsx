import React,{FC} from "react"
interface LoadingBackdropPropos{
    isShowMask?:boolean
}
export const LoadingBackdrop:FC<LoadingBackdropPropos> = ({isShowMask}) => {
    return (
        <div className="NE-chat-loading-backdrop" style={isShowMask?{background:"rgba(0, 0, 0, .4)"}:{}}>
            <i className="fa fa-spinner"></i>
        </div>
    )
}
LoadingBackdrop.displayName='LoadingBackdrop';