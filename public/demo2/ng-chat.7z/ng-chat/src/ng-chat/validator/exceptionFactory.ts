import { ValidationError } from '@framework-frontend/node';
import { HttpException } from '@nestjs/common';

import { ResponseCodeMap } from '../../common/server/response/responseCodeMap';
import { setResponse } from '../../common/server/response/utils';

export class RequestValidationException<T> extends HttpException {
    constructor(codeMaps: ResponseCodeMap<T>[], errorMsg: T) {
        const responseData = setResponse(errorMsg, codeMaps, null);
        super(responseData.body, responseData?.httpCode);
    }
}
