export class ValidationError extends Error {
    public code: string;

    constructor(errorCode: string, message: string) {
        super(message);
        this.name = 'ValidationError';
        this.code = errorCode;
    }
}
