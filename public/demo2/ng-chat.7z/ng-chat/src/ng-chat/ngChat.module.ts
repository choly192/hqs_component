import { Module } from '@nestjs/common';

import { BrowserHttpFactory } from '../common/client/http/implements/browser-http-factory';
import { NodeHttpFactory } from '../common/server/http/implements/node-http-factory';
import {
    NgChatController,
    AgentChatApiController,
    FeedbackApiController,
    ChatApiController,
} from './controllers';
import { AgentService, BaseService } from './services';
import { FeedbackService } from './services/chatSurvey.service';

@Module({
    imports: [],
    controllers: [
        NgChatController,
        AgentChatApiController,
        FeedbackApiController,
        ChatApiController,
    ],
    providers: [BrowserHttpFactory, NodeHttpFactory, AgentService, FeedbackService, BaseService],
    exports: [],
})
export class NgChatModule {}
