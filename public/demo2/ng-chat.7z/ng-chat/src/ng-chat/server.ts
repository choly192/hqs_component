import path from 'path';

import { bootstrap } from '../common/server/bootstrap/bootstrap';
import { BootstrapModuleFactory } from '../common/server/bootstrap/bootstrap-module-factory';
import { NgChatModule } from './ngChat.module';

const bootstrapModule = BootstrapModuleFactory.create([NgChatModule]);

bootstrap(bootstrapModule, { rootDir: path.join(__dirname, '..')});
