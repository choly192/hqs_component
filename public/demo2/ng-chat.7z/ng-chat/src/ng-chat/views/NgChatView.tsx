import React, { FC } from 'react';
import { RecoilRoot } from 'recoil';
import { NgChatLayout } from '../page/NgChatLayout';

if (process.env.BROWSER) {
    require('../../../static/css/chat.css');
}

export const NgChatView: FC = () => {
    return (
        <>
            <RecoilRoot>
                <NgChatLayout />
            </RecoilRoot>
        </>
    );
};
NgChatView.displayName = 'NgChatView';
