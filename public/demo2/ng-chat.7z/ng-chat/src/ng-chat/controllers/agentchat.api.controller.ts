import { FastifyRequest, FastifyReply } from 'fastify';
import {
    Controller,
    Get,
    Req,
    Res,
    Param,
    Post,
    Body,
    UsePipes,
    Inject,
    Query
} from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { ConfigurationManager } from '@framework-frontend/node';

import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';
import { getBu, TripleDES } from '../../common/utils';

import { AgentService, BaseService } from '../services';
import { ValidationPipe } from '../validator/validationPipe';
import {
    CreateAgentChatErrorCodeErrorCode,
    CreateAgentChatErrorCodeMapping
} from '../const/server';

import {
    AgentMemberRequestBody,
    AgentMemberResponse,
    AgentSaveRequest,
    AgentSaveResponse,
    ConversationMessagesResponse,
    CreateAgentChatRequest,
    CustomerMsgToAgentReq,
    CustomerMsgToAgentRes,
    EndConversation,
    GuestCustomerMessageReqBody,
    GuestCustomerMessageResponse,
    MemberEntity,
    OverChatServiceTime,
    WebChatMessageEntity,
    WebChatMessageRes,
    ConversationIdParam,
    ConversationAndMemberIdParam,
    AgentQueryToken,
    AgentQueryCategoryAndType,
    AgentQueryAttachmentFile,
    OverChatServiceTimeReqQuery
} from '../models';
import { SetPrefix } from '../utils/chat-agent.util';
import { ValidationError } from '../validator/validationError';
import { inAgentServiceTime } from '../services/cs.closechat.service';
import { SenCustomerMsgToAgentErrorCodeMapping } from '../const/server/errorCode/customer-msg-agent-error-code-map.const';
import { ParamAndQueryAndBodyErrorCodeMapping } from '../const/server/errorCode/param-query-error-body-code-map.const';
import { ChatType } from '../types';

@Controller('api/agentchat')
export class AgentChatApiController {
    constructor(
        protected readonly _httpFactory: NodeHttpFactory,
        private readonly configMgr: ConfigurationManager,
        private readonly agentService: AgentService,
        private readonly baseService: BaseService,
        @Inject(REQUEST) readonly request: FastifyRequest
    ) {}

    @Post('create')
    @UsePipes(new ValidationPipe(CreateAgentChatErrorCodeMapping))
    async create(
        @Req() req: FastifyRequest,
        @Res() res: FastifyReply<any>,
        @Body() createDto: CreateAgentChatRequest
    ) {
        try {
            const countryCode = createDto.country || 'USA';
            const result = await this.agentService.create(createDto, countryCode, req);
            res.send(this.baseService.buildSuccessMsg(result).body);
        } catch (error) {
            let code = CreateAgentChatErrorCodeErrorCode.SERVICE_ERROR;
            if (error instanceof ValidationError) {
                code = error.code as CreateAgentChatErrorCodeErrorCode;
            }
            const responseInfo = this.baseService.buildErrorMsg(
                error,
                code,
                CreateAgentChatErrorCodeMapping
            );
            (req as any)
                .getLogger()
                .error(
                    `Error in create(create agent conversation):${error};request body:${JSON.stringify(
                        createDto
                    )};responseInfo:${JSON.stringify(responseInfo)}`
                );
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }
    @Get('agent/time')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async inAgentServiceTime(
        @Req() req: FastifyRequest,
        @Query() query: OverChatServiceTimeReqQuery,
        @Res() res: FastifyReply<OverChatServiceTime>
    ) {
        try {
            const countryCode = query.country || 'USA';
            const overServiceTime = await inAgentServiceTime(
                query.category ?? '',
                query.type ?? ChatType.NormalChat,
                countryCode,
                this._httpFactory,
                this.configMgr,
                req
            );
            res.send(this.baseService.buildSuccessMsg(overServiceTime).body);
        } catch (e) {
            const responseInfo = this.baseService.buildErrorMsg(e);
            (req as any).getLogger().error(`Error in inAgentServiceTime(get inCloseTime):${e}`);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Get(':conversationId/members/:memberId')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async getMemberState(
        @Req() req: FastifyRequest,
        @Query() query: AgentQueryToken,
        @Param() paras: ConversationAndMemberIdParam,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const response = await this._httpFactory
                .create('GetWebChatMember')
                .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                .method('GET')
                .send<MemberEntity>(paras);
            this.agentService.convertMemberName(response.data);
            res.send(this.baseService.buildSuccessMsg(response?.data).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in getMemberState(get member status):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Post(':conversationId/members/:memberId/status')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async getAgentConversationState(
        @Req() req: FastifyRequest,
        @Query() query: AgentQueryToken,
        @Param() paras: ConversationAndMemberIdParam,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const response = await this._httpFactory
                .create('GetWebChatMember')
                .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                .method('GET')
                .send<MemberEntity>(paras);

            res.send(
                this.baseService.buildSuccessMsg(
                    response?.data?.state?.toLocaleUpperCase() == 'CONNECTED'
                ).body
            );
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in getAgentConversationState(get conversation status):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Get(':conversationId/members')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async getAllMembersState(
        @Req() req: FastifyRequest,
        @Param() paras: ConversationIdParam,
        @Query() query: AgentQueryToken,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const response = await this._httpFactory
                .create('GetWebChatMembers')
                .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                .method('GET')
                .send<AgentMemberResponse>(paras);
            response.data.entities &&
                response.data.entities.length > 0 &&
                response.data.entities.forEach((item) => {
                    this.agentService.convertMemberName(item);
                });
            res.send(this.baseService.buildSuccessMsg(response?.data).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in getAllMembersState(get all member status):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Get(':conversationId/typing/:memberId')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async memberTyping(
        @Req() req: FastifyRequest,
        @Param() paras: ConversationAndMemberIdParam,
        @Query() query: AgentQueryToken,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const response = await this._httpFactory
                .create('PostWebChatMemberTyping')
                .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                .method('POST')
                .send<AgentMemberResponse>(paras);

            res.send(this.baseService.buildSuccessMsg(response?.data).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in memberTyping(customer typing):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Post(':conversationId/:memberId/end')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async end(
        @Req() req: FastifyRequest,
        @Param() paras: ConversationAndMemberIdParam,
        @Res() res: FastifyReply<any>,
        @Body() body: AgentMemberRequestBody
    ) {
        try {
            //TODO  发请求前需要验证会话状态
            const response = await this._httpFactory
                .create('SendEmailMessage')
                .method('POST')
                .addBody({
                    ConversationID: paras?.conversationId,
                    EnableEmailTranscript: body?.sendTransScript,
                    CountryCode: getBu(body.country || 'USA'),
                    CompanyCode: body.companyCode,
                    LanguageCode: body.language
                } as EndConversation)
                .send();
            res.send(this.baseService.buildSuccessMsg(response?.data).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in end(cs end conversation,send email):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Post(':conversationId/:memberId/endConversation')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async endConversation(
        @Req() req: FastifyRequest,
        @Param() paras: ConversationAndMemberIdParam,
        @Res() res: FastifyReply<any>,
        @Query() query: AgentQueryToken,
        @Body() body: AgentMemberRequestBody
    ) {
        try {
            //TODO  发请求前需要验证会话状态
            const response = await this._httpFactory
                .create('GetWebChatMember')
                .addHeader('Authorization', `Bearer ${query?.token}`)
                .method('GET')
                .send<MemberEntity>(paras);
            let result: boolean = true;
            if (response.data && response.data?.state?.toLocaleUpperCase() == 'CONNECTED') {
                const resp = await this._httpFactory
                    .create('EndWebChatMember')
                    .addHeader('Authorization', `Bearer ${query?.token}`)
                    .method('DELETE')
                    .send(paras);
                result = !!resp;
            }
            if (result) {
                await this._httpFactory
                    .create('SendEmailMessage')
                    .method('POST')
                    .addBody({
                        ConversationID: paras?.conversationId,
                        EnableEmailTranscript: body?.sendTransScript,
                        CountryCode: getBu(body.country || 'USA'),
                        CompanyCode: body.companyCode,
                        LanguageCode: body.language
                    } as EndConversation)
                    .send();
            }
            res.send(this.baseService.buildSuccessMsg(result).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in endConversation(customer end conversation,send email):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Post(':conversationId/:memberId/message')
    @UsePipes(new ValidationPipe(SenCustomerMsgToAgentErrorCodeMapping))
    async sendCustomerMessageToAgent(
        @Req() req: FastifyRequest,
        @Query() query: AgentQueryToken,
        @Body() body: CustomerMsgToAgentReq,
        @Param() paras: ConversationAndMemberIdParam,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const response = await this.agentService.translate(
                body?.message,
                'en',
                body.sourceLanguage
            );
            let sendMessageResult = await this._httpFactory
                .create('SenCustomerMsgToAgent')
                .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                .addBody({
                    body:
                        response.oriLanguageCode !== response.translateLanguageCode &&
                        response.originText !== response.translateText
                            ? `${SetPrefix(response.originText, response.translateText)}`
                            : body?.message?.trim(),
                    bodyType: 'standard | notice'
                })
                .method('POST')
                .send<WebChatMessageRes>(paras);

            let result: CustomerMsgToAgentRes = {
                oriMessage: body?.message?.trim(),
                translateMessage: response?.translateText,
                oriLanguage: response?.oriLanguageCode,
                targetLanguage: response?.translateLanguageCode,
                sendTime: body?.sendTime,
                sendSuccess: !!sendMessageResult.data?.id,
                msgId: '',
                pureCloudSendTime: ''
            };
            if (result.sendSuccess) {
                result.msgId = sendMessageResult.data?.id;
                result.pureCloudSendTime = sendMessageResult.data?.timestamp;
                // call db save data
                this.agentService.saveDataToDB(
                    paras.conversationId,
                    sendMessageResult.data.id,
                    paras.memberId,
                    response.originText,
                    response.translateText,
                    response.oriLanguageCode,
                    response.translateLanguageCode,
                    body.memberName,
                    body.sendTime
                );
            }
            res.send(this.baseService.buildSuccessMsg(result).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in sendCustomerMessageToAgent(send customer msg):${e};conversation ID:${JSON.stringify(
                        paras
                    )};body:${JSON.stringify(body)}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Post(':conversationId/messages')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async messages(
        @Req() req: FastifyRequest,
        @Query() query: AgentQueryToken,
        @Param() paras: ConversationIdParam,
        @Body() body: GuestCustomerMessageReqBody,
        @Res() res: FastifyReply<any>
    ) {
        let params = {
            ...paras,
            sortOrder: 'ascending',
            after: ''
        };
        if (body.msgId) {
            params.after = body.msgId;
        }
        let messages = new Array<WebChatMessageEntity>();
        let customerMessages = new Array<GuestCustomerMessageResponse>();
        let maxResultsCount = 100;
        try {
            let chatMsgRes = await this._httpFactory
                .create('GetWebChatMessages')
                .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                .method('GET')
                .send<ConversationMessagesResponse>(params);
            if (
                chatMsgRes.data &&
                chatMsgRes.data.entities &&
                chatMsgRes.data.entities.length > 0
            ) {
                messages = messages.concat(chatMsgRes.data.entities);
                if (chatMsgRes.data.entities.length >= maxResultsCount) {
                    while (true) {
                        let lastMessageId = chatMsgRes.data.entities.shift();
                        if (lastMessageId) {
                            params.after = lastMessageId?.id;
                        }
                        let response = await this._httpFactory
                            .create('GetWebChatMessages')
                            .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                            .method('GET')
                            .send<ConversationMessagesResponse>(params);
                        if (
                            response.data &&
                            response.data.entities &&
                            response.data.entities.length > 0
                        ) {
                            messages = messages.concat(response.data.entities);
                        } else {
                            break;
                        }
                    }
                }
            }
            messages = messages.filter((t) => !!t.body);
            if (messages.length > 0) {
                let senderIds: Array<string> = [];
                messages.forEach((m) => {
                    if (!!m.sender.id && senderIds.indexOf(m.sender.id) == -1) {
                        senderIds.push(m.sender.id);
                    }
                });
                let senderInfos = new Array<MemberEntity>();
                let res = await Promise.all(
                    senderIds.map((id) =>
                        this._httpFactory
                            .create('GetWebChatMember')
                            .addHeader('Authorization', `Bearer ${req?.query?.token}`)
                            .method('GET')
                            .send<MemberEntity>({
                                conversationId: paras.conversationId,
                                memberId: id
                            })
                    )
                );
                if (res != null && res.length > 0) {
                    res.forEach((r) => senderInfos.push(r.data));
                }
                messages.forEach((msg) => {
                    let resultMessage = new GuestCustomerMessageResponse();
                    resultMessage.conversationId = paras.conversationId;
                    resultMessage.messageId = msg.id;
                    let senderInfo = senderInfos.find(
                        (t) => !!msg.sender.id && t.id == msg.sender.id
                    );
                    resultMessage.senderName = senderInfo?.displayName ?? '';

                    resultMessage.role = senderInfo?.role ?? '';
                    resultMessage.avatarImageUrl = senderInfo?.avatarImageUrl ?? '';

                    resultMessage.sendMessage = msg.body;
                    resultMessage.sendTime = new Date(msg.timestamp).getTime();
                    resultMessage.senderID = msg.sender.id ?? '';
                    customerMessages.push(resultMessage);
                });
            }
            res.send(this.baseService.buildSuccessMsg(customerMessages).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in messages(get history msg):${e};conversation ID:${JSON.stringify(
                        paras
                    )};body:${JSON.stringify(body)}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Post('save/:conversationId/messageId')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async getAgentMessagesAndSave(
        @Req() req: FastifyRequest,
        @Param() paras: ConversationIdParam,
        @Res() res: FastifyReply<any>
    ) {
        try {
            let body = req.body as AgentSaveRequest;
            if (!body.agentMessage || !body?.msgID || !paras?.conversationId) {
                res.send(this.baseService.buildErrorMsg(null));
            }
            if (!body?.targetLanguage || body?.targetLanguage?.toLocaleLowerCase() == 'en') {
                res.send(
                    this.baseService.buildSuccessMsg({
                        oriLanguageCode: 'en',
                        originText: body?.agentMessage,
                        translateLanguageCode: 'en',
                        translateText: body?.agentMessage,
                        messageId: body?.msgID,
                        agentId: body?.agentId,
                        sendTime: body?.sendTime,
                        needTranslate: false
                    } as AgentSaveResponse).body
                );
            }
            const response = await this.agentService.translate(
                body?.agentMessage,
                body?.targetLanguage,
                'en'
            );

            this.agentService.saveDataToDB(
                paras?.conversationId,
                body?.msgID,
                body.agentId,
                response.originText,
                response.translateText,
                response.oriLanguageCode,
                response.translateLanguageCode,
                body.agentName ? body.agentName : 'AGENT',
                body.sendTime
            );

            let result = {
                messageId: body?.msgID,
                agentId: body?.agentId,
                sendTime: body?.sendTime,
                needTranslate:
                    response.oriLanguageCode !== response.translateLanguageCode &&
                    response.originText !== response.translateText,
                ...response
            } as AgentSaveResponse;
            res.send(this.baseService.buildSuccessMsg(result).body);
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in getAgentMessagesAndSave(save agent msg):${e};conversation ID:${JSON.stringify(
                        paras
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Get('getAttachmentFileLink')
    @UsePipes(new ValidationPipe(ParamAndQueryAndBodyErrorCodeMapping))
    async getAttachmentFileLink(
        @Req() req: FastifyRequest,
        @Query() params: AgentQueryAttachmentFile,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const response = TripleDES.decrypt(params?.message);
            const result = JSON.parse(response);

            res.send(
                this.baseService.buildSuccessMsg({
                    Success: true,
                    shortUrl: result.ShortUrl
                }).body
            );
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in getAttachmentFileLink(decrypt attachment link):${e};params:${JSON.stringify(
                        params
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }
}
