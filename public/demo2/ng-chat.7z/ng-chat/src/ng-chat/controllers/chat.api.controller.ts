import { FastifyRequest, FastifyReply } from 'fastify';
import { Controller, Get, Req, Res, UsePipes, Inject, Query } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';

import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';
import { TripleDES } from '../../common/utils';

import { BaseService } from '../services';

import { DecryptLogin, DecryptLoginQuery, UploadReqParams } from '../models';

@Controller('api/chat')
export class ChatApiController {
    constructor(
        protected readonly _httpFactory: NodeHttpFactory,
        private readonly baseService: BaseService,
        @Inject(REQUEST) readonly request: FastifyRequest
    ) {}

    @Get('decrypt/login')
    async getDecryptLogin(
        @Req() req: FastifyRequest,
        @Query() query: DecryptLoginQuery,
        @Res() res: FastifyReply<DecryptLogin>
    ) {
        try {
            let decryptLogin: DecryptLogin = {
                EmailAddress: TripleDES.decrypt(query.encryptedEmailAddress)
            };
            res.send(this.baseService.buildSuccessMsg(decryptLogin).body);
        } catch (error) {
            const responseInfo = this.baseService.buildErrorMsg(error);
            (req as any)
                .getLogger()
                .error(
                    `Error in getDecryptLogin(decrypt login info):${error};query:${JSON.stringify(
                        query
                    )}`
                );
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }

    @Get('uploadReqParams')
    async getUploadReqParams(
        @Req() req: FastifyRequest,
        @Query() params: any,
        @Res() res: FastifyReply<UploadReqParams>
    ) {
        try {
            const uploadClient: any = this._httpFactory?.create('UploadClient');
            if (uploadClient) {
                const client = uploadClient?.client;
                const parameters: any[] = client?.defaultParameters || [];
                const nvtc = parameters.find((p) => 'x-nvtc' === p.name);
                const contentType = parameters.find((p) => 'content-type' === p.name);
                const auth = parameters.find((p) => 'Authorization' === p.name);
                let result: UploadReqParams = {
                    nvtc: nvtc?.value || '',
                    authorization: auth?.value || '',
                    contentType: contentType?.value || '',
                    host: client?.baseUrl
                };
                res.send(this.baseService.buildSuccessMsg(result).body);
            }
        } catch (e) {
            (req as any)
                .getLogger()
                .error(
                    `Error in getUploadReqParams(get upload para):${e};params:${JSON.stringify(
                        params
                    )}`
                );
            const responseInfo = this.baseService.buildErrorMsg(e);
            res.status(responseInfo.httpCode);
            res.send(responseInfo.body);
        }
    }
}
