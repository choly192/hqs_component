import { Controller, Get, Req, Inject, UseInterceptors } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { FastifyRequest } from 'fastify';

import { ConfigurationManagement, TripleDES } from '../../common/utils';
import { Page } from '../../common/server/interceptors/decorators/page.decorator';
import { RenderHtmlInterceptor } from '../../common/server/interceptors/render.interceptor';
import { NgChatView } from '../views/NgChatView';
import { InitialState } from '../types/initialState.type';
import { ConfigurationManager, Query, ValidationPipe } from '@framework-frontend/node';
import { inAgentServiceTime } from '../services/cs.closechat.service';
import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';
import {
    convertBizChatLoginConfig,
    convertChatWindowCustomizedUI
} from '../../common/utils/convert-config.util';
import { NgChatQuery } from '../models';
import { ChatType } from '../types';
import { convertTopicAndReason } from '../utils';

@Controller()
@UseInterceptors(RenderHtmlInterceptor)
export class NgChatController {
    constructor(
        @Inject(REQUEST) readonly request: FastifyRequest,
        private readonly configMgr: ConfigurationManager,
        private readonly httpFactory: NodeHttpFactory
    ) {}

    @Get('/')
    @Page(NgChatView)
    async ngChat(
        @Req() req: FastifyRequest,
        @Query(new ValidationPipe({ transform: true })) query: NgChatQuery
    ) {
        const countryCode = query?.country?.toLocaleUpperCase() || 'USA';
        let overServiceTime = await inAgentServiceTime(
            query.category ?? '',
            query.type ?? ChatType.NormalChat,
            countryCode,
            this.httpFactory,
            this.configMgr,
            req
        );

        const bizChatLoginConfig = convertBizChatLoginConfig(
            ConfigurationManagement.BizChatLoginConfig,
            countryCode
        );

        const bizCustomizedUIConfig = convertChatWindowCustomizedUI(
            ConfigurationManagement.BizCustomizedUIConfig,
            countryCode
        );

        const emailAddress =
            TripleDES.decrypt(query?.encryptedEmailAddress ?? '') || query?.emailAddress;

        let initialState: InitialState = {
            Config: {
                BizChatLoginConfig: bizChatLoginConfig,
                BizCommonConfig: ConfigurationManagement.BizCommonConfig,
                BizCustomizedUIConfig: bizCustomizedUIConfig,
                BizChatBot: ConfigurationManagement.BizChatBot,
                BizChatAgent: ConfigurationManagement.BizChatAgent,
                SocketConfig: ConfigurationManagement.ApplicationWebsocketConfig,
                WebConfig: ConfigurationManagement.WebConfig,
                TopicAndReasonConfig: convertTopicAndReason(
                    bizChatLoginConfig.TopicAndReasonOptions,
                    bizChatLoginConfig.DefaultTopic,
                    bizChatLoginConfig.DefaultReason,
                    overServiceTime?.close,
                    bizChatLoginConfig.ChatBotEntrance.AllowAllTopicAndReason
                )
            },
            AdditionInfo: {
                ...query,
                emailAddress
            },
            IsClose: overServiceTime?.close,
            CloseMsg: overServiceTime?.message
        };

        return {
            initialState: initialState
        };
    }
}
