import { FastifyRequest, FastifyReply } from 'fastify';
import {
    Controller,
    Get,
    Req,
    Res,
    Param,
    Post,
    UsePipes,
    Inject,
    Body,
    Headers,
    Query
} from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { ValidationPipe } from '../validator/validationPipe';
import { NodeHttpFactory } from '../../common/server/http/implements/node-http-factory';
import {
    FeedbackCommentCardErrorCodeMapping,
    FeedbackCommentCardErrorCodeErrorCode,
    SubmitFeedbackCommentCardErrorCodeMapping,
    SubmitFeedbackCommentCardErrorCodeErrorCode
} from '../const/server/errorCode/feedback-error-code-map.const';
import { FeedbackService } from '../services/chatSurvey.service';
import { ValidationError } from '../validator/validationError';
import { setResponse } from '../../common/server/response/utils';
import {
    ChatSurveySubmitVal,
    PostFeedBackQuery
} from '../models/chatSurvey/chat-survey-Submit-request.model';
import { BaseService } from '../services';
import { TripleDES } from '../../common/utils';
export interface PrivateData {
    loginEmailAddress: string | null;
    isPremier: boolean | null;
    iPAddress: string;
    customerNumber: string;
}

@Controller('api/customer-feedback')
export class FeedbackApiController {
    constructor(
        protected readonly _httpFactory: NodeHttpFactory,
        private readonly feedbackService: FeedbackService,
        private readonly baseService: BaseService,
        @Inject(REQUEST) readonly request: FastifyRequest
    ) {}

    @Post('Submit')
    @UsePipes(new ValidationPipe(SubmitFeedbackCommentCardErrorCodeMapping))
    async submit(
        @Headers() headers: FastifyRequest,
        @Req() req: FastifyRequest,
        @Res() res: FastifyReply<any>,
        @Query() query: PostFeedBackQuery,
        @Body() SubmitDto: ChatSurveySubmitVal
    ) {
        try {
            let val: PrivateData = {
                loginEmailAddress: null,
                isPremier: null,
                iPAddress: headers.ip ?? '',
                customerNumber: ''
            };
            if (!!query.EncryptedCustomerNumber) {
                let IsPremier: boolean = false;
                let customerNumber: string =
                    TripleDES.decrypt(query.EncryptedCustomerNumber) ?? '0';
                // Premier Customer, ABANDON!
                // const getPremierStatus = CustomerLoginStorage(this.kookie)?.getPremierStatus();
                // !!getPremierStatus && getPremierStatus === 2
                //     ? (IsPremier = true)
                //     : (IsPremier = false);
                val = {
                    loginEmailAddress: SubmitDto?.logingEmailAddress ?? '',
                    isPremier: IsPremier,
                    iPAddress: headers.ip ?? '',
                    customerNumber: customerNumber
                };
            }
            const result = await this.feedbackService.PostFeedback(SubmitDto, val);
            res.send(this.baseService.buildSuccessMsg(result).body);
        } catch (error) {
            let code = SubmitFeedbackCommentCardErrorCodeErrorCode.SERVICE_ERROR;
            if (error instanceof ValidationError) {
                code = error.code as SubmitFeedbackCommentCardErrorCodeErrorCode;
            }
            const responesInfo = setResponse(
                code,
                SubmitFeedbackCommentCardErrorCodeMapping,
                null,
                error.message
            );
            (req as any)
                .getLogger()
                .error(
                    `Error in submit(submit feedback):${error};body:${JSON.stringify(SubmitDto)}`
                );
            res.status(responesInfo.httpCode);
            res.send(responesInfo.body);
        }
    }

    @Get('CommentCard/:conversationID')
    @UsePipes(new ValidationPipe(FeedbackCommentCardErrorCodeMapping))
    async commentCard(
        @Req() req: FastifyRequest,
        @Param('conversationID') conversationID: string,
        @Res() res: FastifyReply<any>
    ) {
        try {
            const result = await this.feedbackService.GetFeedbackData();
            // return res.send(JSON.stringify(respones?.data))
            res.send(this.baseService.buildSuccessMsg(result).body);
        } catch (error) {
            let code = FeedbackCommentCardErrorCodeErrorCode.SERVICE_ERROR;
            if (error instanceof ValidationError) {
                code = error.code as FeedbackCommentCardErrorCodeErrorCode;
            }
            const responesInfo = setResponse(
                code,
                FeedbackCommentCardErrorCodeMapping,
                null,
                error.message
            );
            (req as any).getLogger().error(`Error in commentCard(get feedback page):${error}`);
            res.status(responesInfo.httpCode);
            res.send(responesInfo.body);
        }
    }
}
