import { Method } from '@framework-frontend/core/dist/http2.0';

export interface RestApi {
  path: string;
  method: Method;
  internal: boolean;
  timeout?: number;
  service: string;
  requiresSignature?: boolean;
}

export interface ServiceHost {
  options?: {
    headers?: {
      [key: string]: string;
    };
  };
  serverList: Array<{ address: string; channel?: string }>;
}

export interface RestfulConfig {
  services: { [serviceName: string]: ServiceHost };
  apis: { [api: string]: RestApi };
}
