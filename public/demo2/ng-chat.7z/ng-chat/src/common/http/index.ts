export { IHttpClient } from './http-client.interface';
export { AbstractHttpFactory } from './implements/abstract-http-factory';
export { RestApi, ServiceHost } from './restful-config.interface';
