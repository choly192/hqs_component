import { Method } from '@framework-frontend/core/dist/http2.0';
import { AxiosResponse } from 'axios';

export interface IHttpClient {
  send<T = any>(query?: object): Promise<AxiosResponse<T>>;
  sendJSON(data: any, query?: any): Promise<AxiosResponse<any>>;
  addUrlSegment(name: string, value: string): IHttpClient;
  addHeader(name: string, value: string): IHttpClient;
  addBody(obj?: any): IHttpClient;
  getAsRaw?(): IHttpClient;
  modifyConfig?(conf: { [s: string]: any }): IHttpClient;
  method(method: Method): IHttpClient;
}
