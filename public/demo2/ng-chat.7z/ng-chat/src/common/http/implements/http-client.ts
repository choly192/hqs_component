import {
    IRestClient,
    IRestRequest,
    Method,
} from '@framework-frontend/core/dist/http2.0';
import { AxiosResponse } from 'axios';

import { IHttpClient } from '../http-client.interface';

export class HttpClient implements IHttpClient {
    protected readonly client: IRestClient;
    protected readonly request: IRestRequest;

    constructor(client: IRestClient, request: IRestRequest) {
        this.client = client;
        this.request = request;
    }

    public send<T>(query): Promise<AxiosResponse<T>> {
        if (!!query) {
            Object.entries(query).forEach(([name, value]) => {
                this.request.addQueryParameter(name, <string>value);
            });
        }

        return this.client.execute<T>(this.request);
    }

    public sendJSON<T>(data, query): Promise<AxiosResponse<T>> {
        if (!!query) {
            Object.entries(query).forEach(([name, value]) => {
                this.request.addQueryParameter(name, value as string);
            });
        }

        this.request.addJsonBody(data);

        return this.client.execute<T>(this.request);
    }

    addUrlSegment(name: string, value: string): IHttpClient {
        this.request.addUrlSegment(name, value);
        return this;
    }
    addHeader(name: string, value: string): IHttpClient {
        this.request.addHeader(name, value);
        return this;
    }
    addBody(obj?: any): IHttpClient {
        this.request.addBody(obj);
        return this;
    }
    method(method: Method): IHttpClient {
        this.request.method = method;
        return this;
    }
    public getAsRaw(): IHttpClient {
        this.request.raw = true;
        return this;
    }
    public modifyConfig(c) {
        this.request?.newConfigs?.push(c);
        return this;
    }
}
