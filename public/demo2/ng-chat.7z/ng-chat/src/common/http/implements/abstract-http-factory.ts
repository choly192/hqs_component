import { IRestClient, IRestRequest, } from '@framework-frontend/core/dist/http2.0';
import { IHttpClient } from '../http-client.interface';
import { HttpClient } from './http-client';


export abstract class AbstractHttpFactory {

  abstract createRestClient(name: string): IRestClient;

  abstract createRestRequest(name: string): IRestRequest;

  create(apiName: string): IHttpClient {

    return new HttpClient(
      this.createRestClient(apiName),
      this.createRestRequest(apiName),
    );

  }
}
