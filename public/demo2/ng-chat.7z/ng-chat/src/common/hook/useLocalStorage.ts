import { LocalStorageData, LocalStorageType } from '../storage';
import { LocalStorage } from '../storage/localStorage';

function useLocalStorage(original: boolean = false) {
    const { get: getLS, set: setLS, remove: removeLS } = LocalStorage(original);

    return {
        getValue: <K extends keyof LocalStorageData>(key: K): LocalStorageData[K] => getLS(key),
        setValue: <K extends keyof LocalStorageData>(key: K, value: LocalStorageData[K]) =>
            setLS(key, value as any),
        remove: (key: LocalStorageType) => removeLS(key),
    };
}

export { useLocalStorage };
