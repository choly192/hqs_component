import { useCallback, useEffect, useState } from 'react';
import { isFunction } from 'lodash';
import axios, { AxiosResponse } from 'axios';

import { Method } from '@framework-frontend/core/dist/http2.0';

import { AbstractHttpFactory, IHttpClient } from '../http';
import { BrowserHttpFactory } from '../client/http/implements/browser-http-factory';
import { InitialState } from '../../ng-chat/types';
import { useInitialState } from '../server/interceptors/context/GlobalContext';

type HandleMoreDataFunction<T> = (newData: T, oldData: T) => T;
type BodyParam = Function | Object;
type ApiParam = Function | string;
function useAjaxRequest<T = any>(
    loadData: boolean,
    options: {
        api: {
            withAxios?: boolean;
            factory?: AbstractHttpFactory;
            apiParam: ApiParam;
            buildQuery?: () => any;

            /**
             * api config, you can set some config to this api, such like timeout
             * default is {timeout:3000}
             */
            config?: { [s: string]: any };
            method?: Method;
            /**
             * init body param
             */
            body?: BodyParam;
        };
    },
) {
    const defaultRequestFactory = BrowserHttpFactory;

    const [loading, setLoading] = useState(loadData);

    const [data, setData] = useState<T>();

    const initialState = useInitialState<InitialState>();

    const onHandleLoadData = useCallback(
        async (
            apiParam?: ApiParam,
            body?: BodyParam,
            dynamicQuery?: object,
            handleMoreData?: HandleMoreDataFunction<T>,
        ): Promise<T> => {
            setLoading(true);

            let newData = data;
            try {
                const requestApiName = apiParam ?? options?.api?.apiParam;
                const requestBody = body ?? options?.api?.body;
                const reqAPI = isFunction(requestApiName) ? requestApiName() : requestApiName;
                const query = isFunction(options?.api?.buildQuery)
                    ? options?.api?.buildQuery()
                    : {};
                let ReqBody;
                if (requestBody) {
                    if (typeof requestBody == 'function') {
                        ReqBody = requestBody();
                    } else {
                        ReqBody = requestBody;
                    }
                }
                const config = options?.api?.config;

                let apiResponse: AxiosResponse<T>;

                if (options?.api?.withAxios) {
                    const instance = axios.create();
                    apiResponse = await instance.request({
                        method: options?.api?.method ?? 'GET',
                        url: reqAPI,
                        params: { ...query, ...dynamicQuery },
                        data: ReqBody,
                        timeout: options?.api?.config?.timeout ?? 3000,
                    });
                } else {
                    const requestFactory = options?.api?.factory ?? defaultRequestFactory;

                    const httpClient: IHttpClient = requestFactory
                        .create(reqAPI)
                        .addHeader('x-nvtc', initialState.AdditionInfo.nvtc)
                        .addHeader(
                            'x-customer-number',
                            initialState.AdditionInfo.encryptedCustomerNumber ?? '',
                        )
                        ?.method(options?.api?.method ?? 'GET');
                    ReqBody && httpClient?.addBody(ReqBody);

                    if (config) {
                        httpClient &&
                            httpClient?.modifyConfig &&
                            httpClient?.modifyConfig(options?.api?.config ?? { timeout: 3000 });
                    }

                    apiResponse = await httpClient?.send<T>({ ...query, ...dynamicQuery } ?? {});
                }

                if (!!apiResponse?.data) {
                    newData = isFunction(handleMoreData)
                        ? handleMoreData(apiResponse?.data, data as any) ?? data
                        : apiResponse?.data;
                }
            } catch (e) {
                newData = {
                    data: null,
                } as any;
            }

            setData(newData);
            setLoading(false);

            return newData as T;
        },
        [data],
    );

    const sendRequest = useCallback(
        (
            requestOption?: {
                /**
                 * dynamic api param,if set this,it will replace init api param
                 */
                apiParam?: ApiParam;
                /**
                 * dynamic body param,if set this,it will replace init body param
                 */
                body?: BodyParam;
                /**
                 * dynamic query param,if set this,it will be merged with the initial buildQuery param
                 */
                query?: object;
                /**
                 * you need handle data by your self? try this.
                 */
            },
            handleMoreData?: HandleMoreDataFunction<T>,
        ) => {
            // if (loading) {
            //     return;
            // }

            return onHandleLoadData(
                requestOption?.apiParam,
                requestOption?.body,
                requestOption?.query ?? {},
                handleMoreData,
            );
        },
        [data],
    );

    useEffect(() => {
        if (!loadData) {
            return;
        }

        onHandleLoadData();
    }, [loadData]);

    return {
        loading,
        data,
        sendRequest,
    };
}

export { useAjaxRequest };
