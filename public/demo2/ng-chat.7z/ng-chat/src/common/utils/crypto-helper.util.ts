import crypto from 'crypto';

export module TripleDES {
    const key = Buffer.from([97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120])
    const iv = Buffer.alloc(8)


    export function encrypt(input: string) {
        const cipher = crypto.createCipheriv('des-ede3-cbc', key, iv)
        try {
            return Buffer.concat([cipher.update(Buffer.from(input, 'utf16le')), cipher.final()]).toString('base64')
        } catch (e) {
            return input
        }
    }


    export function decrypt(input: string) {
        const cipher = crypto.createDecipheriv('des-ede3-cbc', key, iv)
        try {
            return Buffer.concat([cipher.update(Buffer.from(input, 'base64')), cipher.final()]).toString('utf16le')
        } catch (e) {
            return input
        }
    }
}

