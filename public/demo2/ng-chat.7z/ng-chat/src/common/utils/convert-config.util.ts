import {
    BizChatLogin,
    BizCustomizedUI,
    BizCustomizedUIDetail,
    CategoryAndQueueInfo,
    ChatBotEntrance,
    Country,
    SpecialChatSkill,
    TopicAndReasonOption,
} from '../types';
import { ApplicationWebsocket, ChatBotConnection } from '../types/application-websocket';

export interface BizChatLoginByCountry {
    CategoryOptions: Array<string>;
    CategoryAndQueueMapping: Array<CategoryAndQueueInfo>;
    ChatBotEntrance: ChatBotEntrance;
    TopicAndReasonOptions: Array<TopicAndReasonOption>;
    SpecialChatSkills: Array<SpecialChatSkill>;
    EmailValidRegex: string;
    DefaultTopic: string;
    DefaultReason: string;
    DefaultCategory: string;
    EnableTranscript: boolean;
}

export interface BizCustomizedUIByCountry {
    ChatWindow: BizCustomizedUIDetailByCountry;
}

interface BizCustomizedUIDetailByCountry {
    Title?: {
        Main?: string;
        Sub?: string;
    };
    Disclaimer?: string;
}

const commonConfig = 'Common';

export const getBu = (country: Country): 'USA' | 'CAN' | 'USB' => {
    switch (country.toLocaleUpperCase()) {
        case 'USB':
            return 'USB';
        case 'CAN':
            return 'CAN';
        default:
            return 'USA';
    }
};

export const convertBizChatLoginConfig = (
    BizChatLogin: BizChatLogin,
    country: Country,
): BizChatLoginByCountry => {
    let bu = getBu(country);
    let config: BizChatLoginByCountry = {
        CategoryOptions: [
            ...(BizChatLogin.CategoryOptions[bu] ?? []),
            ...BizChatLogin.CategoryOptions[commonConfig],
        ],
        CategoryAndQueueMapping: [
            ...(BizChatLogin.CategoryAndQueueMapping[bu] ?? []),
            ...BizChatLogin.CategoryAndQueueMapping[commonConfig],
        ],
        ChatBotEntrance: BizChatLogin.ChatBotEntrance,
        TopicAndReasonOptions: [
            ...(BizChatLogin.TopicAndReasonOptions[bu] ?? []),
            ...BizChatLogin.TopicAndReasonOptions[commonConfig],
        ],
        SpecialChatSkills: BizChatLogin.SpecialChatSkills,
        EmailValidRegex: BizChatLogin.EmailValidRegex,
        DefaultTopic: BizChatLogin.DefaultTopic,
        DefaultReason: BizChatLogin.DefaultReason,
        DefaultCategory: BizChatLogin.DefaultCategory,
        EnableTranscript: BizChatLogin.EnableTranscript,
    };
    config.CategoryOptions.unshift(config.DefaultCategory);
    return config;
};

export const convertChatWindowCustomizedUI = (
    bizCustomizedUI: BizCustomizedUI,
    country: Country,
): BizCustomizedUIByCountry => {
    let config: BizCustomizedUIByCountry = {
        ChatWindow: {
            ...bizCustomizedUI.ChatWindow.find((t) => t.Countries == 'Default')?.Value,
            ...bizCustomizedUI.ChatWindow.find((t) => t.Countries == country)?.Value,
        },
    };
    return config;
};
