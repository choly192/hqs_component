import {
    BizChatAgent,
    BizChatBot,
    BizChatLogin,
    BizCommon,
    BizCustomizedUI,
    WebConfig
} from '../types';
import { ApplicationWebsocket } from '../types/application-websocket';
import { BizChatSurvey } from '../types/biz-chatSurvey';

declare let global: any;
declare let window: any;
declare let __WebPlatform__: { OS: string };

class ConfigurationManage {
    public get BizChatLoginConfig(): BizChatLogin {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig || {};
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Biz.ChatLogin') || {};
        }
    }

    public get BizCommonConfig(): BizCommon {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig || {};
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Biz.Common') || {};
        }
    }

    public get BizCustomizedUIConfig(): BizCustomizedUI {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig || {};
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Biz.CustomizedUI') || {};
        }
    }

    public get ApplicationWebsocketConfig(): ApplicationWebsocket {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig || {};
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Application.Websocket') || {};
        }
    }
    public get BizChatSurvey(): BizChatSurvey {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig||{}
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Biz.ChatSurvey') || {};
        }
    }

    public get BizChatBot(): BizChatBot {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig||{}
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Biz.ChatBot') || {};
        }
    }

    public get BizChatAgent(): BizChatAgent {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig||{}
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('Biz.ChatAgent') || {};
        }
    }

    public get WebConfig(): WebConfig {
        if (typeof __WebPlatform__ !== 'undefined' && __WebPlatform__.OS === 'browser') {
            // return window?.__SITE__?.productConfig||{}
            return {} as any;
        } else {
            let configService = require('@framework-frontend/node').ConfigService;
            return configService.getConfiguration('WebConfig') || {};
        }
    }
}

export const ConfigurationManagement = new ConfigurationManage();
