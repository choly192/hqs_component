import { ConfigurationManager, RemoteConfigStatusFlags } from '@framework-frontend/node';
import { Controller, Get, Req, Res, Inject, HttpStatus } from '@nestjs/common';

@Controller()
export class FaqController {
    @Inject()
    private configMgr: ConfigurationManager;

    private remoteConfigsReady(logger) {
        if (!this.configMgr.getConfiguration('WebConfig').HealthCheck?.CheckRemoteConfigs)
            return true;

        let ready = true;

        const status = this.configMgr.remoteConfigStatus;

        if (
            (status.status & RemoteConfigStatusFlags.CONFIGS_MISSING) ===
            RemoteConfigStatusFlags.CONFIGS_MISSING
        ) {
            logger.warn(
                `faq: not ready because the following configs are missing:\n` +
                    status?.missingConfigs?.join('\n'),
            );
            ready = false;
        }

        if (
            (status.status & RemoteConfigStatusFlags.NOT_CONNECTED) ===
            RemoteConfigStatusFlags.NOT_CONNECTED
        ) {
            // 如果只是配置中心没连上，那我们记一条警告，faq仍然返回正常，
            // 保证站点的可用，避免暂时的网络波动导致我们站点被下线。
            logger.warn('faq: config center not connected');
        }

        return ready;
    }

    @Get('/faq')
    faq(@Req() req, @Res() res) {
        const healthy = this.remoteConfigsReady(req.getLogger());

        res.status(healthy ? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE).send(
            healthy ? 'true' : 'false',
        );
    }
}
