import qs from "qs";
import { pipe } from "lodash/fp";

let array2String = (x: any): string => {
  if (typeof x === "string") {
    return x;
  } else {
    if (Array.isArray(x)) {
      return x[0];
    } else if (typeof x == 'object' && x) {
      return "";
    }
    else {
      console.warn(
        `You want a non string query value [type]: ${typeof x}? Modify src/common/server/bootstrap/utils.ts to fit you needs.`
      )
      return x;
    }
  }
};

let filterQuery = (x: { [s: string]: any } = {}) => {
  let tmp = {};
  for (let key of Object.keys(x)) {
    tmp[key] = array2String(x[key]);
  }
  return tmp;
};

export let queryParser = pipe(qs.parse, filterQuery);
