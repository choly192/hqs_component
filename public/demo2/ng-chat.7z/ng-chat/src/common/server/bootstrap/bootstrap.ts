import crypto from 'crypto';
import { join } from 'path';
import fastify from 'fastify';
import { NestFastifyApplication } from '@nestjs/platform-fastify';
import { FastifyAdapter } from '@nestjs/platform-fastify';
import { NegLogger, NestFactory } from '@framework-frontend/node';
import ConfigurationEvents, {
    CONFIG_VALUE_CHANGE
} from '@framework-frontend/node/dist/configuration-center/configuration-events';
import { ConfigService } from '@framework-frontend/node';

import { MetricsPlugin } from '../plugins/metrics/metrics-plugin';
import { IBootstrapOptions } from './bootstrap-options.interface';
import { queryParser } from './utils';
import { LoggerPlugin } from '../plugins/log/logger-plugin';
import { QueryStringPlugin } from '../plugins/queryStr/query-string-plugin';
import XMLAdapters from './xml-adapters';
import { NotFoundExceptionFilter } from '../filter';

export async function bootstrap(rootModule: any, options?: IBootstrapOptions) {
    ConfigService.rootPath = join(options?.rootDir || __dirname, './conf');
    ConfigService.XMLAdapters = XMLAdapters;

    if (process.env.NODE_ENV === 'production') {
        ConfigurationEvents.getInstance().on(CONFIG_VALUE_CHANGE, configWatcher());
    }

    let fastifyInstance = fastify({
        ignoreTrailingSlash: true,
        caseSensitive: false,
        querystringParser: queryParser
    });
    fastifyInstance.register(MetricsPlugin, { endpoint: '/metrics' });
    fastifyInstance.addHook('onSend', (request, reply, payload, done) => {
        const serverId = ConfigService.get('serverId');
        serverId && reply.header('x-server-id', serverId);
        done(undefined, payload);
    });

    if (process.env.NODE_KEEP_ALIVE_TIMEOUT) {
        fastifyInstance.server.keepAliveTimeout =
            Number.parseInt(process.env.NODE_KEEP_ALIVE_TIMEOUT) ?? 5e3;
    }
    fastifyInstance.register(LoggerPlugin);
    fastifyInstance.register(QueryStringPlugin);

    const app = await NestFactory.create<NestFastifyApplication>(
        rootModule,
        new FastifyAdapter(fastifyInstance)
    );
    app.useGlobalFilters(new NotFoundExceptionFilter());
    app.useStaticAssets({ root: join(ConfigService.rootPath, '..') });

    const port = ConfigService.getConfiguration('WebConfig')?.PORT || 8220;
    await app.listen(port, '0.0.0.0', (err, address) => {
        if (err) {
            console.error(err.message);
            process.exit(1);
        } else {
            console.log(`Server start at ${address}`);
        }
    });
}

const configWatcher = () => {
    let logConfLoaded = false;
    const buf: { name: string; value: any }[] = [];

    const log = (entry: typeof buf[number]) =>
        NegLogger.getDefaultLogger().info(
            `zookeeper config updated, config name: ${entry.name}, hash: ${crypto
                .createHash('sha1')
                .update(JSON.stringify(entry.value))
                .digest('hex')}`
        );

    return (name, value) => {
        // 是这样的，logger需要配置transport，不然它不知道往哪里写，而我们的log配置又在zookeeper，这里我们又是监听zookeeper的配置，
        // 然后记log，在第一次连zookeeper时，我们还没有拿到log的配置，但是我们又要记log :) 所以这里我们先把要记的东西缓存下来，当log的配置读到了再去写log。

        if (name === 'Application.Log') {
            logConfLoaded = true;
        }

        buf.push({ name, value });

        if (logConfLoaded) {
            while (buf.length > 0) log(buf?.shift() as any);
        }
    };
};
