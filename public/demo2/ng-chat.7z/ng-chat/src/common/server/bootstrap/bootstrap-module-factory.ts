import { ConfigurationManager, ConfigModule, MiddlewareConsumer } from '@framework-frontend/node';
import { DynamicModule, Global, Module, OnModuleInit, Type } from '@nestjs/common';
import { castArray } from 'lodash';

import { CustomerIPMiddleware, HeaderMiddleware } from '../../../common/server/middleware';

import { FaqController } from '../controllers/faq.controller';

export class BootstrapModuleFactory {
    public static create(_module: Type<any> | Array<Type<any>>): DynamicModule {
        return {
            module: BootstrapModule,
            imports: [ConfigModule.load('./**/!(*.d).json') as any, ...castArray(_module)],
        };
    }
}

@Global()
@Module({
    providers: [ConfigurationManager],
    controllers: [FaqController],
    exports: [ConfigurationManager],
})
class BootstrapModule implements OnModuleInit {
    onModuleInit() {}
    configure(consumer: MiddlewareConsumer) {
        consumer.apply(CustomerIPMiddleware, HeaderMiddleware).forRoutes('*');
    }
}
