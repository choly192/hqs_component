const XMLAdapters = new Map();

export default XMLAdapters;
