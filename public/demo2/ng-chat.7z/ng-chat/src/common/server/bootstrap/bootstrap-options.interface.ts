import { ExceptionFilter } from "@nestjs/common";

export interface IBootstrapOptions {
    rootDir?: string;
    globalFilters?: ExceptionFilter[];
}