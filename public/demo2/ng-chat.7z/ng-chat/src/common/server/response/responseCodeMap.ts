import { HttpStatus } from '@framework-frontend/node';

export interface ResponseCodeMap<T> {
    ErrorCode: T;
    Message: string;
    Status: HttpStatus;
}
