import { HttpStatus } from '@framework-frontend/node';

import { Model } from './model';
import { ResponseCodeMap } from './responseCodeMap';

function setResponse<T extends Object, K>(
    errorCode: K,
    codeMaps: ResponseCodeMap<K>[],
    data: T | null,
    customMessage?: string,
): Model<T, K> {
    const codeMap = getResponseCodeMap<K>(codeMaps, errorCode);
    return {
        httpCode: codeMap?.Status || HttpStatus.OK,
        body: {
            data: data,
            errorCode: (codeMap?.ErrorCode || '1000000') as K,
            errorMessage: customMessage || codeMap?.Message || '',
        },
    };
}

function getResponseCodeMap<T>(
    codeMaps: ResponseCodeMap<T>[],
    errorCode: T,
): ResponseCodeMap<T> | null {
    return codeMaps?.find((c) => c.ErrorCode === errorCode) || null;
}

export { setResponse };
