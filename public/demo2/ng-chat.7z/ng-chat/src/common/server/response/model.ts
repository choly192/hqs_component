import { HttpStatus } from '@framework-frontend/node';
import { ResponseBody } from '../../client/response/model';

export interface Model<T extends Object, K> {
    body: ResponseBody<T, K>;
    httpCode: HttpStatus;
}
