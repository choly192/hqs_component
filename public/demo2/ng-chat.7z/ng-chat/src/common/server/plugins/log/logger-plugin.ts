import fp from 'fastify-plugin';
import { join } from 'path';

import {
    ConfigService,
    NegLogger,
    ConfigurationEvents,
    LoggerOption,
    Transport,
    TransportType,
} from '@framework-frontend/node';

const LOG_LEVEL = new Set(['trace', 'debug', 'info', 'warn', 'error', 'fatal']);

enum LoggerCategory {
    USA = 'USA',
    CAN = 'CAN',
    USB = 'USB',
}

type LoggerConfig = {
    transports: LoggerOption;
};

const transportMap = (category: LoggerCategory) => (opt: Transport) => {
    switch (opt.type) {
        case TransportType.File:
            return <Transport>Object.assign({}, opt, {
                filename: join('log', category, (<any>opt).filename),
            });
        default:
            return opt;
    }
};

const createAndUpdateLoggers = (e: LoggerOption) => {
    NegLogger.getInstance().updateLogger(
        LoggerCategory.USA,
        e?.map(transportMap(LoggerCategory.USA)),
    );
    NegLogger.getInstance().updateLogger(
        LoggerCategory.CAN,
        e?.map(transportMap(LoggerCategory.CAN)),
    );
};

export const LoggerPlugin = fp((fastify, opt, done) => {
    const loggerCfg: LoggerConfig = ConfigService.getConfiguration('Application.Log');

    // remote configs are loaded asynchronously, so loggerCfg might be undefiend at this point
    if (loggerCfg) createAndUpdateLoggers(loggerCfg.transports);

    ConfigurationEvents.on<LoggerConfig>('Application.Log', (loggerCfg) => {
        createAndUpdateLoggers(loggerCfg.transports);
    });

    const promClient = (fastify as any).metrics.client;

    let prmoLogCounter = new promClient.Counter({
        name: 'log_count_trace',
        help: 'Number of log count',
        labelNames: ['level', 'country'],
    });

    fastify.decorateRequest('getLogger', function () {
        // todo
        // let isCAN = isCANRequest(this.hostname, ConfigService as any);

        // let logType = String(isCAN ? LoggerCategory.CAN : LoggerCategory.USA);
        // if (isDev) {
        //   logType = "default";
        // }
        let logType = String(LoggerCategory.USA);
        let logInstance = NegLogger.getInstance().getLogger(logType);
        let sid = '',
            tid = '';

        this.headers['x-gateway-tid'] && (tid = this.headers['x-gateway-tid']);
        this.headers['x-gateway-sid'] && (sid = this.headers['x-gateway-sid']);

        let requestLogger = logInstance.child({
            tid,
            sid,
        });

        return new Proxy(requestLogger, {
            get: (target, propertyName) => {
                if (LOG_LEVEL.has(<string>propertyName)) {
                    prmoLogCounter.inc({
                        level: propertyName,
                        country: logType,
                    });
                }
                return (...message) => {
                    let msg = JSON.stringify(message.join(''));
                    target[propertyName](msg?.slice(1, msg.length - 1));
                };
            },
        });
    });

    done();
});
