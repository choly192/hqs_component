import fp from "fastify-plugin";
import promClient from "prom-client";
import {
  FastifyMetrics,
  MetricConfig,
  PluginOptions,
} from "./metrics-plugin.types";
import {
  FastifyReply,
  FastifyInstance,
} from "fastify";

const rNeweggEnv = /^neg_.+/i;

const envLabels = Object.entries(process.env).filter(([k, v]) =>
  rNeweggEnv.test(k)
);

const metricsPlugin = async (
  fastify: FastifyInstance,
  {
    enableDefaultMetrics = true,
    enableRouteMetrics = true,
    groupStatusCodes = false,
    pluginName = "metrics",
    blacklist,
    register,
    prefix,
    endpoint,
    neweggEnvironments = true,
    metrics = {},
  }: PluginOptions = {}
) => {
  const plugin: FastifyMetrics = {
    client: promClient,
    clearRegister: function () {},
  };
  const defaultOptions: promClient.DefaultMetricsCollectorConfiguration = {};

  if (register) {
    plugin.clearRegister = () => {
      register.clear();
    };
  }

  if (prefix) {
    defaultOptions.prefix = prefix;
  }

  if (enableDefaultMetrics) {
    promClient.collectDefaultMetrics(defaultOptions);
  }

  if (enableRouteMetrics) {
    const collectMetricsForUrl = (url: string) => {
      const queryIndex = url.indexOf("?");
      url = queryIndex === -1 ? url : url.substring(0, queryIndex);
      if (!blacklist) {
        return true;
      }
      if (Array.isArray(blacklist)) {
        return !blacklist.includes(url);
      }
      if (typeof blacklist === "string") {
        return blacklist !== url;
      }
      if (typeof blacklist.test === "function") {
        return !blacklist.test(url);
      }
      return false;
    };

    const opts: MetricConfig = {
      histogram: {
        name: "http_request_duration_seconds",
        help: "request duration in seconds",
        labelNames: ["status_code", "method", "route"],
        buckets: [0.05, 0.1, 0.5, 1, 3, 5, 10],
        ...metrics.histogram,
      },
      summary: {
        name: "http_request_summary_seconds",
        help: "request duration in seconds summary",
        labelNames: ["status_code", "method", "route"],
        percentiles: [0.5, 0.9, 0.95, 0.99],
        ...metrics.summary,
      },
    };

    if (register) {
      opts.histogram.registers = [register];
      opts.summary.registers = [register];
    }

    if (prefix) {
      opts.histogram.name = `${prefix}${opts.histogram.name}`;
      opts.summary.name = `${prefix}${opts.summary.name}`;
    }

    const routeHist = new promClient.Histogram(opts.histogram);
    const routeSum = new promClient.Summary(opts.summary);

    fastify.addHook("onRequest", (request, _, next) => {
      if (request.raw.url && collectMetricsForUrl(request.raw.url)) {
        (request as any).metrics = {
          hist: routeHist.startTimer(),
          sum: routeSum.startTimer(),
        };
      }
      next();
    });

    fastify.addHook("onResponse", (request, reply, next) => {
      if ((request as any).metrics) {
        const context = reply.context;
        let routeId = context.config.url || "/NotFound";
        if (context.config.statsId) {
          routeId = context.config.statsId;
        }
        const method = request.raw.method;
        const statusCode = groupStatusCodes
          ? `${Math.floor(reply.res.statusCode / 100)}xx`
          : reply.res.statusCode;

        (request as any).metrics.sum({
          method: method || "UNKNOWN",
          route: routeId,
          status_code: statusCode,
        });
        (request as any).metrics.hist({
          method: method || "UNKNOWN",
          route: routeId,
          status_code: statusCode,
        });
      }
      next();
    });
  }

  if (endpoint) {
    fastify.route({
      url: endpoint,
      method: "GET",
      // schema: {
      //   hide: true,
      // },
      handler: async (_, reply) => {
        const data = register
          ? await register.metrics()
          : await promClient.register.metrics();

        void reply.type("text/plain").send(data);
      },
    });
  }

  if (neweggEnvironments) {
    let envGuage = new promClient.Gauge({
      name: `neg_env`,
      help: `newegg_environments during CD`,
      labelNames: envLabels.map(([k, v]) => k),
    });

    envGuage.inc(envLabels.reduce((rcc, [k, v]) => ({ ...rcc, [k]: v }), {}));
  }

  fastify.decorate(pluginName, plugin);
};

export const MetricsPlugin = fp(metricsPlugin, {
  fastify: ">=2.0.0",
  name: "fastify-metrics",
});
