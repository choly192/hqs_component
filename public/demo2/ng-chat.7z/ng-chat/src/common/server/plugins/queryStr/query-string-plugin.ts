import fp from 'fastify-plugin';

const QueryStringPlugin = fp((fastify, opt, done) => {
    fastify.addHook('preHandler', (request, reply, hookDone) => {
        let _query = Object.entries(request.query).reduce((rcc, [key, value]) => {
            rcc[key.toLowerCase()] = value;
            return rcc;
        }, {});

        request.query = new Proxy(request.query, {
            get: (queryString, key, receiver) => {
                if (typeof key === 'string') return _query[(<string>key).toLowerCase()];
                // key可能不是string，比如是Symbol(Symbol.toStringTag)
                else return _query[key];
            },
            set: (obj, prop: string, value) => {
                Object.keys(obj)?.forEach((key, index) => {
                    if (key.toLowerCase() == prop.toLowerCase()) {
                        obj[key] = value;
                        _query[key.toLowerCase()] = value;
                    }
                });
                return true;
            },
        });

        hookDone();
    });

    done();
});

export { QueryStringPlugin };
