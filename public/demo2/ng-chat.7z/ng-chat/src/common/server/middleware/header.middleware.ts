import { Injectable, NestMiddleware } from '@nestjs/common';
import { FastifyRequest, FastifyReply } from 'fastify';

import { TripleDES } from '../../utils';
@Injectable()
export class HeaderMiddleware implements NestMiddleware {
    use(req: FastifyRequest, res: Response, next: Function) {
        if (req.headers['x-customer-number']) {
            req.headers['x-customer-number'] = TripleDES.decrypt(req.headers['x-customer-number']);
        }
        next();
    }
}
