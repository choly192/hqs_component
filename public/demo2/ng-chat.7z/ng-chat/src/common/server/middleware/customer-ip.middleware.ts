import { Injectable, NestMiddleware } from '@nestjs/common';
import { FastifyRequest, FastifyReply } from 'fastify';

@Injectable()
export class CustomerIPMiddleware implements NestMiddleware {
    use(req: FastifyRequest, res: Response, next: Function) {
        if (req.headers[Constants.TrueClientIPKey]) {
            req.headers['ip'] = (req.headers[Constants.TrueClientIPKey] as string).split(',')[0];
        } else if (req.headers[Constants.CustomerIP2Key]) {
            req.headers['ip'] = (req.headers[Constants.CustomerIP2Key] as string).split(',')[0];
        } else if (req.headers[Constants.CustomerIPKey]) {
            req.headers['ip'] = (req.headers[Constants.CustomerIPKey] as string).split(',')[0];
        } else if (req.headers[Constants.REMOTEADDRKey]) {
            req.headers['ip'] = req.headers[Constants.REMOTEADDRKey];
        } else {
            req.headers['ip'] = req.ip;
        }
        next();
    }
}

const Constants = {
    TrueClientIPKey: 'true-client-ip',
    CustomerIP2Key: 'x-source-ip2',
    CustomerIPKey: 'x-source-ip',
    REMOTEADDRKey: 'REMOTE_ADDR',
};
