import { Injectable, Inject, Scope } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { FastifyRequest } from 'fastify';
import { ConfigurationManager } from '@framework-frontend/node';
import {
    RestClient,
    IRestClient,
    RestRequest,
    IRestRequest,
    Parameter,
    ParameterType,
} from '@framework-frontend/core/dist/http2.0';

import { AbstractHttpFactory, RestApi, ServiceHost, IHttpClient } from '../../../../common/http';
import { Parameters } from '../../../const/parameters.const';

const IGNORE_REQUEST_HEADERS = new Set([
    'host',
    'cookie',
    'sec-fetch-dest',
    'sec-fetch-mode',
    'sec-fetch-site',
    'accept',
    'content-type',
    'content-length',
]);

const headerFilter = ([name, value]) => !IGNORE_REQUEST_HEADERS.has(name.toLowerCase());
const HEADER_MAPPING = { referer: 'x-client-referrer' };

let LoadBalance = () => {
    let balanceMap = new Map<string, number>();
    return (apiName: string, total: number) => {
        if (total < 1) {
            return 0;
        }

        let nextValue = balanceMap.get(apiName) ?? 0;
        balanceMap.set(apiName, (nextValue + 1) % total);
        return nextValue;
    };
};
let getLoadBalance = LoadBalance();

@Injectable({ scope: Scope.REQUEST })
export class NodeHttpFactory extends AbstractHttpFactory {

    constructor(
        @Inject(REQUEST) readonly request: FastifyRequest,
        readonly configurationManager: ConfigurationManager,
    ) {
        super();
    }

    public createRestClient(apiName: string): IRestClient {
        const host = this.getHost(apiName);
        const client = new RestClient(
            host?.serverList?.[getLoadBalance(apiName, host?.serverList?.length)]?.address,
        );

        Object.entries(this.request?.headers)
            ?.filter(headerFilter)
            ?.forEach(([k, v]) => {
                client.addDefaultParameter(
                    new Parameter(HEADER_MAPPING[k] ?? k, v, ParameterType.HttpHeader),
                );
            });

        if (!!host?.options?.headers) {
            Object.entries(host.options.headers).forEach(([headerName, value]) => {
                client.addDefaultParameter(
                    new Parameter(headerName, value, ParameterType.HttpHeader),
                );
            });
        }

        // client.addDefaultQueryString(
        //     Parameters.COUNTRY_CODE,
        //     CountryStorage(this.kookie).getCountryCode(),
        // );
        // client.addDefaultQueryString(
        //     Parameters.REGION_CODE,
        //     CountryStorage(this.kookie).getCountryCode(),
        // );
        client.addDefaultQueryString(Parameters.COMPANY_CODE, 1003);
        client.addDefaultQueryString(Parameters.LANGUAGE_CODE, 'en-US');

        this.addHeader(client);
        return client;
    }

    public addHeader(client: RestClient) {
        // let NVTCkookie = NVTCStorage(this.kookie);
        // let customerKookie = CustomerLoginStorage(this.kookie);
        // let loginStatus = customerKookie.getPremierStatus();
        // let customerNumber = customerKookie.getCustomerNumber();
        // let nvtc = NVTCkookie.getNVTC();

        // const sdValue = this.kookie.getSubCookie(cookieConfig.CookieMapping.OtherInfo.key, 'sd');
        // const xLoginToken = this.kookie.getCookie(cookieConfig.CookieMapping.NVToken.key);

        // nvtc &&
        //     client.addDefaultParameter(
        //         new Parameter('x-nvtc', NVTCkookie.getNVTC(), ParameterType.HttpHeader),
        //     );
        // typeof loginStatus !== 'undefined' &&
        //     client.addDefaultParameter(
        //         new Parameter('x-login-status', loginStatus, ParameterType.HttpHeader),
        //     );
        // customerNumber &&
        //     client.addDefaultParameter(
        //         new Parameter('x-customer-number', customerNumber, ParameterType.HttpHeader),
        //     );

        // sdValue &&
        //     xLoginToken &&
        //     this.addDefaultParameterSafety(
        //         client,
        //         new Parameter('x-logintoken', xLoginToken, ParameterType.HttpHeader),
        //     );
    }

    public createRestRequest(apiName: string): IRestRequest {
        const api = this.getRestApi(apiName);
        const request = new RestRequest(api.path);
        request.method = api.method;
        if (api.timeout) {
            request.timeout = api.timeout;
        } else {
            const defaultTimeout =
                this.configurationManager.getConfiguration<{ [name: string]: RestApi }>(
                    'Application.UI',
                )?.DefaultHttpRequestTimeout ?? 4000;
            // default API timeout is 4s
            request.timeout = Number(defaultTimeout);
        }
        return request;
    }

    protected getRestApi(apiName: string): RestApi {
        const restfulConfig = this.configurationManager.getConfiguration<{
            [name: string]: RestApi;
        }>('Service.RestfulAPI');
        const api = restfulConfig?.[apiName];
        if (!api) {
            throw new Error(
                `Could not find [${apiName}] in Service.RestfulAPI.json, please check your configuration again!`,
            );
        }

        return api;
    }

    protected getHost(apiName: string): ServiceHost {
        const hostConfig = this.configurationManager.getConfiguration<{
            [name: string]: ServiceHost;
        }>('Service.ServerList');
        const serviceName = this.getRestApi(apiName)?.service;
        const host = hostConfig?.[serviceName];
        if (!host) {
            throw new Error(
                `Could not find [${serviceName}] in Service.ServerList.json, which is the service of [${apiName}] in restful-config, please check your configuration again!`,
            );
        }

        return host;
    }

    create(apiName: string): IHttpClient {
        const client = super.create(apiName);

        let originalSend = client.send;

        let req = this.request;

        client.send = function (...args) {
            let result = originalSend.call(client, ...args);
            return result.then((r) => {
                try {
                    let debugInfo = (r as any).__DEBUG_INFO__;
                    if (debugInfo) {
                        if (!(req as any).__DEBUG_INFO__) {
                            (req as any).__DEBUG_INFO__ = [];
                        }
                        (req as any).__DEBUG_INFO__.push(debugInfo);
                    }
                } catch (e) {
                    console.log(e);
                }
                return r;
            });
        };
        return client;
    }

    private addDefaultParameterSafety(client: RestClient, parameter: Parameter) {
        const idx = client.defaultParameters.findIndex(
            (x) => x.name.toUpperCase() === parameter.name.toUpperCase(),
        );
        if (idx <= -1) {
            client.addDefaultParameter(parameter);
        }
    }
}
