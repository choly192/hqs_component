import { Catch, NotFoundException, ExceptionFilter, ArgumentsHost } from '@nestjs/common';

const NotFoundHtml = `<h1><span>Oops!</span>We couldn&#180;t find the page</h1>`;

@Catch()
export class NotFoundExceptionFilter implements ExceptionFilter {
    catch(exception: NotFoundException, host: ArgumentsHost) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse();
        response.header('content-type', 'text/html').send(NotFoundHtml);
    }
}
