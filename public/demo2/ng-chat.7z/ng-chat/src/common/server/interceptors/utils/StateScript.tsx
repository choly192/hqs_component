
import React, { FC } from 'react';
import serialize from 'serialize-javascript';


type ScriptProps = {
    name: string;
    data: any;
};

const StateScript: FC<ScriptProps> = ({ name, data }) => {
    return (
        <script
            defer
            dangerouslySetInnerHTML={{
                __html: `window.${name} = ${serialize(data, {
                    isJSON: true,
                })}`,
            }}
        />
    );
};


export { ScriptProps, StateScript }