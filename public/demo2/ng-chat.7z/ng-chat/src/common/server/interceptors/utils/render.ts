import { ComponentType } from 'react';
import { Observable, switchMap } from 'rxjs';
import _ from 'lodash';

import { ControllerResult, Options, ReactString } from '../types/render';
import { skipNull } from './operator';
import { addAssetsManifest } from '../renderHtml/assetsManifest/assetsManifest';
import { addInjectingScript } from '../renderHtml/injecting-script/add-injecting-script';
import { renderT0String } from './render.string';
import { addHtmlHeader } from '../htmlHeader/html-header';

export let render = (controllerResult: Observable<ControllerResult>, options: Options) => (
    element: ComponentType,
): Observable<Buffer> =>
    controllerResult.pipe(
        skipNull(addAssetsManifest(options)),
        skipNull(addInjectingScript(options)),
        skipNull(addHtmlHeader(options)),
        skipNull(reactString(options)(element)),
        switchMap((_) => _),
    ) as Observable<Buffer>;

let reactString: ReactString = ({ request, reply }) => {
    return (element) => (preRenderData) =>
        renderT0String(element, preRenderData, {
            fastifyReply: reply,
            fastifyRequest: request,
            initialState: preRenderData.controllerResult.initialState,
        });
};
