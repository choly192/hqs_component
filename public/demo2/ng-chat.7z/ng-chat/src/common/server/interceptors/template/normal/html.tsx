import React, { FC, ComponentType } from "react";
import { GlobalContext } from "../../context/GlobalContext";

import { ContextType, PreRender } from "../../types/render";
import { createBody } from "./body";
import { createHead } from "./head";

const createHtml = (
    content: ComponentType,
    preRender: PreRender,
    environment: ContextType
) => {
    const Body = createBody(content, preRender);
    const Head = createHead(preRender);
    let Html: FC = () => {

        return (
            <GlobalContext.Provider value={environment}>
                <html lang={`en-us`}>
                    <Head />
                    <Body />
                </html>
            </GlobalContext.Provider >
        );
    };

    return Html;
};

export { createHtml };