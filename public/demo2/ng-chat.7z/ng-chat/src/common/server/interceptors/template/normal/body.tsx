import React, { ComponentType, FC } from 'react';

import { PreRender } from '../../types/render';
import { StateScript } from '../../utils/StateScript';

let createBody = (Content: ComponentType, preRender: PreRender): FC => () => {
    let scripts = preRender?.htmlConfig?.bodyScripts || [];

    return (
        <body {...Content['__BODY_PROPS__']}>
            {preRender?.injectedScripts?.map(({ content, name }) => (
                <div key={name} dangerouslySetInnerHTML={{ __html: content }} />
            ))}
            <div id="root">
                <Content />
            </div>

            {/* <StateScript name="__SITE__" data={preRender?.siteConf} /> */}
            <StateScript name="__initialState__" data={preRender?.controllerResult} />
            {/* <StateScript name="__neweggState__" data={preRender?.neweggState} /> */}
            {preRender?.polyfills?.map((x) => (
                <script key={x} src={x} />
            ))}

            {scripts.map((s) => (
                <script defer src={s.src} key={s.src} />
            ))}

        </body>
    );
};

export { createBody };
