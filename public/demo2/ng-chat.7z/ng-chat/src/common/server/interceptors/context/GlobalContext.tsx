import { createContext, useContext } from "react";

export let GlobalContext = createContext<{
  initialState: any;
}>({} as any);


export let useInitialState = <T,>(): T =>
  useContext(GlobalContext)?.initialState;