import { ComponentType } from "react";
import { ContextType, PreRender } from "../types/render";

import { createHtml } from "./normal/html";

function getHtmlComponent(
    content: ComponentType,
    preRender: PreRender,
    environment: ContextType,
): ComponentType {
    const html = createHtml(content, preRender, environment);
    return html;
}

export { getHtmlComponent };
