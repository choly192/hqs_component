import { AddAssetsManifest, PreRender } from '../../types/render';
import { processAsseets2 } from '../../utils/process-assets';

let isDev = process.env?.__DEV__ === 'true';

export let addAssetsManifest: AddAssetsManifest = ({ request, getConfig }): any => {
    let { scripts, styles } = processAsseets2(getConfig);

    if (scripts === undefined && styles === undefined) {
        if (isDev) {
            console.log('Maybe you forgot to yarn build:gulp?');
        }
        return null;
    }

    return (data) => {
        let htmlConfig: PreRender['htmlConfig'] = {
            headStyles: styles.map((s) => ({ src: s })),
            headScripts: scripts
                .filter((s) => s.js.includes('polyfillEntry'))
                .map((s) => ({ src: s.js, scriptSpecies: s.scriptSpecies })),
            bodyScripts: scripts
                .filter((s) => !s.js.includes('polyfillEntry'))
                .map((s) => ({ src: s.js, scriptSpecies: s.scriptSpecies })),
        };
        return {
            controllerResult: data,
            htmlConfig,
        };
    };
};
