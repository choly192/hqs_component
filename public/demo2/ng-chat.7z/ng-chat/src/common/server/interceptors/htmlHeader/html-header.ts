import { AddHtmlHeader } from '../types/render';

export let addHtmlHeader: AddHtmlHeader = ({ request, getConfig }) => {
    return (preRenderData) => {
        return preRenderData;
    };
};
