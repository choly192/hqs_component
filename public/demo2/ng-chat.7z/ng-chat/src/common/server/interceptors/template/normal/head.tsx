import React, { FC } from 'react';
// import { encode } from 'he';
// import parser from 'html-react-parser';

import { PreRender } from '../../types/render';


let createHead =
  (preRender: PreRender): FC =>
  () => {
    let scripts = preRender?.htmlConfig?.headScripts || [];
    let styles = preRender?.htmlConfig?.headStyles || [];

    // let description = preRender?.controllerResult?.pageInfo?.PageDescription;
    let title = preRender?.controllerResult?.pageInfo?.PageTitle;
    // let viewport = preRender?.controllerResult?.pageInfo?.viewport;
   
    let enableRobot = preRender.htmlConfig.robots;
    let enableFollowWhenNoIndex = preRender?.controllerResult?.pageInfo?.followWhenNoIndex || false;
    const followWhenNoIndex = enableFollowWhenNoIndex ? ',follow' : '';

    // const parserHTML = (content: string) => {
    //     return parser(encode(content)) as string;
    //   };

    return (
      <head>
        <title>{title}</title>
        <meta charSet="utf-8" />
        <meta httpEquiv="content-type" content="text/html; charset=UTF-8" />
        {/* {viewport && <meta name="viewport" content={parserHTML(viewport)}></meta>} */}
        <meta name="referrer" content="always" />
        {/* <meta name="description" content={parserHTML(description)} /> */}


        <meta name="language" content="english" />
        
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta
          name="robots"
          content={
            enableRobot
              ? 'index,follow,max-image-preview:large,max-snippet:-1'
              : `noindex${followWhenNoIndex}`
          }
        />
        <meta name="X-DNS-Prefetch-Control" content="on" />
        <meta name="format-detection" content="telephone=no" />
      
        <link
          rel="shortcut icon"
          type="image/x-icon"
          href="https://c1.neweggimages.com/WebResource/Chat/Themes/Nest/newegg.ico"
        />
       
        {/* <script
          dangerouslySetInnerHTML={{
            __html: `window.__PolyfillScripts__=${JSON.stringify(
              preRender.siteConf.PolyfillScripts,
            )}`,
          }}
        /> */}
        {scripts.map((s) => (
          <script src={s.src} key={s.src}></script>
        ))}
        {styles.map((s) => (
          <link href={s.src} rel="stylesheet" key={s.src}></link>
        ))}

      </head>
    );
  };

export { createHead };
