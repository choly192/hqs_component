import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { ConfigurationManager } from '@framework-frontend/node';

import { ControllerMethod } from './decorators/page.decorator';
import { ComponentType } from 'react';
import { Options } from './types/render';
import { render } from './utils/render';

@Injectable()
export class RenderHtmlInterceptor implements NestInterceptor {
    constructor(private readonly configurationManager: ConfigurationManager) {}

    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        let element = (context.getHandler() as ControllerMethod).__Root_React_Element__;
        if (!element) {
            return next.handle();
        }

        const reply = context.switchToHttp().getResponse();
        let request = context.switchToHttp().getRequest();
        const getConfig = (name: string) => this.configurationManager.getConfiguration(name);
        let options = {
            request,
            reply,
            getConfig,
        };

        reply.header('Content-Type', 'text/html; charset=UTF-8');
        return this.render(element, options, next);
    }

    protected render(element: ComponentType, options: Options, next: CallHandler): Observable<any> {
        return render(
            next.handle(),
            options,
        )(element).pipe(
            catchError((error) => {
                throw error;
            }),
        );
    }
}
