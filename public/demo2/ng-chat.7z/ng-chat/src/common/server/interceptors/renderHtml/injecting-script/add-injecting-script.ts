import { AddInjectingScripts, GetConfig, IInjectedScript } from '../../types/render';
import Seq, { filter } from 'lodash';

interface ThirdPartyConfig {
    resources: IInjectedScript[];
}

const polyfillConf = [
    {
        test: (agent: string) => !!agent.match(/msie|trident/i),
        polyfills: ['polyfill-ie11'],
    },
];

const getPolyfills = (ua: string, getConfig: GetConfig) => {
    if (!ua) return [];

    const scripts = getConfig('assets.script');
    const webConfig = getConfig('WebConfig');
    let cdn = webConfig?.CDN?.jsServer;
    if (cdn.indexOf('localhost') >= 0) cdn = '';

    return Seq(polyfillConf)
        .filter((x) => x.test(ua))
        .map((x) => filter(x.polyfills.map((y) => scripts[y]?.js)))
        .flatMap((x) => cdn + x)
        .value();
};

export let addInjectingScript: AddInjectingScripts = ({ request, getConfig }) => {
    let thirdPartyConfig = getConfig('Application.ThirdParty');

    return (preRenderData) => {
        let scripts = thirdPartyConfig.resources.filter(combineFilters(filterByEnabled));

        preRenderData.injectedScripts = scripts;
        // preRenderData.polyfills = getPolyfills(request.headers['user-agent'], getConfig);

        return preRenderData;
    };
};

type Filter = {
    (a: ThirdPartyConfig['resources'][number]): boolean;
};

let combineFilters = (...fs: Filter[]): Filter => (config) =>
    fs.map((f) => f(config)).reduce((res, i) => res && i, true);

const filterByEnabled: Filter = ({ enable }) => enable;
