import { FastifyReply, FastifyRequest } from 'fastify';
import { ComponentType } from 'react';
import { Observable } from 'rxjs';

type Reply = FastifyReply<any>;

export type ContextType = {
    fastifyReply?: FastifyReply<any>;
    fastifyRequest?: FastifyRequest<any>;
    initialState: any;
    rerender?: {
        reducers: { fn: (s: any) => any; priority?: number }[];
        rerendered: boolean;
    };
};

export type GetConfig = {
    (n: string): any;
};

export type Options = {
    request: FastifyRequest;
    reply: Reply;
    getConfig: GetConfig;
};

export type ControllerResult<T = any> = {
    initialState: T;
    pageInfo?: {
        [a: string]: string;
    };
    raw?: string;
    __DEBUG_INFO__?: any;
};

export type ReactString = {
    (x: { request: FastifyRequest; reply: Reply }): (
        element: ComponentType,
    ) => (preRenderData: PreRender) => Observable<Buffer>;
};

export type PreRender = {
    controllerResult: ControllerResult;
    htmlConfig: HtmlConfig;
    // siteConf?: {
    //     CDN: string;
    //     staticCDN?: string; // for local test static image cdn
    //     scripts: Array<{ js: string; scriptSpecies?: string }>;
    //     ImageConfiguration: { [key: string]: any };
    //     JsonpList: Array<{ name: string; api: string }>;
    //     PolyfillScripts: { [s: string]: string };
    //     thirdParty?: any;
    //     adobeConfig?: any;
    //     timestamp: number;
    // };
    injectedScripts?: IInjectedScript[];
    polyfills?: string[];
    // neweggState: INeweggState;
};

export type HtmlConfig = {
    title?: string;
    robots?: boolean;
    headScripts?: {
        src: string;
    }[];
    headStyles?: {
        src: string;
    }[];
    bodyScripts?: {
        src: string;
        scriptSpecies: string;
    }[];
};

export type IInjectedScript = {
    enable: boolean;
    name: string;
    content: string;
};

export type AddAssetsManifest = {
    (x: { request: FastifyRequest; getConfig: GetConfig }): (data: ControllerResult) => PreRender;
};

export type AddInjectingScripts = {
    (x: { request: FastifyRequest; getConfig: GetConfig }): (data: PreRender) => PreRender;
};

export type AddHtmlHeader = {
    (x: { request: FastifyRequest; getConfig: GetConfig }): (data: PreRender) => PreRender;
};

export interface ICurrencyInfo {
    countryCode: string;
    currencyCode: string;
    extraUnit: string;
    unit: string;
    decimalDigits: number;
    decimalSeparator: string;
    groupSizes: number;
    groupSeparator: string;
    positivePattern: number;
    supportDecimal: boolean;
}
