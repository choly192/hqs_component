import { ComponentType, createElement } from 'react';
import { renderToNodeStream } from 'react-dom/server';
import { Observable } from 'rxjs';

import { getHtmlComponent } from '../template/getHtml';
import { ContextType, PreRender } from '../types/render';

export let renderT0String = (
    element: ComponentType,
    preRender: PreRender,
    environment: ContextType,
) => {
    let rerender: ContextType['rerender'] = {
        reducers: [],
        rerendered: false,
    };

    let updateInitialState = () => {
        try {
            let reducers = rerender?.reducers
                ?.map((i) => {
                    if (i.priority) {
                        return i;
                    } else {
                        return { ...i, priority: 500 };
                    }
                })
                ?.sort((i:any) => -i?.priority)
                ?.map((i) => i.fn);
            let newInitState = reducers?.reduce(
                (prev, reduce) => reduce(prev),
                environment.initialState,
            );
            environment.initialState = newInitState;
            preRender.controllerResult.initialState = newInitState;
        } catch (e) {
            console.error(e);
        }
    };

    let renderBuf = (onEnd: (b: Buffer) => void, onError: (e: Error) => void) => {
        let htmlComponent = getHtmlComponent(element, preRender, {
            ...environment,
            rerender,
        });

        let stream = renderToNodeStream(createElement(htmlComponent));

        let buf = Buffer.from('<!DOCTYPE html>');

        stream.on('data', (data) => {
            buf = Buffer.concat([buf, data]);
        });

        stream.on('end', () => {
            // rerender only once
            if (rerender && rerender?.reducers?.length > 0 && !rerender?.rerendered) {
                rerender.rerendered = true;
                updateInitialState();
                renderBuf(onEnd, onError);
            } else {
                onEnd(buf);
            }
        });

        stream.on('error', onError);
    };


    return new Observable<Buffer>(subscriber => {
        renderBuf(
          buf => {
            subscriber.next(buf);
            subscriber.complete();
          },
          error => {
            subscriber.error(error);
          }
        );
      });
};
