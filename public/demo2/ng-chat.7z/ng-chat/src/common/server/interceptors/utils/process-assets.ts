import { map, castArray, compact } from 'lodash';

export const processAsseets2 = (
    getConfig: (n: string) => any,
): { scripts: Array<{ js: string; scriptSpecies: string }>; styles: string[] } => {
    let scripts: Array<{ js: string; scriptSpecies: string }>, styles: string[];
    const webConfig = getConfig('WebConfig');

    const stylesAssets = getConfig('assets.css');
    const scriptsAssets = getConfig('assets.script');
    const jsCDN = webConfig?.CDN?.jsServer || '';
    const cssCDN = webConfig?.CDN?.cssServer || '';
    scripts = getScript(scriptsAssets, jsCDN);
    styles = getSource(stylesAssets, cssCDN);

    return {
        scripts,
        styles,
    };
};

function getScript(dic, cdn: string) {
    if (!dic) {
        return [];
    }
    return Object.keys(dic).map((s) =>
        cdn.indexOf('localhost') >= 0
            ? { scriptSpecies: dic[s]?.scriptSpecies, js: dic[s]?.js }
            : { scriptSpecies: dic[s]?.scriptSpecies, js: `${cdn}${dic[s]?.js}` },
    );
}

function getSource(dic, cdn: string) {
    if (!dic) {
        return [];
    }
    return Object.keys(dic).map((s) =>
        cdn.indexOf('localhost') >= 0 ? dic[s] : `${cdn}${dic[s]}`,
    );
}
