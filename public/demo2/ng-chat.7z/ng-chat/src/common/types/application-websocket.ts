export type ApplicationWebsocket = {
    ChatBotConnection: ChatBotConnection;
};

export type ChatBotConnection = {
    HubUrl: string;
    HostAddress: string;
    ServerTimeoutInMilliseconds: number;
    KeepAliveIntervalInMilliseconds: number;
    SkipNegoTiation: boolean;
    Transport: number;
    MaxRetryCounts: number;
};
