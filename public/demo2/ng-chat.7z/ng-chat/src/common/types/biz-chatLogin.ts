import { Country } from './';

export type BizChatLogin = {
    CategoryOptions: CategoryOption;
    CategoryAndQueueMapping: CategoryAndQueueMapping;
    ChatBotEntrance: ChatBotEntrance;
    TopicAndReasonOptions: TopicAndReasonOptions;
    SpecialChatSkills: Array<SpecialChatSkill>;
    EmailValidRegex: string;
    DefaultTopic: string;
    DefaultReason: string;
    DefaultCategory: string;
    DefaultCloseMessage: string;
    EnableTranscript: boolean;
};

export type CategoryOption = {
    [K in Country]: Array<string>;
};

export type CategoryAndQueueMapping = {
    [K in Country]: Array<CategoryAndQueueInfo>;
};

export type CategoryAndQueueInfo = {
    CategoryName: string;
    QueueName: string;
    QueueID: string;
    Skills: string;
    Priority: string;
};

export type ChatBotEntrance = {
    Enable: boolean;
    AllowAllTopicAndReason: boolean;
};

export type TopicAndReasonOptions = {
    [K in Country]: Array<TopicAndReasonOption>;
};

export type TopicAndReasonOption = {
    Name: string;
    Reason: Array<Reason>;
};

export type Reason = {
    Name: string;
    AllowChatBot: boolean;
};

export type SpecialChatSkill = {
    SkillName: string;
    HitTopic: string;
    HitCategory: string;
    HitReason: string;
    HitCity: string;
};
