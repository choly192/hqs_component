export type BizChatSurvey = {
    FeedBackInfo: FeedBackInfo
}
export type FeedBackInfo = {
    HashCode: string;
    ExcludeQuesion: string;
    QuestionReplaceInfo: QuestionReplaceInfo
}
export type QuestionReplaceInfo = {
    Question: Array<
        {
            QuestionMasterId: string;
            QuestionText: string;
        }
    >
}