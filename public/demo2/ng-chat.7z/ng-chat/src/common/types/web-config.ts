export type WebConfig = {
    PORT?: number;
    CDN: {
        imageServer: string;
        cssServer: string;
        jsServer: string;
        staticImageServer: string;
    };
};
