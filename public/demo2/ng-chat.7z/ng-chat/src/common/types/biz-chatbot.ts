export type BizChatBot = {
    MaxConnectToAgentRetryCounts: number;
};
