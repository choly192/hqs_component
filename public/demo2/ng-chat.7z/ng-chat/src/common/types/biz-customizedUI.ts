import { Country } from "./";

export interface BizCustomizedUI {
    ChatWindow: Array<BizCustomizedUIDetail>;
}
export type BizCustomizedUIDetail = {
    Countries: Country;
    Value: {
        Title: {
            Main: string;
            Sub: string;
        };
        Disclaimer: string;
    };
};
