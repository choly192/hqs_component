export type BizChatAgent = {
    EnableTyping: boolean;
};
