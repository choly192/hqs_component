export type BizCommon = {
    ChatStatusCookieExpireDate: ChatStatusCookieExpireDate;
    PureCloud: PureCloud;
    SpecialBusiness: Array<SpecialBusiness>;
};

export type SpecialBusiness = {
    BizType: number;
    Description: string;
    Config?: Config;
};

type Config = {
    SpecialApi?: Array<{ key?: string; api?: string }>;
    SpecialCustomField2?: string;
    SpecifiedQueueList?: Array<string>;
};
export type ChatStatusCookieExpireDate = {
    ChattingExpireMinute: number;
    WaitingChatExpireMinute: number;
};
export type PureCloud = {
    deployMentKey: string;
    orgGuid: string;
};
