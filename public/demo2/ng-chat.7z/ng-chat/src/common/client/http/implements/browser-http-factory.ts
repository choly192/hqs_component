import { IRestRequest, RestClient, IRestClient, RestRequest } from '@framework-frontend/core/dist/http2.0';

import { IHttpClient } from '../../../http/http-client.interface';
import { AbstractHttpFactory } from '../../../http/implements/abstract-http-factory';

export class BrowserHttpFactory extends AbstractHttpFactory {
  private static _httpFactory = new BrowserHttpFactory();

  public createRestClient(apiName: string): IRestClient {
    return new RestClient(`${location.protocol}//${location.host}`);
  }

  public createRestRequest(apiName: string): IRestRequest {
    return new RestRequest(`api/${apiName}`);
  }

  public static initialize() {
    this._httpFactory = new BrowserHttpFactory();
  }

  public static create(apiName): IHttpClient {
    const client = this._httpFactory.create(apiName);
    return client;
  }
}
