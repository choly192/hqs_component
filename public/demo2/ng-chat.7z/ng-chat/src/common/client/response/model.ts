export interface ResponseBody<T extends Object, K> {
    errorCode: K;
    errorMessage: string;
    data: T | null;
}
