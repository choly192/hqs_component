let localStorage = {
    conf: {
        CountryInfo: {
            key: 'NG_CI',
            options: {
                path: 'www',
            },
        },
        CartItems: {
            key: 'NG_CartItems',
            options: {
                path: 'ssl',
            },
        },
        CompareItems: {
            key: 'NG_CompareBox',
            type: 2,
            options: {
                path: 'www',
            },
        },
        GuestEmail: {
            key: 'NG_Ge',
            type: 2,
            options: {
                path: 'www',
            },
        },
        PromoCodes: {
            key: 'NG_Promo',
            type: 2,
            options: {
                path: 'ssl',
            },
        },
        IsNotShowDelMessage: {
            key: 'NG_HideDelMsg',
            options: {
                path: 'www',
            },
        },
        PrivacyPolicy: {
            key: 'NG_PPV',
            type: 2,
            options: {
                path: 'ssl',
            },
        },
        SmartBanner: {
            key: 'NG_SB',
            type: 2,
            options: {
                path: 'www',
            },
        },
        Purchased: {
            key: 'NG_Purchased',
            type: 2,
            options: {
                path: 'ssl',
            },
        },
        RecentlyView: {
            key: 'NG_Viewed',
            type: 2,
            options: {
                path: 'www',
            },
        },
        SearchHistory: {
            key: 'NG_Searched',
            type: 2,
            options: {
                path: 'www',
            },
        },
        PopupBanner: {
            key: 'NG_PopupBanner',
            type: 2,
            options: { path: 'www' },
        },
    },
    keys: {
        IsNotShowDelMessage: {
            key: 'NG_HideDelMsg',
        },
        ItemList: {
            key: 'itemList',
        },
        KeyWords: {
            key: 'keywords',
        },
        PrivacyPolicy: {
            key: 'NG_PPV',
        },
        SmartBanner: {
            key: 'NG_SB',
        },
        Purchased: {
            key: 'NG_Purchased',
        },
        RecentlyView: {
            key: 'NG_Viewed',
        },
        CountryInfo: {
            key: 'CountryInfo',
        },
        IsIpMatched: {
            key: 'IsDefaultRegion',
        },
        PopStamp: {
            key: 'PopStamp',
        },
        GuestEmail: {
            key: 'NG_Ge',
        },
        PromoCodes: {
            key: 'NG_Promo',
        },
        PopupBanner: {
            key: 'NG_PopupBanner',
        },
    },
};

export let StorageConfig = {
    localStorage,
    sessionStorage: {
        conf: {},
        keys: {
            MyCountry: {
                key: 's_mycounrty',
            },
            Finder: {
                key: 's_finder',
            },
            ShowCaseComment: {
                key: 's_showcase_comment',
            },
            Adobe: {
                key: 's_adobe',
            },
        },
    },
};

export default StorageConfig;
