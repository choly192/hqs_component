import { omit } from 'lodash';
import { nameMapping } from './local/nameMapping';
import { LocalStorageData as LS } from './local/nameMapping';

let voidStorage: Storage = {
    length: 0,
    key: () => '',
    clear: () => {},
    getItem: () => '',
    removeItem: () => {},
    setItem: () => {},
};

export const ROOT_KEY = 'CHAT_INFO';

let Storage = (st: Storage) => (original: boolean = false) => {
    let getKeyByName = (key: string): string => {
        if (st !== voidStorage && st === localStorage && nameMapping[key]) return nameMapping[key];

        return key;
    };

    let getAll = (): LS => {
        let value = st.getItem(ROOT_KEY);
        try {
            return JSON.parse(value as string);
        } catch {
            return null as any;
        }
    };

    let getRaw = (name: string): string => {
        let key = getKeyByName(name);
        return getAll()?.[key];
    };

    let get = (name: string) => {
        let raw = original ? st.getItem(name) : getRaw(name);
        try {
            return JSON.parse(raw as string);
        } catch {
            return raw;
        }
    };

    let set = (name: string, value: string | object) => {
        if (original) {
            st.setItem(name, typeof value === 'string' ? value : JSON.stringify(value));
            return;
        }
        let key = getKeyByName(name);
        let oldLS = getAll();
        let newValue = typeof value === 'string' ? value : JSON.stringify(value);
        let newLS: LS = {
            ...oldLS,
            ...{ [key]: newValue },
        };
        st.setItem(ROOT_KEY, JSON.stringify(newLS));
    };

    let remove = (name: string) => {
        if (original) {
            st.removeItem(name);
            return;
        }
        let key = getKeyByName(name);
        let newLS = omit(getAll(), key);
        st.setItem(ROOT_KEY, JSON.stringify(newLS));
    };

    return { get, set, remove, getAll };
};

export let LocalStorage = Storage(typeof localStorage === 'undefined' ? voidStorage : localStorage);
export let SessionStorage = Storage(
    typeof sessionStorage === 'undefined' ? voidStorage : sessionStorage,
);
