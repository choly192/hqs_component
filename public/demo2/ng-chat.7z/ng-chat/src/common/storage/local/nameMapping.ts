export enum LocalStorageType {
    CHAT_STATE = 'CHAT_STATE',
    // CHAT_USER_NAME = 'CHAT_USER_NAME',
    // CHAT_EMAIL = 'CHAT_EMAIL',
    CHAT_WINDOW_IS_OPEN = 'CHAT_WINDOW_IS_OPEN',
    CHAT_BASIC_INFO = 'CHAT_BASIC_INFO',
    // CHAT_INFO = 'CHAT_INFO',
    // CHAT_START_TIME = 'CHAT_START_TIME',
    // CHAT_QUEUE_ID = 'CHAT_QUEUE_ID',
    CHAT_CONVERSATION_ID = 'conversationId',
    // CHAT_SEND_TRANSCRIPT_EMAIL = 'transcript_email_checked',
    CHAT_CONVERSATION_TOKEN = 'jwt',
    // CHAT_CUSTOMERNUMBER = 'customerNumber',
    CHAT_SOURCE = 'source',
    CHAT_CUSTOMER_MEMBER_ID = 'customer_member_id',
    CHAT_CONVERSATION_WEBSOCKETURL = 'websocket_url',
    // CHAT_AGENT_ID = 'agentId',
    CHAT_AGENT_NAME = 'agentName',
    CHAT_LANGUAGE = 'language',
    CHAT_HAS_SUBMIT_FEEDBACK = 'has_submit_feedback',
    CHAT_HAS_RED_TIPS = 'has_red_tips',
    CHAT_MSG_LIST = 'msg_list',

    CHATBOT_SESSIONID = 'ChatBotSessionId',
    CHATBOT_TOKEN = 'ChatBotToken',
    // CHATBOT_STATE = 'ChatBotState',
    CHATBOT_HISTORY_LINK = 'ChatBotHistoryLink',
    CHATBOT_TO_AGENT = 'ChatBotToAgent',
}

export let nameMapping = {
    CHAT_STATE: LocalStorageType.CHAT_STATE,
    // CHAT_USER_NAME: LocalStorageType.CHAT_USER_NAME,
    // CHAT_EMAIL: LocalStorageType.CHAT_EMAIL,
    CHAT_WINDOW_IS_OPEN: LocalStorageType.CHAT_WINDOW_IS_OPEN,
    CHAT_BASIC_INFO: LocalStorageType.CHAT_BASIC_INFO,
    CHAT_CONVERSATION_ID: LocalStorageType.CHAT_CONVERSATION_ID,
    // CHAT_SEND_TRANSCRIPT_EMAIL: LocalStorageType.CHAT_SEND_TRANSCRIPT_EMAIL,
    CHAT_CONVERSATION_TOKEN: LocalStorageType.CHAT_CONVERSATION_TOKEN,
    // CHAT_CUSTOMERNUMBER: LocalStorageType.CHAT_CUSTOMERNUMBER,
    CHAT_SOURCE: LocalStorageType.CHAT_SOURCE,
    CHAT_CUSTOMER_MEMBER_ID: LocalStorageType.CHAT_CUSTOMER_MEMBER_ID,
    CHAT_CONVERSATION_WEBSOCKETURL: LocalStorageType.CHAT_CONVERSATION_WEBSOCKETURL,
    CHAT_AGENT_NAME: LocalStorageType.CHAT_AGENT_NAME,
    CHAT_LANGUAGE: LocalStorageType.CHAT_LANGUAGE,
    CHAT_HAS_SUBMIT_FEEDBACK: LocalStorageType.CHAT_HAS_SUBMIT_FEEDBACK,
    CHAT_HAS_RED_TIPS: LocalStorageType.CHAT_HAS_RED_TIPS,
    CHAT_MSG_LIST: LocalStorageType.CHAT_MSG_LIST,

    CHATBOT_SESSIONID: LocalStorageType.CHATBOT_SESSIONID,
    CHATBOT_TOKEN: LocalStorageType.CHATBOT_TOKEN,
    CHATBOT_TO_AGENT: LocalStorageType.CHATBOT_TO_AGENT,
    // CHATBOT_STATE: LocalStorageType.CHATBOT_STATE,
    // CHATBOT_HISTORY_LINK: LocalStorageType.CHATBOT_HISTORY_LINK,
};

export class LocalStorageData {
    [LocalStorageType.CHAT_STATE]: ChatStatus;
    // [LocalStorageType.CHAT_USER_NAME]: string;
    // [LocalStorageType.CHAT_EMAIL]: string;
    [LocalStorageType.CHAT_WINDOW_IS_OPEN]: boolean;
    [LocalStorageType.CHAT_BASIC_INFO]: ChatBasicInfo;
    [LocalStorageType.CHAT_CONVERSATION_ID]: string;
    // [LocalStorageType.CHAT_SEND_TRANSCRIPT_EMAIL]: boolean;
    [LocalStorageType.CHAT_CONVERSATION_TOKEN]: string;
    // [LocalStorageType.CHAT_CUSTOMERNUMBER]: string;
    [LocalStorageType.CHAT_SOURCE]: string;
    [LocalStorageType.CHAT_CUSTOMER_MEMBER_ID]: string;
    [LocalStorageType.CHAT_CONVERSATION_WEBSOCKETURL]: string;
    [LocalStorageType.CHAT_AGENT_NAME]: string;
    [LocalStorageType.CHAT_LANGUAGE]: string;
    [LocalStorageType.CHAT_HAS_SUBMIT_FEEDBACK]: boolean;
    [LocalStorageType.CHAT_HAS_RED_TIPS]: boolean;
    [LocalStorageType.CHAT_MSG_LIST]: Array<ChatMsg>;

    [LocalStorageType.CHATBOT_SESSIONID]: string;
    [LocalStorageType.CHATBOT_TOKEN]: string;
    // [LocalStorageType.CHATBOT_STATE]: string;
    [LocalStorageType.CHATBOT_HISTORY_LINK]: string;
    [LocalStorageType.CHATBOT_TO_AGENT]: boolean;
}

export class ChatBasicInfo {
    fullName: string;

    emailAddress: string;

    sendMeTranscript: boolean;

    category: string;

    topic: string;

    reason: string;

    question: string;

    dateTime?: Date;

    questionTranslate?: string;
}

export class ChatMsg {
    role: 'AGENT' | 'CUSTOMER';
    sendMessage: string;
    sendDate: string;
    translateMessage: string;
    targetLanguage: string;
    oriLanguage: string;
    messageId: string;
}

export enum ChatStatus {
    Ended = 'Ended',
    Initial = 'Initial',
    Waiting = 'Waiting',
    Chatting = 'Chatting',
    ChatBotChatting = 'ChatBotChatting',
    BotToAgent = 'BotToAgent',
}
