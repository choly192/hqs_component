import React, {
    FC,
    useState,
    useRef,
    useEffect,
    forwardRef,
    useImperativeHandle,
    Ref,
} from 'react';
import classnames from 'classnames';

interface SelectProps {
    title?: string;
    disabled?: boolean;
    defaultValue?: string;
    onChange?: (val: string) => void;
    isWide?: boolean;
    isActive?: boolean;
    customerClass?: string;
}
export let Select: FC<SelectProps> = (props, ref) => {
    const {
        title,
        isWide,
        isActive,
        disabled,
        children,
        onChange,
        defaultValue,
        customerClass,
    } = props;
    const [selectValue, setSelectedValue] = useState(defaultValue);

    let className = classnames(
        'form-select',
        {
            'is-wide': isWide,
            'is-active': isActive,
        },
        customerClass,
    );

    let change = (e) => {
        setSelectedValue(e.target.value);
        onChange && onChange(e.target.value);
    };

    return (
        <label className={className}>
            <select
                disabled={disabled || false}
                onChange={change}
                title={title}
                defaultValue={defaultValue}
            >
                {children}
            </select>
            <span className="form-select-name">{selectValue}</span>
            <i className="fa fa-caret-down"></i>
        </label>
    );
};

Select.displayName = "Select"