import React, {
    FC,
    useState,
    useRef,
    useEffect,
    forwardRef,
    useImperativeHandle,
    Ref,
} from 'react';
import cn from 'classnames';

export interface CascaderOptions {
    Value: string;
    Children?: Array<CascaderOptions>;
    Key?: number;
    Level?: number;
}

interface CustomerOptions {
    defaultValue?: Array<string>;
    class?: Array<string>;
    title?: Array<string>;
}

interface CascaderProps {
    onChange?: (val: Array<string>) => void;
    options: Array<CascaderOptions>;
    CustomerOptions?: CustomerOptions;
    ReplaceDefaultValue?: boolean;
    ReturnAllValue?: boolean;
}

export let Cascader: FC<CascaderProps> = ({
    onChange,
    CustomerOptions,
    options,
    ReplaceDefaultValue,
    ReturnAllValue,
}) => {
    const selectValueArrayRef = useRef<Array<string>>(
        CustomerOptions && CustomerOptions.defaultValue && CustomerOptions.defaultValue.length > 0
            ? CustomerOptions?.defaultValue
            : [],
    );

    const [, setSelectedValueArray] = useState<Array<string>>(selectValueArrayRef.current);
    const [cascaderArray, setCascaderArray] = useState<Array<() => JSX.Element>>([
        () => renderCascader(dealOptions(options, 0), 0),
    ]);

    let change = (e: React.ChangeEvent<HTMLSelectElement>, options: Array<CascaderOptions>) => {
        const selectOption = options.find((t) => t.Value == e.target.value);
        const level = selectOption?.Level ?? 0;
        selectValueArrayRef.current = selectValueArrayRef?.current?.slice(0, level + 1);
        selectValueArrayRef.current[level] = selectOption?.Value ?? '';
        setSelectedValueArray([...selectValueArrayRef?.current]);
        if (selectOption?.Children && selectOption?.Children?.length > 0) {
            setCascaderArray((prevCascaderArray) => {
                prevCascaderArray = prevCascaderArray?.slice(0, level + 1);
                prevCascaderArray?.push(() =>
                    renderCascader(selectOption?.Children ?? [], level + 1),
                );
                return prevCascaderArray;
            });
            CustomerOptions?.defaultValue &&
                selectValueArrayRef.current.push(CustomerOptions.defaultValue[level + 1]);
            setSelectedValueArray([...selectValueArrayRef.current]);
        } else {
            setCascaderArray((prevCascaderArray) => {
                if (CustomerOptions?.defaultValue && CustomerOptions?.defaultValue.length > 0) {
                    let index = CustomerOptions?.defaultValue?.findIndex(
                        (t, i) => t == selectValueArrayRef.current[i],
                    );
                    if (prevCascaderArray && prevCascaderArray.length > 0 && index > -1) {
                        prevCascaderArray = prevCascaderArray.slice(0, index + 1);
                    }
                }
                return prevCascaderArray;
            });
            onChange && ReturnAllValue && onChange(selectValueArrayRef.current);
        }
        if (
            onChange &&
            !ReturnAllValue &&
            CustomerOptions?.defaultValue &&
            CustomerOptions?.defaultValue?.length > 0
        ) {
            let arr: Array<string> = [];
            selectValueArrayRef.current.forEach((t, index) => {
                if (CustomerOptions.defaultValue) {
                    if (t == CustomerOptions?.defaultValue[index]) {
                        arr.push(ReplaceDefaultValue ? '' : t);
                    } else {
                        arr.push(t);
                    }
                }
            });
            onChange(arr);
        }
    };

    useEffect(() => {
        if (options && options.length > 0) {
            options = dealOptions(options, 0);
            setCascaderArray([() => renderCascader(options, 0)]);
        }
    }, [options]);

    const renderCascader = (options: Array<CascaderOptions>, level: number) => {
        return (
            <label
                className={cn(
                    'form-select',
                    CustomerOptions?.class && CustomerOptions?.class[level],
                )}
                key={level}
            >
                <select
                    onChange={(e) => change(e, options)}
                    title={CustomerOptions?.title && CustomerOptions?.title[level]}
                    defaultValue={
                        CustomerOptions?.defaultValue && CustomerOptions?.defaultValue[level]
                    }
                >
                    {options.map((option, index) => {
                        return (
                            <option value={option.Value} key={`${option.Value}-${index}`}>
                                {option.Value}
                            </option>
                        );
                    })}
                </select>
                <span className="form-select-name">{selectValueArrayRef.current[level]}</span>
                <i className="fa fa-caret-down"></i>
            </label>
        );
    };

    return (
        <>
            {cascaderArray &&
                cascaderArray.length > 0 &&
                cascaderArray.map((cascader) => cascader())}
        </>
    );
};

const dealOptions = (options: Array<CascaderOptions>, level: number): Array<CascaderOptions> => {
    return options.map(
        (t, index): CascaderOptions => {
            const children =
                t.Children && t.Children.length > 0 ? dealOptions(t.Children, level + 1) : [];
            t.Level = level;
            t.Key = index;
            t.Children = children;
            return t;
        },
    );
};

Cascader.displayName = 'Cascader';
