import React, { FC } from 'react';
import classnames from 'classnames';

interface checkboxProps {
    size?: 'is-mini';
    disabled?: boolean;
    children?: string;
    checked?: boolean;
    defaultChecked?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    styles?: any;
    id?: string;
}

export let Checkbox: FC<checkboxProps> = ({
    size,
    disabled,
    children,
    checked,
    defaultChecked,
    onChange,
    styles,
    id,
}) => {
    let className = classnames('form-checkbox', {
        size: size,
    });

    let change = (e: React.ChangeEvent<HTMLInputElement>) => {
        onChange && onChange(e);
    };

    return (
        <label className={className} htmlFor={id}>
            <input
                id={id}
                type="checkbox"
                disabled={disabled ?? false}
                defaultChecked={defaultChecked}
                checked={checked ?? undefined}
                onChange={change}
            />
            <span className="form-checkbox-title" style={styles}>
                {children && children}
            </span>
        </label>
    );
};

Checkbox.displayName = 'Checkbox';
