import { useEffect, useState, useCallback } from 'react';
import { getCookie } from '../utils/getCookie';

interface Header {
    ['x-nvtc']?: string;
}
type UseRequestHeaderRespoes = [Header, () => void];

export const useRequestHeader = (): UseRequestHeaderRespoes => {
    const [header, setHeader] = useState({});

    const handleGetHeader = useCallback(() => {
        const nvtc = getCookie('NVTC');
        let newHeader = {};

        if (nvtc) {
            newHeader = {
                ...newHeader,
                ['x-nvtc']: nvtc,
            }
        }

        setHeader(newHeader);
    }, []);

    useEffect(() => {
        handleGetHeader();
    }, [true]);

    return [header, handleGetHeader];
}