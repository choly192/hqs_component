import { useCallback, useRef } from 'react';
import axios, { AxiosRequestConfig, AxiosResponse, Canceler } from 'axios';
import { isEmpty } from 'lodash';
import { useRequestHeader } from './useRequestHeader';
import {
    ReqData,
    UploadingOptions,
    UploadFile,
    ApiPath,
    UseUploadProgressResponses,
    ErrorMessageType,
    UploadErrorMessage,
    ProgressBeforeParams,
    ProgressParams,
    CancelListChangeParams,
    CancelSendListRef,
} from '../types';

const CancelToken = axios.CancelToken;

/**
 * @param config axios 配置
 * @param errorMessage
 */
export const useUploadProgress = (
    config?: AxiosRequestConfig,
    errorMessage?: ErrorMessageType,
): UseUploadProgressResponses => {
    const cancelSendListRef = useRef<CancelSendListRef>({});
    const [header] = useRequestHeader();

    const handleCancelListChange = useCallback(({ type, fileId, cancel }: CancelListChangeParams) => {
        const cancelList = { ...cancelSendListRef.current };
        if (type === 'add') {
            cancelList[fileId] = cancel as Canceler;
        }
        if (type === 'cancel') {
            delete cancelList[fileId];
        }

        cancelSendListRef.current = cancelList;
    }, [cancelSendListRef.current]);

    const handleProgress = useCallback(
        async ({ file, signature, options, reqData }: ProgressParams) => {
            const { bizType, host, header: extHeader } = reqData;
            const api = `${host}${ApiPath.progress}${bizType}/${signature}`;
            const { nvtc: extHeaderNVTC, ...restHeader } = extHeader ?? {};
            const nvtc = config?.headers?.nvtc || extHeaderNVTC || header['x-nvtc'] || '';

            try {
                const formData = new FormData();
                formData.append(file.name, file);
                const {
                    data: resultData,
                }: AxiosResponse = await axios.post(
                    api,
                    formData,
                    {
                        timeout: 60000,
                        timeoutErrorMessage: 'timeout',
                        ...config,
                        ...options,
                        headers: {
                            ...config?.headers ?? {},
                            ...header,
                            ...restHeader,
                            ['x-nvtc']: nvtc,
                        },
                        cancelToken: new CancelToken(function executor(cancel) {
                            handleCancelListChange({ type: 'add', fileId: file.fileId, cancel });
                        }),
                    },
                );

                if (resultData.ErrorCode !== 100000) {
                    throw resultData;
                }
                handleCancelListChange({ type: 'cancel', fileId: file.fileId });
                return Promise.resolve(resultData);
            } catch (err) {
                let errMsg = errorMessage?.uploadError ?? UploadErrorMessage.uploadError;
                if (err.response?.data?.ErrorCode === 700000) {
                    errMsg = errorMessage?.checkFileHeaderTypeError ?? errorMessage?.uploadError ?? errMsg;
                }

                return Promise.reject({
                    success: false,
                    errorMessage: errMsg,
                });
            }
        },
        [handleCancelListChange],
    );

    const handleProgressBefore = useCallback(
        ({ file, options, signature, reqData }: ProgressBeforeParams) => {
            const { attachmentType, ...rest } = options;

            let files = [file];

            if (signature.length > 1) {
                // TODO block size
            }

            const promiseRequest = signature.map((item, index) => {
                return handleProgress({
                    file: files[index],
                    signature: item,
                    options: rest,
                    reqData,
                });
            });

            return Promise.all(promiseRequest)
                .then((result) => {
                    if (signature.length > 1) {
                        // TODO block size
                    }

                    return Promise.resolve(result);
                })
                .catch((err) => Promise.reject(err));
        },
        [],
    );

    const handleSignatureParams = useCallback(
        (file, options: UploadingOptions, reqData: ReqData) => {
            const { attachmentType, rule } = options;
            const {
                bizType,
                host,
                header,
                options: paramsOptions = {},
            } = reqData;
            const {
                EncryptedCustomerNumber = '',
                Identity = '',
            } = paramsOptions;
            const api = `${host}${ApiPath.signature}${bizType}`;

            let SignCount = 1;
            let signatureParams;

            if (EncryptedCustomerNumber) {
                signatureParams = {
                    EncryptedCustomerNumber: EncryptedCustomerNumber,
                };
            } else if (Identity) {
                signatureParams = {
                    EncryptedIdentity: Identity,
                };
            } else {
                throw new Error(
                    'Request parameters cannot be empty, CustomerNumber or Identity',
                );
            }


            if (rule?.BlockSizeKB > -1) {
                SignCount = Math.ceil(file.size / rule?.BlockSizeKB);

                return {
                    signatureApi: api,
                    signatureParams: {
                        ...signatureParams,
                        FileInfo: [
                            {
                                AttachmentType: attachmentType,
                                // TODO
                                FileMD5: '',
                                OriginFileName: file.name,
                                TotalPart: SignCount,
                            },
                        ],
                    },
                    extHeader: header,
                };
            }

            return {
                signatureApi: api,
                signatureParams: {
                    ...signatureParams,
                    SignCount,
                    AttachmentType: attachmentType,
                },
                extHeader: header,
            }
        },
        [],
    );

    const handleSignature = useCallback(
        async (file: UploadFile, options: UploadingOptions, reqData: ReqData) => {
            let responseStatus = {
                success: true,
                errorMessage: '',
            };

            try {
                const {
                    signatureApi,
                    signatureParams,
                    extHeader,
                } = handleSignatureParams(file, options, reqData);
                const { nvtc: extHeaderNVTC, ...restHeader } = extHeader ?? {};
                const nvtc = config?.headers?.nvtc || extHeaderNVTC || header['x-nvtc'] || '';

                const {
                    data: resultData,
                }: AxiosResponse<any> = await axios.post(
                    signatureApi,
                    signatureParams,
                    {
                        ...config,
                        headers: {
                            ...config?.headers ?? {},
                            ...header,
                            ...restHeader,
                            ['x-nvtc']: nvtc,
                        },
                        cancelToken: new CancelToken(function executor(cancel) {
                            handleCancelListChange({ type: 'add', fileId: file.fileId, cancel});
                        }),
                    },
                );

                if (resultData.ErrorCode !== 100000) {
                    throw resultData;
                }
                handleCancelListChange({ type: 'cancel', fileId: file.fileId });
                return handleProgressBefore({
                    file,
                    options,
                    signature: resultData.Result,
                    reqData,
                });



            } catch (err) {
                responseStatus = {
                    success: false,
                    errorMessage: errorMessage?.uploadError ?? UploadErrorMessage.uploadError,
                };
            }

            return Promise.reject(responseStatus);
        },
        [handleCancelListChange],
    );

    const onSendUpload = useCallback(
        /**
         * @param file UploadFile
         * @param reqData 包含 bizType, host, header, options
         * header目前支持目前支持authorization、nvtc，authorization必传，nvtc为空则会从cookie中获取；
         * options 请求额外参数，CustomerNumber、Identity，必须传其中一个，如两个都传优先使用CustomerNumber
         * @param options UploadingOptions
         */
        (
            file: UploadFile,
            reqData: ReqData,
            options: UploadingOptions = {},
        ) => {
            const { attachmentType } = options;

            if (attachmentType) {
                return handleSignature(file, options, reqData);
            }

            if (file.AttachmentType) {
                const opt: UploadingOptions = {
                    ...options,
                    attachmentType: file.AttachmentType,
                };
                return handleSignature(file, opt, reqData);
            }

            return Promise.reject('Request parameters cannot be empty, AttachmentType');
        },
        [],
    );

    const onSendCancel = useCallback((fileId: string = '', msg: string = '') => {
        let cancelList = { ...cancelSendListRef.current };
        if (!isEmpty(cancelList)) {
            if (fileId) {
                cancelList[fileId](msg);
                delete cancelList[fileId];
            } else {
                for (let key in cancelList) {
                    cancelList[key](msg);
                }

                cancelList = {};
            }
            cancelSendListRef.current = cancelList;
        }
    }, [cancelSendListRef.current]);

    return {
        onSendUpload,
        onUploadCancel: onSendCancel,
    };
}
