import toLower from 'lodash/toLower';
import toUpper from 'lodash/toUpper';
import { FileError } from './fileError';
import { ErrorType, StatusType } from '../types';

export const getFileType = (fileName) => toLower(fileName.substring(fileName.lastIndexOf(".")));

const getRulesKeys = (rules) => Object.keys(rules);

const checkFileType = (file, fileType, accept) => {
    if (accept.indexOf(fileType) > -1) {
        return Promise.resolve();
    }

    const acceptStr = toUpper(accept.join('').replace(/\./g, ' '));
    return Promise.reject(new FileError(ErrorType.fileTypeError, file, acceptStr));
};

const checkFileSize = (file, maxSize) => {
    if (file.size < maxSize * 1024 *1024) {
        return Promise.resolve();
    }

    return Promise.reject(new FileError(ErrorType.fileSizeError, file, `${maxSize}M`));
}

const checkFileCount = (file, maxCount, fileCount, key) => {
    const currentFileCount = fileCount[key];

    if (currentFileCount < maxCount) {
        fileCount[key] = currentFileCount + 1;
        return Promise.resolve();
    }

    return Promise.reject(new FileError(ErrorType.fileCountError, file, maxCount));
}

export const beforeUploadFileCheck = async ({files, fileList, rules, accept}): Promise<any> => {
    const rulesKeys = getRulesKeys(rules);
    const allFileTypeCount = rulesKeys.reduce((pre, cur) => ({ ...pre, [cur]: 0 }), {});

    fileList.forEach((item) => {
        const fileType = getFileType(item.name);
        const key = rulesKeys.find((val) => val.includes(fileType)) ?? '';
        if (item.status !== StatusType.error) {
            allFileTypeCount[key] = allFileTypeCount[key] + 1;
        }
    });

    for (let item of files) {
        const fileType = getFileType(item.name);
        const key = rulesKeys.find((val) => val.includes(fileType)) ?? '';
        const rule = rules[key];

        const {
            MaxFileCountForEachSubmit: maxCount = 0,
            MaxFileSizeForEachFileMB: maxSize = 0,
            AttachmentType,
        } = rule ?? {};

        item.fileId = item?.fileId || `date-${new Date().getTime()}`;
        item.AttachmentType = AttachmentType;
        try {
            await checkFileType(item, fileType, accept)
                .then(() => checkFileSize(item, maxSize))
                .then(() => checkFileCount(item, maxCount, allFileTypeCount, key))
                .catch((error) => Promise.reject(error));

        } catch (error) {
            return Promise.reject(error);
        }
    }

    return Promise.resolve();
}