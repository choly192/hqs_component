import React, { Fragment, useImperativeHandle, useRef, useState } from 'react';
import cn from 'classnames';
import { isEmpty, isNumber, noop } from 'lodash';
import { UploadItem } from './UploadItem';
import {
    defaultShowFileErrType,
    defaultShowErrFileType,
    StatusType,
    UploadFile,
    UploadProps,
    UploadPropsRef,
    ViewMode,
} from './types';
import { useUploadPermission } from './hooks/useUploadPermission';
import { beforeUploadFileCheck, getFileType } from './utils/beforeUploadFileCheck';

if (process.env.BROWSER) {
    require('./static/index.css');
}

/**
 * TODO List
 * 兼容样式 -- 1
 * 分片 -- 1
 */
const Upload: React.ForwardRefRenderFunction<UploadPropsRef, UploadProps> = ({
    className,
    style,
    viewMode = ViewMode.create,
    bizType,
    reqParams,
    isSwiper = false,
    icon = 'fa fa-plus',
    iconText = '',
    disabled = false,
    defaultFileValue,
    accept = 'image/*',
    multiple = false,
    isAllErrorMessage = false,
    showFileErrType = defaultShowFileErrType,
    fileIcon,
    errorMessage,
    permissionData,
    onChange = noop,
    onRemove = noop,
}, ref) => {
    const [fileList, setFileList] = useState<UploadFile[]>(defaultFileValue ?? []);
    const fileListRef = useRef<UploadFile[]>(defaultFileValue ?? []);
    const [errorMsg, setErrorMsg] = useState<string[]>([]);

    const compStatusRef = useRef<StatusType>(StatusType.init);

    // 获取上传配置
    const { permission, sourceData } = useUploadPermission(
        isEmpty(permissionData),
        {
            bizType,
            ...reqParams,
        },
        {},
        permissionData,
    );

    // 暴露当前组件状态，被动调用
    useImperativeHandle(ref, () => ({
        onGetStatus: () => compStatusRef.current,
        onAllReset: () => {
            setFileList((prevList) => {
                const list = prevList.reduce((total, item) => {
                    if (item.status === StatusType.uploading) {
                        item.isCancel = true;
                        item.status = StatusType.remove;
                        return [...total, item];
                    }
                    return total;
                }, []);

                fileListRef.current = [...list];
                return [...list];
            });
            setErrorMsg([]);
            compStatusRef.current = StatusType.init;
        },
        getPermission: () => sourceData,
        onAllCancelUploading: () => {
            setFileList((prevList) => {
                const newList = prevList.map((item) => {
                    if (item.status === StatusType.uploading) {
                        item.isCancel = true;
                        item.status = StatusType.remove;
                    }
                    return item;
                });

                fileListRef.current = newList;
                return newList;
            });
        },
    }));

    // 获取当前文件状态 uploading > error > success
    const handleStatusRef = (curFileList) => {
        let file = curFileList.find((item) => item.status === StatusType.uploading);
        if (isEmpty(file)) {
            file = curFileList.find((item) => item.status === StatusType.error);
        }

        compStatusRef.current = !isEmpty(file) ? file.status : StatusType.success;
    }

    // 上传前校验
    const handleBeforeFiles = (files: UploadFile[], index?: number) => {
        const { UploadRule, Accept } = permission;

        const checkParams = {
            files,
            fileList: fileListRef.current,
            rules: UploadRule,
            accept: Accept,
        };
        // 校验文件类型、大小、数量
        beforeUploadFileCheck(checkParams).then(() => {
            setFileList((preFileList) => {
                // 重新上传文件处理
                if (isNumber(index)) {
                    const newFileList = [...preFileList];
                    newFileList.splice(index, 1, ...files);

                    fileListRef.current = newFileList;
                    return newFileList;
                }

                fileListRef.current = [...preFileList, ...files];
                return [...preFileList, ...files];
            });

        }).catch((err) => {
            const { code, message, file } = err;
            const fileType = getFileType(file.name);
            const errMsg = errorMessage?.[code] || message;
            // 判断是否需要展示文件的错误类型
            if (showFileErrType.includes(code) && defaultShowErrFileType.includes(fileType)) {
                file.errorMessage = errMsg;
                setFileList((preFileList) => {
                    if (isNumber(index)) {
                        const newFileList = [...preFileList];
                        newFileList.splice(index, 1, ...files);

                        fileListRef.current = [...newFileList];
                        return [...newFileList];
                    }

                    fileListRef.current = [
                        ...preFileList,
                        file,
                    ];
                    return [
                        ...preFileList,
                        file,
                    ];
                });
            } else {
                setErrorMsg((preErrorMsg) => [...preErrorMsg, errMsg]);
            }
        });
    };

    // 上传
    const handleUploadChange = (e) => {
        e.stopPropagation();
        e.preventDefault();
        const files = e.target.files ?? [];
        if (files.length > 0) {
            setErrorMsg([]);
            handleBeforeFiles([...files]);
        }
    };

    // 重新上传
    const handleReUpload = (files, index) => {
        setErrorMsg([]);
        handleBeforeFiles(files, index);
    };

    // 删除操作 同时触发onChange onRemove
    const handleRemove = (file, isCallFun = true) => {
        const newFileList = [...fileListRef.current].filter((item) => item.fileId !== file.fileId);
        const successList = newFileList.filter((item) =>
            item.status === StatusType.success || item.status === StatusType.done,
        );
        handleStatusRef(newFileList);
        if (isCallFun && viewMode !== ViewMode.view) {
            file.status = StatusType.remove;
            onChange(file, newFileList, successList);
            onRemove(file, newFileList, successList);
        }

        setFileList((prev) =>{
            const newList = isCallFun ? newFileList : prev.filter((item) => item.fileId !== file.fileId);
            fileListRef.current = newList;
            return [...newList];
        });
        setErrorMsg([]);
    };

    // 上传中
    const handleFileUploadingChange = (file) => {
        const newFileList = [...fileListRef.current].reduce((total, item) => {
            if (item.fileId === file.fileId) {
                return [...total, file];
            }

            return [...total, item];
        }, []);
        let successList = newFileList.filter((item) =>
            item.status === StatusType.success || item.status === StatusType.done,
        );

        // 上传完成后（成功/失败）操作
        if (file.status === StatusType.success || file.status === StatusType.error) {
            setFileList((preList) => {
                const newList = preList.reduce((total, item) => {
                    if (item.fileId === file.fileId) {
                        return [...total, file];
                    }

                    return [...total, item];
                }, []);

                fileListRef.current = [...newList];
                return [...newList];
            });
        }
        handleStatusRef(newFileList);
        delete file?.isCancel;

        viewMode !== ViewMode.view && onChange(file, newFileList, successList);
    };

    // 渲染icon
    const renderUploadIcon = () => {
        return (
            <span className="attachment-add-icon">
                {typeof icon === 'string' ? <i className={icon} /> : icon }
                {iconText && typeof iconText === 'string' ? <span>{iconText}</span> : iconText}
            </span>
        );
    };

    // 渲染上传按钮
    const renderUploadBtn = () => {
        const { UploadEnabled, Accept, maxFileCont } = permission;

        return Number(maxFileCont) <= fileList.length || viewMode === ViewMode.view ? null : (
            <div
                className="attachment-add flex-center"
                id="upload-btn"
            >
                <input
                    disabled={!UploadEnabled && disabled || viewMode === ViewMode.disabled}
                    value={''}
                    type="file"
                    multiple={multiple}
                    accept={Accept.length > 0 ? Accept.join(',') : accept}
                    aria-label="Upload_File"
                    onChange={handleUploadChange}
                />
                {renderUploadIcon()}
            </div>
        )
    };

    // 渲染文件列表
    const renderFileList = () => {
            const { Accept, UploadRule } = permission;

            return fileList.map((item, index) => {
                return (
                    <UploadItem
                        key={item.fileId}
                        viewMode={viewMode}
                        file={item}
                        accept={Accept.length > 0 ? Accept.join(',') : accept}
                        fileIcon={fileIcon}
                        rules={UploadRule}
                        bizType={bizType}
                        reqParams={reqParams}
                        errorMessage={errorMessage}
                        onChange={(file) => handleFileUploadingChange(file)}
                        onReUpload={(files) => handleReUpload(files, index)}
                        onRemove={(isCallFun) => handleRemove(item, isCallFun)}
                    />
                );
            });
        };

    // 渲染错误信息
    const renderShowErrorMsg = () => {
        let errMsg: React.ReactNode[] = errorMsg.map((msg, index) => (
            <Fragment key={`errMsg_${index}`}>
                {msg}
                <br />
            </Fragment>
        ));

        const fileListErr = fileList.reduce((total, item, index, list) => {
            if (item.status === StatusType.error) {
                const isErrMsg = list.slice(0, index).some((val) =>
                    val?.errorMessage === item.errorMessage,
                );

                return isErrMsg ? total : [
                    ...total,
                    (
                        <Fragment key={item.fileId}>
                            {item.errorMessage}
                            <br />
                        </Fragment>
                    ),
                ];
            }

            return total;
        }, errMsg);

        let msg = fileListErr;

        if (viewMode === ViewMode.view && errorMessage?.hasUploadedInAnotherWindowError) {
            msg = [(
                <Fragment>
                    {errorMessage?.hasUploadedInAnotherWindowError}
                    <br />
                </Fragment>
            )];
        }else if (!isAllErrorMessage) {
            msg = errorMsg.length > 0 ? errorMsg.slice(-1) : fileListErr.slice(-1);
        }

        return fileListErr.length > 0 ? (
            <div className="message message-alert no-bg">
                <div className="message-wrapper">
                    <div className="message-icon fa-exclamation-triangle" />
                    <div className="message-information">
                        <span className="message-title">Upload Failed </span>
                        {msg.length > 1 ? (
                            <Fragment>
                                <br />
                                {msg}
                            </Fragment>
                        ) : msg}
                    </div>
                </div>
            </div>
        ) : null;
    };

    return (
        <div className={cn('NE-chat-dialog-content', className)} style={style}>
            <div className="NE-chat-attachments">
                {renderFileList()}
                {renderUploadBtn()}
            </div>
            {permission.Notice && (
                <p className="note" id="upload-notice">
                    Note: {permission.Notice}
                </p>
            )}
            {renderShowErrorMsg()}
    </div>
    );
};

export default React.forwardRef(Upload);
