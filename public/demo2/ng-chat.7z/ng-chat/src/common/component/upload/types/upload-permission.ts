import { ReqData } from './index';

export interface PermissionResult {
    UploadEnabled:      boolean;
    UploadRule:         UploadRule;
    GlobalCustomFields: CustomFields;
}

export interface CustomFields {
    UploadNote:          string;
    UploadTimeoutSecond: number;
}

export interface UploadRule {
    AllowFileTypes: AllowFileType[];
}

export interface AllowFileType {
    FileType:                  string[];
    Extension:                 string[];
    AttachmentType:            number;
    BlockSizeKB:               number;
    MaxFileSizeForEachFileMB:  number;
    MaxFileCountForEachSubmit: number;
    CustomFields:              CustomFields;
    AllowCustomerUpload:       boolean;
}

export interface PermissionData {
    Notice: string;
    UploadEnabled: boolean;
    Accept: string[];
    UploadRule: any;
    maxFileCont: number;
}

export interface ReqStatus {
    success: boolean;
    errorMessage: string;
}

export interface OnGetPermissionResponses extends ReqStatus {
    permission: PermissionData;
    sourceData: PermissionResult;
}

export interface useUploadPermissionResponses {
    permission: PermissionData;
    onGetPermission: (query?: ReqData) => Promise<OnGetPermissionResponses>;
    requestStatus?: ReqStatus;
    sourceData?: PermissionResult;
}
