import { useEffect, useCallback, useState } from 'react';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import toLower from 'lodash/toLower';
import isEmpty from 'lodash/isEmpty';
import { useRequestHeader } from './useRequestHeader';
import {
    ResultBase,
    PermissionData,
    ReqData,
    ApiPath,
    PermissionResult,
    useUploadPermissionResponses,
    OnGetPermissionResponses,
    RequestParams,
    ReqStatus,
    defaultPermissionData,
} from '../types';

/**
 * @param loadData 是否立即调用
 * @param data 包含 bizType, host, header, options
 * header目前支持目前支持authorization、nvtc，authorization必传，nvtc为空则会从cookie中获取；
 * options 请求额外参数，CustomerNumber、Identity，必须传其中一个，如两个都传优先使用CustomerNumber
 * @param config axios 配置
 * @param permissionData
 */
export const useUploadPermission = (
    loadData: boolean,
    data: Partial<ReqData> = {},
    config: AxiosRequestConfig = {},
    permissionData: PermissionData = defaultPermissionData,
): useUploadPermissionResponses => {
    const [permission, setPermission] = useState<PermissionData>(permissionData);
    const [sourceData, setSourceData] = useState<PermissionResult>();
    const [error, setError] = useState<ReqStatus>();

    const defaultCommonErrorMessage =
        "It's not you. It's us. Let's refresh the page and try again, please.";

    const [header] = useRequestHeader();

    const handlePermissionParams = useCallback(
        (queryData: ReqData): RequestParams => {
            const {
                bizType,
                host,
                header,
                options = {},
            } = queryData;

            const {
                EncryptedCustomerNumber = '',
                Identity = '',
            } = options;
            const api = `${host}${ApiPath.permission}${bizType}`;

            if (EncryptedCustomerNumber) {
                return {
                    api,
                    params: { EncryptedCustomerNumber: EncryptedCustomerNumber },
                    extHeader: header,
                };
            }

            if (Identity) {
                return {
                    api,
                    params: { EncryptedIdentity: Identity },
                    extHeader: header,
                };
            }

            throw new Error(
                'Request parameters cannot be empty, CustomerNumber or Identity',
            );
        },
        [],
    );

    const handleGetPermission = useCallback(
        async (query?: ReqData): Promise<OnGetPermissionResponses> => {
            let permissionData: PermissionData = {
                Notice: '',
                UploadEnabled: false,
                UploadRule: {},
                Accept: [],
                maxFileCont: 0,
            };
            let reqStatus = {
                success: true,
                errorMessage: '',
            };
            let sourceData: PermissionResult;

            try {
                const queryData = query?.bizType ? query : data;
                const { api = '', params = {}, extHeader } = handlePermissionParams(queryData as ReqData) ?? {};
                const { nvtc: extHeaderNVTC, ...restHeader } = extHeader ?? {};
                const nvtc = config?.headers?.nvtc || extHeaderNVTC || header['x-nvtc'] || '';
                const {
                    data: resultData,
                }: AxiosResponse<ResultBase<PermissionResult>> = await axios.post(
                    api,
                    params,
                    {
                        ...config,
                        headers: {
                            ...config?.headers ?? {},
                            ...header,
                            ...restHeader,
                            ['x-nvtc']: nvtc,
                        },
                    },
                );

                if (resultData.ErrorCode !== 100000) {
                    throw resultData;
                }

                const {
                    GlobalCustomFields,
                    UploadEnabled = false,
                    UploadRule,
                } = resultData?.Result ?? {};

                const rule = UploadRule?.AllowFileTypes?.reduce((pre, cur) => {
                    const {
                        Extension = [],
                        CustomFields,
                        AllowCustomerUpload,
                        MaxFileCountForEachSubmit,
                    } = cur;
                    const key = toLower(Extension.join(','));

                    if (!AllowCustomerUpload) {
                        return pre;
                    }

                    permissionData.Accept.push(...Extension.map((val) => toLower(val)));
                    permissionData.maxFileCont = permissionData.maxFileCont + MaxFileCountForEachSubmit;
                    return {
                        ...pre,
                        [key]: {
                            ...cur,
                            UploadTimeoutSecond: CustomFields.UploadTimeoutSecond,
                        },
                    };
                }, {});

                const Accept = permissionData.Accept.reduce((total: string[], item: string) =>
                    total.includes(item) ? total : [...total, item],
                    [],
                );

                permissionData = {
                    ...permissionData,
                    Accept,
                    UploadEnabled: isEmpty(rule) ? false : UploadEnabled,
                    UploadRule: rule,
                    Notice: GlobalCustomFields?.UploadNote ?? '',
                };
                sourceData = resultData?.Result ?? {};

            } catch (err) {
                sourceData = err.data;
                reqStatus = {
                    success: false,
                    errorMessage: err?.ErrorMessage ?? err?.message ?? defaultCommonErrorMessage
                };
            }

            setError(reqStatus);
            setPermission(permissionData);
            setSourceData(sourceData);

            return {
                ...reqStatus,
                permission: permissionData,
                sourceData: sourceData,
            };
        },
        [data],
    );

    useEffect(() => {
        if (!loadData) {
            return;
        }

        handleGetPermission();
    }, [loadData]);

    return {
        permission,
        onGetPermission: handleGetPermission,
        requestStatus: error,
        sourceData,
    };
}