export enum ViewMode {
    create = 'create',
    edit = 'edit',
    view = 'view',
    disabled = 'disabled',
}
