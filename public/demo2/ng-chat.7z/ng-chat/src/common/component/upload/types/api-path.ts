export enum ApiPath {
    progress = 'api/website/upload/progress/',
    signature = 'api/website/upload/external/signature/',
    permission = 'api/website/upload/external/permission/',
}