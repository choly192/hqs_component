export interface UploadFile extends File {
    fileId: string;
    AttachmentType: number;
    status: StatusType;
    url?: string;
    errorMessage?: string;
    response?: {
        FileName: string;
        FileInfo: string;
    };
    [key: string]: any;
}

export enum StatusType {
    // 初始化
    init = 'init',
    // 上传中
    uploading = 'uploading',
    // 成功
    success = 'success',
    // 失败
    error = 'error',
    // 删除
    remove = 'remove',
    // 完成，一般用于回显
    done = 'done',
}

export enum AttachmentItemType {
    Add,
    Img,
    Mp4,
    Pdf,
  }

export enum FileType {
    jpg = '.jpg',
    jpeg = '.jpeg',
    png = '.png',
    gif = '.gif',
    svg = '.svg',
    pdf = '.pdf',
    mp4 = '.mp4',
}