import { AxiosRequestConfig, Canceler } from 'axios';
import { UploadFile } from './upload-file';
import { ReqData } from './hooks-base';

export interface UploadingOptions extends Pick<AxiosRequestConfig, 'onUploadProgress' | 'onDownloadProgress'> {
    attachmentType?: number;
    rule?: any;
}

export interface ProgressResult {
    FileInfo: string;
    FileName: string;
}

export type SignatureResult = Array<string>;

export interface UseUploadProgressResponses {
    onSendUpload: (file: UploadFile, reqData: ReqData, options?: UploadingOptions) => Promise<any>;
    onUploadCancel: (msg?: string) => void;
}

export interface ProgressBeforeParams {
    file: UploadFile;
    options: UploadingOptions;
    signature: string[];
    reqData: ReqData;
}

export interface ProgressParams {
    options: AxiosRequestConfig;
    signature: string;
    reqData: ReqData;
    file: UploadFile;
}

export interface CancelListChangeParams {
    type: 'add' | 'cancel';
    fileId: string;
    cancel?: Canceler;
}

export interface CancelSendListRef {
    [key: string]: Canceler;
}