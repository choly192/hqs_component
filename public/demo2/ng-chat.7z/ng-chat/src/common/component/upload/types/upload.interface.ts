import { ReactNode, CSSProperties } from 'react';
import { ErrorType } from './upload-error-message';
import { UploadFile } from './upload-file';
import { ViewMode } from './view-mode';
import { PermissionData, PermissionResult } from './upload-permission';

export type ErrorMessageType = { [key in ErrorType]?: string };

export interface UploadProps {
    className?: string;
    style?: CSSProperties;
    /**
     * viewMode
     * 模式
     */
    viewMode?: keyof typeof ViewMode;
    /**
     * bizType
     * 业务码
    */
    bizType: number;
    /**
     * reqParams
     * 请求所需参数
    */
    reqParams: ReqParams;
    /**
     * isSwiper
     * 开启横向滑动
     * defaultValue false
    */
    isSwiper?: boolean;
    /**
     * icon
     * 上传按钮图标
    */
    icon?: ReactNode;
    /**
     * iconText
     * 上传按钮文本信息
    */
    iconText?: ReactNode;
    /**
     * listType
     * 上传文件列表
     * defaultValue default
     * TODO 未启用
    */
    listType?: 'default' | 'card';
    /**
     * disabled
     * 禁用
    */
    disabled?: boolean;
    /**
     * defaultFileList
     * 初始值
    */
    defaultFileValue?: UploadFile[];
    /**
     * accept
     * 文件类型
     * defaultValue image/*
     */
    accept?: string;
    /**
     * multiple
     * 是否可以多选
    */
    multiple?: boolean;
    /**
     * isAllErrorMessage
     * 是否展示全部错误信息
     * defaultValue false
    */
     isAllErrorMessage?: boolean;
    /**
     * showErrFileType
     * 需要显示的错误类型文件
    */
    showFileErrType?: ErrorType[];
    /**
     * fileIcon
     * 文件图标
     * 上传后文件展示图标
    */
    fileIcon?: { [key: string]: ReactNode };
    /**
     * errorMessage
     * 上传中错误文案
    */
    errorMessage?: ErrorMessageType;
    /**
     * permissionData
     * 上传文件配置数据
     * 传入组件则不再读取配置
     */
    permissionData?: PermissionData;
    /**
     * onChange
     * value变化时触发
     * (file, fileList) => void
    */
    onChange?: (file: UploadFile | UploadFile[], fileList: UploadFile[], successList: UploadFile[]) => void;
    /**
     * onRemove
     * 删除文件时触发
     * (file, fileList) => void
    */
   onRemove?: (file: UploadFile | UploadFile[], fileList: UploadFile[], successList: UploadFile[]) => void;
}

export interface UploadPropsRef {
    /**
     * onGetStatus
     * 获取所有文件状态
     * 优先级：uploading > error > success
     * () => status
    */
    onGetStatus: () => string;
    /**
     * onAllReset
     * 重置fileList successFileList值
     */
    onAllReset: () => void;
    /**
     * getPermission
     * 获取上传配置
     */
    getPermission: () => PermissionResult | undefined;
    onAllCancelUploading: () => void;
}

export interface ReqParams {
    /**
     * host
     * 请求地址
     */
    host?: string;
    /**
     * header
     * 请求头额外参数，目前支持authorization、nvtc
     * authorization必传
     * nvtc为空则会从cookie中获取
     * 如需增加额外参数请联系MIS
     */
    header: Header;
    /**
     * options
     * 请求额外参数，CustomerNumber、Identity
     * 必须传其中一个，如两个都传优先使用CustomerNumber
     */
    options?: ReqOptions;
}

export interface Header {
    Authorization: string;
    nvtc: string;
}

export interface ReqOptions {
    EncryptedCustomerNumber?: string;
    Identity?: string;
}