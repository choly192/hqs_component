export enum ErrorType {
    getUploadConfigError = 'getUploadConfigError',
    uploadError = 'uploadError',
    fileTypeError = 'fileTypeError',
    fileSizeError = 'fileSizeError',
    fileCountError = 'fileCountError',
    hasUploadedInAnotherWindowError = 'hasUploadedInAnotherWindowError',
    checkFileHeaderTypeError = 'checkFileHeaderTypeError',
    commonError = 'commonError',
}

export enum UploadErrorMessage {
    getUploadConfigError = 'Uh-oh, it looks like we have our wires crossed. Please try again later.',
    uploadError = 'Connection timeout.',
    fileTypeError = 'Unsupported file type (supported:',
    fileSizeError = 'Exceeded maximum file size (',
    hasUploadedInAnotherWindowError = 'Upload in progress on another window.',
    checkFileHeaderTypeError = 'Try saving it in a different format and upload again.',
    commonError = 'The attachment(s) being uploaded does not meet the criteria!',
}