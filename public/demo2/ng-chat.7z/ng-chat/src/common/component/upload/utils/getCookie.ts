export const getCookie = (objName: string) => {
    const arrStr = document.cookie.split('; ');

    for (let i = 0; i < arrStr.length; i++) {
        const temp = arrStr[i].split('=');

        if (temp[0] == objName) {
            return decodeURI(temp[1]);
        }
    }

    return '';
}
