import { useState, useEffect, useRef, useCallback } from 'react';
import { UploadFile } from '../types';

declare let window: any;

export const useGetObjectUrl = (file): [string, (file: UploadFile) => void] => {
  const [blobUrl, setBlobUrl] = useState('');
  const preFile = useRef<UploadFile>();

  useEffect(() => {
    if (preFile?.current?.fileId !== file.fileId) {
      getBlobUrl(file);
      preFile.current = file;
    }
  }, [file]);

  const getBlobUrl = useCallback((curFile) => {
    let url = "";
    if (window.createObjectURL != undefined) {
      //basic
      url = window.createObjectURL(curFile);
    } else if (window.URL != undefined) {
      //firefox
      url = window.URL.createObjectURL(curFile);
    } else if (window.webkitURL != undefined) {
      url = window.webkitURL.createObjectURL(curFile);
    }

    setBlobUrl(url);
  }, []);

  return [blobUrl, getBlobUrl];
};