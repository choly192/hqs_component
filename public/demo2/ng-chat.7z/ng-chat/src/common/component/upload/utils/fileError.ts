import { StatusType, UploadErrorMessage, UploadFile } from '../types';

class FileError {
    readonly errorFile: UploadFile;
    readonly errorCode: string;
    readonly joinVal: string;

    constructor(code: string, file: UploadFile, val?: string) {
        this.errorCode = code;
        this.joinVal = val ?? '';
        this.errorFile = file;
    }

    public get message() {
        const msg = UploadErrorMessage[this.errorCode];
        return msg ? `${msg}${this.joinVal}).` : UploadErrorMessage.commonError;
    }

    public get code() {
        return this.errorCode;
    }

    public get file() {
        this.errorFile.status = StatusType.error;
        return this.errorFile;
    }
}

export { FileError };