import React from 'react';
import { ErrorType } from './upload-error-message';
import { FileType } from './upload-file';

export const defaultPermissionData = {
    Notice: '',
    UploadEnabled: false,
    UploadRule: {},
    Accept: [],
    maxFileCont: 0,
};

export const defaultShowFileErrType: string[] = [ErrorType.fileSizeError, ErrorType.fileCountError];

export const defaultShowErrFileType: string[] = [
    FileType.pdf,
    FileType.gif,
    FileType.jpg,
    FileType.png,
    FileType.jpeg,
    FileType.mp4,
];

export const defaultFileIcon = {
    [FileType.pdf]: <i className="fa fa-file-pdf-o" aria-label="pdf" />,
};
