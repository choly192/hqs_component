import { Header, ReqParams } from './upload.interface';

export interface ReqData extends ReqParams {
    bizType: number;
}

export interface CustomerParams {
    EncryptedCustomerNumber?: string;
    EncryptedIdentity?: string;
}

export interface RequestParams {
    api: string;
    params: CustomerParams;
    extHeader: Header;
}

export interface ResultBase<T> {
    ErrorMessage: string;
    ErrorCode:    number;
    Result:       T;
}