import React, { useCallback, useRef, useEffect, useState } from 'react';
import cn from 'classnames';
import {
    UploadFile,
    StatusType,
    defaultFileIcon,
    AttachmentItemType,
    ViewMode,
    ReqParams,
    ErrorMessageType,
} from './types';
// import { getObjectUrl } from './utils/getObjectUrl';
import { useGetObjectUrl } from './hooks/useGetObjectUrl';
import { useUploadProgress } from './hooks/useUploadProgress';

interface UploadItemProps {
    viewMode?: keyof typeof ViewMode;
    file: UploadFile;
    accept: string;
    disabled?: boolean;
    fileIcon?: { [key: string]: React.ReactNode };
    rules: any;
    bizType: number;
    reqParams: ReqParams;
    errorMessage?: ErrorMessageType;
    onReUpload: (files: UploadFile[]) => void,
    onChange: (file: UploadFile) => void,
    onRemove: (isCallFun?: boolean) => void,
}

export const UploadItem: React.FC<UploadItemProps> = ({
    viewMode,
    accept,
    file,
    disabled = false,
    fileIcon = {},
    rules,
    bizType,
    reqParams,
    errorMessage,
    onChange,
    onReUpload,
    onRemove,
}) => {
    const [uploadProgress, setUploadProgress] = useState<number>(0);
    const reselectRef = useRef<HTMLInputElement>(null);
    const uploadCancelRef = useRef<boolean>(false);

    // 获取文件blobUrl
    const [blobUrl] = useGetObjectUrl(file);
    // 上传文件（获取签名、上传）
    const { onSendUpload, onUploadCancel } = useUploadProgress(
        {},
        errorMessage,
    );

    const {
        name = '',
        AttachmentType,
    } = file;

    const fileTypeIndex = name.lastIndexOf('.');
    const fileType = name.substring(fileTypeIndex).toLowerCase();

    /**
     * 1.监测文件
     *   文件没有状态及表示没有进行上传操作
     *   调用上传服务并设置状态
     *
     * 2.检测组件展示模式
     *   只读时移除上传中文件并清除上传请求
    */
    useEffect(() => {
        if (!file?.status) {
            file.status = StatusType.uploading;
            setUploadProgress(0);
            handleUploading(file);
            onChange(file);
        }

        if (file.isCancel || viewMode === ViewMode.view && file?.status === StatusType.uploading) {
            uploadCancelRef.current = true;
            onUploadCancel();
            onRemove(!file.isCancel);
        }
    }, [file, file.isCancel, viewMode, onUploadCancel]);

    // 是否可编辑
    const handleHasOperator = useCallback(() => {
        return !(viewMode === ViewMode.view || viewMode === ViewMode.disabled);
    }, [viewMode]);

    // 上传进度
    const handleUploadProgress = (progressEvent) => {
        const complete = progressEvent.loaded / progressEvent.total * 100 | 0;
        setUploadProgress(() => complete > 95 ? 95 : complete);
    }

    // 调用上传服务
    const handleUploading = async (curFile) => {
        try {
            const key = Object.keys(rules).find((val) => val.includes(fileType)) ?? '';
            const rule = rules[key];
            const result = await onSendUpload(curFile,
                {
                    bizType,
                    ...reqParams,
                },
                {
                    rule,
                    onUploadProgress: handleUploadProgress,
                },
            );

            curFile.response = result[0].Result;
            curFile.status = StatusType.success;
            setUploadProgress(100);
        } catch (err) {
            if (!uploadCancelRef.current) {
                curFile.errorMessage = err.errorMessage;
                curFile.status = StatusType.error;
            }
        }

        !uploadCancelRef.current && onChange(curFile);
    };

    // 重新上传
    const handleReUploadChange = (e) => {
        e.stopPropagation();
        e.preventDefault();
        const files = e.target.files ?? [];

        if (files.length > 0) {
            const curFile = files[0];
            curFile.fileId = file.fileId;
            onReUpload([curFile]);
        }
    };

    // 选择上传文件
    const handleReselectClick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const hasOperator = handleHasOperator();
        if (hasOperator) {
            reselectRef?.current?.click();
        }
    }

    // 删除前操作
    const handleRemoveBefore = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (file.status === StatusType.uploading) {
            uploadCancelRef.current = true;
            onUploadCancel();
        }

        onRemove();
    };

    // 错误类型文件，可重新上传
    const renderErr = () => {
        if (file.status === StatusType.error) {
            const hasOperator = handleHasOperator();

            return (
                <>
                    {hasOperator && <input
                        ref={reselectRef}
                        type='file'
                        accept={accept}
                        aria-label='Reselect_File'
                        value={''}
                        disabled={disabled || viewMode === ViewMode.disabled}
                        hidden
                        onChange={handleReUploadChange}
                    />}
                    <span
                        className={cn('attachment-reselect', {
                            ['attachment-reselect-pointer ']: hasOperator,
                            ['attachment-reselect-not']: !hasOperator,
                        })}
                        onClick={handleReselectClick}
                    >
                        Reselect
                    </span>
                </>
            );
        }

        return null;
    };

    // 上传进度条
    const renderLoading = () => {
        return file.status === StatusType.uploading && (
            <div className="attachment-upload-processing" style={{ width: `${uploadProgress}%` }} />
        )
    };

    // 预览文件
    const renderFileView = () => {
        if (AttachmentType === AttachmentItemType.Pdf) {
            return <span className="attachment-pdf-name">{name}</span>
        }

        if (AttachmentType === AttachmentItemType.Mp4) {
            // TODO MP4
            return null;
        }

        return (
            <img
                className={cn({
                    ['lower-opacity']: [StatusType.error, StatusType.uploading].includes(file.status),
                })}
                src={file.url || blobUrl}
                alt={name ?? ''}
            />
        );
    };

    // 删除按钮
    const renderRemoveBtn = () => {
        const hasOperator = handleHasOperator();
        if (!hasOperator) {
            return null;
        }

        return <span className="attachment-remove" onClick={handleRemoveBefore}>
                <i className="fa fa-times" />
            </span>;
    };

    return (
        <div className={cn({
            ['attachment-img']: AttachmentType === AttachmentItemType.Img,
            ['attachment-pdf']: AttachmentType === AttachmentItemType.Pdf,
            ['attachment-failed']: file.status === StatusType.error,
            ['attachment-uploading']: file.status === StatusType.uploading,
        })}>
            {renderErr()}
            {renderLoading()}
            {fileIcon?.[fileType] || defaultFileIcon?.[fileType]}
            {renderFileView()}
            {renderRemoveBtn()}
        </div>
    )
};
