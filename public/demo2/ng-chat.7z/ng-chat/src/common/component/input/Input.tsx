import React, { useState, FC } from 'react';
import cn from 'classnames';

interface LabelInputProps {
    name: string;
    defaultValue?: string;
    errorMsg?: string;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (event: React.FocusEvent<HTMLInputElement, Element>) => void;
    onFocus?: (event: React.FocusEvent<HTMLInputElement, Element>) => void;
    onKeyDown?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
    error?: boolean;
    maxLength?: number;
}

export const Input: FC<LabelInputProps> = ({
    name,
    defaultValue,
    errorMsg,
    onChange,
    onBlur,
    onFocus,
    onKeyDown,
    error,
    maxLength,
}) => {
    return (
        <div className={cn('row', { 'is-error': error && errorMsg })}>
            <label>{name}</label>
            <input
                defaultValue={defaultValue}
                onChange={onChange}
                onBlur={onBlur}
                onFocus={onFocus}
                onKeyDown={onKeyDown}
                maxLength={maxLength}
            />
            {error && errorMsg && <span className="form-error-message">{errorMsg}</span>}
        </div>
    );
};

Input.displayName = 'Input';
