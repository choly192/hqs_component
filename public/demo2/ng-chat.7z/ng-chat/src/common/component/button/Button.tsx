import React, { FC, useState, useEffect } from 'react';
import classnames from 'classnames';

type HtmlButtonProps = React.DetailedHTMLProps<
    React.ButtonHTMLAttributes<HTMLButtonElement>,
    HTMLButtonElement
>;

type PickedProps = 'id' | 'name' | 'onClick' | 'className' | 'disabled' | 'type';
type ButtonProps = Pick<HtmlButtonProps, PickedProps> & {
    text: string;
    pending?: boolean;
    style?: React.CSSProperties;
};

export const Button: FC<ButtonProps> = ({
    type,
    id,
    style,
    name,
    className,
    onClick,
    disabled,
    pending,
    text,
}) => {
    let initType =
        type != 'submit' ? type : ('button' as 'submit' | 'reset' | 'button');
    let [btnType, setBtnType] = useState(initType);

    useEffect(() => {
        if (type != 'submit') return;
        setBtnType(type);
    }, []);
    return (
        <button
            id={id}
            style={style || {}}
            name={name}
            type={btnType || 'button'}
            className={classnames('btn', className)}
            onClick={onClick}
            disabled={disabled}
        >
            {pending ? (
                <span
                    className="loading-icon loading-spin"
                    aria-label="please waiting moment"
                ></span>
            ) : (
                text
            )}
        </button>
    );
};
