import React, { FunctionComponent, CSSProperties, useEffect, useRef, useState } from 'react';
import cn from 'classnames';

let styles = {
    normal: { color: 'rgb(112, 112, 112)' },
    warn: { color: 'rgb(225, 0, 0)' },
};

interface TextareaProps {
    placeholder?: string;
    limit?: number;
    autoHeight?: boolean;
    label?: string;
    maxLength?: number;
    disabled?: boolean;
    defaultValue?: string;
    errorMessage?: string;
    style?: CSSProperties;
    customerClass?: string;
    onChange?: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
    onBlur?: (event: React.FocusEvent<HTMLTextAreaElement, Element>) => void;
    maxHeight?: number;
    minHeight?: number;
    error?: boolean;
    isOption?: boolean;
}

export let Textarea: FunctionComponent<TextareaProps> = (props) => {
    const {
        label,
        placeholder,
        disabled,
        customerClass,
        limit,
        maxLength,
        onChange,
        onBlur,
        autoHeight,
        defaultValue,
        errorMessage,
        maxHeight,
        minHeight,
        error,
        isOption,
    } = props;

    const [count, setCount] = useState(0);
    const [style, setStyle] = useState(styles.normal);

    const textareaRef = useRef<HTMLTextAreaElement>(null);

    let changeLimitStyle = (e) => {
        let target = e.target;
        let length = target.value.length ?? 0;
        setCount(length);

        if (!!limit) {
            if (length > limit) {
                setStyle(styles.warn);
            } else {
                setStyle(styles.normal);
            }
        }
    };

    let change = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        !!limit && !maxLength && changeLimitStyle(e);
        setCount(e?.target?.value?.length);
        onChange && onChange(e);
    };

    let blur = (event: React.FocusEvent<HTMLTextAreaElement, Element>) => {
        onBlur && onBlur(event);
    };

    useEffect(() => {
        if (!autoHeight) return;
        let current = textareaRef.current;
        let keyup = () => {
            current ? (current.style.height = current?.scrollHeight + 'px') : null;
        };
        current?.addEventListener('keyup', keyup);

        return () => {
            autoHeight && current?.removeEventListener('keyup', keyup);
        };
    }, []);

    useEffect(() => {
        if (minHeight && maxHeight) {
            let current = textareaRef.current as HTMLTextAreaElement;
            current.style.height = minHeight + 'px';
            let input = () => {
                current.style.height = 'inherit';
                let computed = window.getComputedStyle(current);
                let height =
                    current.scrollHeight +
                    parseInt(computed.getPropertyValue('padding-bottom'), 10) -
                    parseInt(computed.getPropertyValue('border-top-width'), 10) -
                    parseInt(computed.getPropertyValue('border-bottom-width'), 10);

                // cap height
                if (height > maxHeight) {
                    height = maxHeight;
                } else {
                    height = minHeight;
                }
                current ? (current.style.height = height + 'px') : null;
            };
            current?.addEventListener('input', input);

            return () => {
                autoHeight && current?.removeEventListener('keyup', input);
            };
        }
    }, []);

    return (
        <>
            {label && <label className="form-cell-name">{label}{isOption && <span className="small"> (OPTIONAL)</span>}</label>}
            <textarea
                ref={textareaRef}
                disabled={disabled || false}
                className={cn('form-textarea', customerClass ?? '')}
                placeholder={`${placeholder || ''}`}
                defaultValue={defaultValue}
                onChange={change}
                onBlur={blur}
                aria-label={label}
                maxLength={maxLength}
            ></textarea>
            {!!limit && (
                <div className="form-textarea-counter">
                    <span style={style}>{count}</span> / {limit}
                </div>
            )}
            {error && errorMessage && <span className="form-error-message">{errorMessage}</span>}
        </>
    );
};

Textarea.displayName = 'Textarea';
