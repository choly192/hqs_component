export module Parameters {
    export const COMPANY_CODE = 'CompanyCode';
    export const LANGUAGE_CODE = 'LanguageCode';
}
